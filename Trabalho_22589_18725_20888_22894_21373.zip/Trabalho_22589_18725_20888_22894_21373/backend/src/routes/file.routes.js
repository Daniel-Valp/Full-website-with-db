const express = require("express");
const router = express.Router();

const controller = require("../controllers/file.controller");
const upload = require("../utils/fileUtils");

router.get("/delete/:id", controller.delete);
router.post("/create", upload.single("file"), controller.create); // recebe o ficheiro no form-data
router.get("/update/:id", upload.single("file"), controller.update); // recebe o ficheiro no form-data & id nos params
router.get("/get/:id", controller.get);
router.get("/list", controller.list);

module.exports = router;