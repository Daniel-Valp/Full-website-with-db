const express = require("express");
const router = express.Router();

const controller = require("../controllers/cliente.controller");

router.post("/negocio/create", controller.negocioclientes);

module.exports = router;