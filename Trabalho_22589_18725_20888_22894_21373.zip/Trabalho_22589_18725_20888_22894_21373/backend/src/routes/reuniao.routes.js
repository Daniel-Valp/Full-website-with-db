const express = require("express");
const router = express.Router();

const controller = require("../controllers/reuniao.controller");

router.post("/listUtilizador", controller.listUtilizador);

module.exports = router;