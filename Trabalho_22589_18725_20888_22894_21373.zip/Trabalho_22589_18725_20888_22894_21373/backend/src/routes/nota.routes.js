const express = require("express");
const router = express.Router();

const controller = require("../controllers/notaficheiro.controller");

router.post("/mulCreate", controller.mulCreate);

module.exports = router;