const express = require("express");
const router = express.Router();

const controller = require("../controllers/negocio.controller");

router.post("/adicionar-utilizador", controller.adicionarUtilizador);

module.exports = router;