const express = require('express');
const middleware = require('../middleware/middleware');

const Routes = ({ directory, validateToken = [] }) => {
	const router = express.Router();
	const controller = require(`../controllers/${directory}.controller`);

	router.route('/create')
		.post([...(validateToken?.create ? [middleware.checkToken] : [])], controller.create);
	router.route('/get/:id')
		.get([...(validateToken?.get ? [middleware.checkToken] : [])], controller.get);
	router.route('/list')
		.get([...(validateToken?.list ? [middleware.checkToken] : [])], controller.list)
		.post([...(validateToken?.list ? [middleware.checkToken] : [])], controller.list);
	router.route('/update/:id')
		.put([...(validateToken?.update ? [middleware.checkToken] : [])], controller.update);
	router.route('/delete/:id')
		.get([(middleware.checkToken)], controller.delete);

	return router;
}

module.exports = Routes;