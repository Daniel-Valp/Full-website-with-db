const express = require("express");
const router = express.Router();

const controller = require("../controllers/utilizador.controller");

router.get("/gettag/:id", controller.gettag);
router.post("/search/geral", controller.searchGeral);
router.post("/search/exactMatch", controller.searchExactMatch);
router.post("/login", controller.login);
router.get("/confirmacao", controller.confirmacao);
router.get("/dados", controller.dados);
router.post("/auth/refresh", controller.refreshToken);
router.put("/forgetPassword/confirmar", controller.forgetPasswordConfirmacao);
router.post("/forgetPassword/email", controller.forgetPasswordEmail);

module.exports = router;