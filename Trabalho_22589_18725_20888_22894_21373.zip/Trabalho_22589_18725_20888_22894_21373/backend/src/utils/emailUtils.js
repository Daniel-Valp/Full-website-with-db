const nodemailer = require("nodemailer");
const { emailInfo, FRONTEND_URL, CONFIRMACAO_PARAM, AVISO_REUNIAO_COMECANDO_MIN } = require("../data/constants");

const transporter = nodemailer.createTransport({
	service: "Gmail",
	auth: emailInfo
});


const mandarEmailConfirmacao = async (codigo, email, routeConfirmacao = CONFIRMACAO_PARAM) => {
	const url = `${FRONTEND_URL}/${routeConfirmacao}/${codigo}`;
	sendEmail({
		to: email,
		subject: 'O seu código de verificação',
		html: `Acesse o seguinte link para confirmar: <a href="${url}">${url}</a>`
	});
};

const mandarEmailNotificacao = async (emailArray, notificacao) => {
	sendEmail({
		to: [emailArray],
		subject: `${notificacao.notificacao_titulo}`,
		html: `Assunto: ${notificacao.notificacao_descricao}.<br>Para mais informações acesse o nosso site: ${FRONTEND_URL}`
	});
}

const mandarEmailReuniaoIniciando = async (emailArray, reuniao) => {
	sendEmail({
		to: [emailArray],
		subject: `${reuniao.reuniao_titulo}`,
		html: `Assunto: ${reuniao.reuniao_assunto}.<br>A reunião vai começar em ${AVISO_REUNIAO_COMECANDO_MIN}, para mais informações acesse o nosso site: ${FRONTEND_URL}/reunioes`
	});
}


const sendEmail = async ({ to, subject, html }) => {
	const mailOptions = {
		from: emailInfo.user,
		to: to,
		subject: subject,
		html: html,
	};

	transporter.sendMail(mailOptions, (error, info) => {
		if (error) {
			console.error(error);
			res.status(500).send(error);
		} else {
			res.status(200).send("E-mail enviado com sucesso.");
		}
	});
};

module.exports = { mandarEmailConfirmacao, mandarEmailNotificacao, mandarEmailReuniaoIniciando };
