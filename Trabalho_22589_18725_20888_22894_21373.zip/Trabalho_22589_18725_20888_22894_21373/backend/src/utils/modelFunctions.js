const { Op } = require('sequelize');
const sequelize = require('sequelize');
const { getInclude, handleError, handleSuccess, printLog } = require('./modelUtils');


const handleResponse = async (res, func) => {
	try {
		const response = await func();
		handleSuccess(res, response);
	} catch (error) {
		handleError(res, error);
	}
};

const SuccessJSON = (data, more = {}) => {
	return { success: true, data, ...(more ? { ...more } : {}) }
}

const ErrorJSON = (errorMessage) => {
	return { success: false, error: errorMessage }
}

const criar = async ({ body, model }) => {
	printLog("criar " + model.name);
	try {
		const response = await model.create(body);
		return SuccessJSON(response);
	} catch (error) {
		return ErrorJSON(error.message);
	}
};

const listar = async ({ body = {}, model, modelosIncluir = [], atributosRemover = [], options = {}, incluirModelosAutomaticamente = true }) => {
	printLog("listar " + model.name);
	try {
		const defaultOptions = {
			where: { ...body },
			include: getInclude(modelosIncluir, model, incluirModelosAutomaticamente),
			attributes: { exclude: atributosRemover },
		}
		const mergedOptions = { ...defaultOptions, ...options };
		const response = await model.findAll(mergedOptions);
		return SuccessJSON(response);
	} catch (error) {
		return ErrorJSON(error.message);
	}
}

const obter = async ({ params, model, identifier, modelosIncluir = [], atributosRemover = [], options = {}, incluirModelosAutomaticamente = true }) => {
	printLog("obter " + model.name);
	try {
		const { id } = params;
		const defaultOptions = {
			where: { [identifier]: id },
			include: getInclude(modelosIncluir, model, incluirModelosAutomaticamente),
			attributes: { exclude: atributosRemover },
		}
		const mergedOptions = { ...defaultOptions, ...options };

		const response = await model.findOne(mergedOptions);
		return SuccessJSON(response);
	} catch (error) {
		return ErrorJSON(error.message);
	}
};

const atualizar = async ({ params, body, model, identifier }) => {
	printLog("atualizar " + model.name);
	try {
		const { id } = params;
		const response = await model.update(
			{ ...body },
			{ where: { [identifier]: id } }
		)
		return SuccessJSON(response);
	} catch (error) {
		return ErrorJSON(error.message);
	}
}

const apagar = async ({ params, model, identifier }) => {
	printLog("apagar " + model.name);
	try {
		const { id } = params;
		const response = await model.destroy({
			where: { [identifier]: id },
		});
		return SuccessJSON(response);
	} catch (error) {
		return ErrorJSON(error.message);
	}
}

const pesquisar = async (req, res, model, identifier, atributosRemover) => {
	printLog("pesquisar " + model.name);
	try {
		const searchTerm = req.body[identifier]
		const response = await model.findAll({
			where: { [identifier]: { [Op.like]: `%${searchTerm}%` } },
			attributes: { exclude: atributosRemover }
		})
		return SuccessJSON(response);
	} catch (error) {
		return ErrorJSON(error.message);
	}
}

const pesquisarExato = async (req, res, model, identifier, atributosRemover) => {
	printLog("pesquisarExato " + model.name);
	try {
		const searchTerm = req.body[identifier]
		if (!searchTerm) return ErrorJSON("Search term não existe", { exists: false });
		const response = await model.findAll({
			where: { [identifier]: searchTerm },
			attributes: { exclude: atributosRemover }
		})
		if (response.length === 0) return ErrorJSON(response, { exists: false });
		return SuccessJSON(response, { exists: true });
	} catch (error) {
		return ErrorJSON(error.message, { exists: false });
	}
}

module.exports = { criar, obter, listar, atualizar, apagar, pesquisar, pesquisarExato, handleResponse, SuccessJSON, ErrorJSON };