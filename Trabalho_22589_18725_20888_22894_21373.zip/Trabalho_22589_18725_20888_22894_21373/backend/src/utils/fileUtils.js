const multer = require('multer');
const path = require('path');
const fs = require('fs');

const storage = multer.diskStorage({
	destination: function (req, file, cb) {
		cb(null, 'src/temp/');
	},
	filename: function (req, file, cb) {
		const extension = path.extname(file.originalname);
		const currentDate = new Date();
		const originalFileName = path.basename(file.originalname, path.extname(file.originalname));
		const formattedDate = currentDate.toISOString().replace(/[-:.TZ]/g, "");
		const newFileName = `${originalFileName}-${formattedDate}${extension}`;
		const absolutePath = path.resolve(__dirname, `../temp/`);
		if (!fs.existsSync(absolutePath))
			fs.mkdirSync(absolutePath, { recursive: true });

		file.absolutePath = path.join(absolutePath, newFileName);

		cb(null, newFileName);
	},
	fileFilter: function (req, file, cb) {
		cb(null, true);
	},
	overwrite: true
});

// Set up multer middleware
const upload = multer({
	storage: storage,
	fileFilter: function (req, file, cb) {
		cb(null, true);
	}
});

module.exports = upload;