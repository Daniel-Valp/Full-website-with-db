const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const { JWT_CONFIG } = require('../data/constants');
const { mandarEmailConfirmacao } = require('./emailUtils');

const createAuthToken = async (res, utilizador) => {
	// codigo abaixo vai ser executado quando o email for verificado
	let token = jwt.sign(
		{
			id: utilizador.utilizador_id,
			tag: utilizador.utilizador_tag,
			email: utilizador.utilizador_email,
			perfil: utilizador.utilizador_perfil,
			imagem: utilizador.utilizador_imagem,
		},
		JWT_CONFIG.PASSWORD_SECRET,
		{
			expiresIn: '30d'
		}
	);
	return res.json({ success: true, token: token });
}

const createEmailVerificationToken = async (utilizador) => {
	const token = jwt.sign(
		{
			id: utilizador.utilizador_id,
			email: utilizador.utilizador_email
		},
		JWT_CONFIG.EMAIL_SECRET,
		{
			expiresIn: '1h'
		}
	);
	mandarEmailConfirmacao(token, utilizador.utilizador_email);
}

const createForgetPasswordConfirmationToken = async (utilizador) => {
	const token = jwt.sign(
		{
			id: utilizador.utilizador_id,
			email: utilizador.utilizador_email
		},
		JWT_CONFIG.FORGET_PASSWORD_SECRET,
		{
			expiresIn: '1h'
		}
	);
	mandarEmailConfirmacao(token, utilizador.utilizador_email, "esqueceu-senha/trocar-senha");
	return token
}

module.exports = { createAuthToken, createEmailVerificationToken, createForgetPasswordConfirmationToken };