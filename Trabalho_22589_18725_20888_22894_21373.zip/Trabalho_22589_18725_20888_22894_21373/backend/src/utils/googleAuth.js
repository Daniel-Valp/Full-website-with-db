const { google } = require('googleapis');
const key = require('../data/googleCredentials.json');

async function DriveApi() {
	try {
		const auth = new google.auth.GoogleAuth({
			credentials: key,
			scopes: ['https://www.googleapis.com/auth/drive'],
		});

		const drive = google.drive({ version: 'v3', auth });
		return drive;
	} catch (error) {
		console.error('Error initializing Google Drive API:', error);
		throw new Error('Error initializing Google Drive API');
	}
}

module.exports = { DriveApi }