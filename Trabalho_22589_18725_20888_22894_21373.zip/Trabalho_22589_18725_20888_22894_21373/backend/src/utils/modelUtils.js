const { IsFunction, getTimeString } = require("./functionUtils");

function modelosAssociados(models) {
	const modelsObject = [];
	Object.keys(models.associations).forEach((key) => {
		const association = models.associations[key];
		modelsObject.push({ model: association.target, as: association.as });
	});
	return Object.values(modelsObject);
}

const handleError = (res, JSON, status = 500) => {
	console.log(JSON)
	res.status(status).json(JSON);
};

const handleSuccess = (res, JSON) => {
	res.json(JSON);
};

const getInclude = (modelosIncluir, model, adicionarModelosAssociados = true) => {
	let include = [];

	if (IsFunction(modelosIncluir)) {
		include = [...modelosIncluir()];

		if (adicionarModelosAssociados) {
			include.push(...modelosAssociados(model));
		}
	} else if (adicionarModelosAssociados) {
		include = modelosAssociados(model);
	}

	return include;
};

const printLog = (log) => {
	console.log(`${getTimeString()} | LOG: ${log}`);
}

module.exports = { modelosAssociados, handleError, handleSuccess, getInclude, printLog };