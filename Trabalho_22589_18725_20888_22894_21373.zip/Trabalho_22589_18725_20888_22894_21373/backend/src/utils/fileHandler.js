const { google } = require('googleapis');
const key = require('../data/googleCredentials.json');
const { DriveApi } = require('./googleAuth');
const fs = require('fs');
const { DRIVE_PARENT_FOLDER } = require('../data/constants');

async function listFile() {
	const drive = await DriveApi();
	try {
		const response = await drive.files.list({
			fields: 'files(id, name)',
		});

		const files = response.data.files;
		return files;
	} catch (error) {
		console.error('Error listing files:', error);
		throw new Error('Error listing files');
	}
}

async function getFile(id) {
	const drive = await DriveApi();
	try {
		const response = await drive.files.get({
			fileId: id,
			alt: 'media',
		});
		return response;
	} catch (error) {
		console.error('Error getting files in folder:', error);
		throw new Error('Error getting files in folder');
	}
}


async function uploadFile(id, file) {
	const drive = await DriveApi();
	try {
		const response = await drive.files.update({
			fileId: id,
			requestBody: {
				name: file.name,
			},
			media: {
				mimeType: file.mimeType,
				body: fs.createReadStream(file.path),
			},
		});
		return response;
	} catch (error) {
		console.error('Error replacing file:', error);
		throw new Error('Error replacing file');
	}
}

async function deleteFile(id) {
	const drive = await DriveApi();
	try {
		const response = await drive.files.delete({
			fileId: id,
		});
		return response;
	} catch (error) {
		console.error('Error deleting file:', error);
		throw new Error('Error deleting file');
	}
}

async function createFile(file) {
	const drive = await DriveApi();
	try {
		const response = await drive.files.create({
			requestBody: {
				name: file.filename,
				parents: [DRIVE_PARENT_FOLDER],
			},
			media: {
				mimeType: file.mimetype,
				body: fs.createReadStream(file.absolutePath),
			},
		});
		return response;
	} catch (error) {
		console.error('Error creating file:', error);
		throw new Error('Error creating file');
	}
}



module.exports = { listFile, createFile, getFile, uploadFile, deleteFile }