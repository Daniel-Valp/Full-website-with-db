function levenshteinDistance(a, b) {
	const m = a.length;
	const n = b.length;
	const dp = [];

	for (let i = 0; i <= m; i++) {
		dp[i] = [];
		dp[i][0] = i;
	}

	for (let j = 0; j <= n; j++) {
		dp[0][j] = j;
	}

	for (let i = 1; i <= m; i++) {
		for (let j = 1; j <= n; j++) {
			if (a[i - 1] === b[j - 1]) {
				dp[i][j] = dp[i - 1][j - 1];
			} else {
				dp[i][j] = Math.min(
					dp[i - 1][j] + 1, // deletion
					dp[i][j - 1] + 1, // insertion
					dp[i - 1][j - 1] + 1 // substitution
				);
			}
		}
	}

	return dp[m][n];
}

function IsFunction(func) {
	if (typeof func === 'function')
		return true;
	return false;
}

function getTimeString() {
	const currentDate = new Date();
	const hours = currentDate.getHours().toString().padStart(2, '0');
	const minutes = currentDate.getMinutes().toString().padStart(2, '0');
	const seconds = currentDate.getSeconds().toString().padStart(2, '0');
	return`${hours}:${minutes}:${seconds}`;
}

module.exports = { IsFunction, levenshteinDistance, getTimeString }