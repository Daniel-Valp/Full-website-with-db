const Sequelize = require('sequelize');
module.exports = function (sequelize, DataTypes) {
	return sequelize.define('negociotipoprojetos', {
		negociotipoprojeto_id: {
			autoIncrement: true,
			type: DataTypes.INTEGER,
			allowNull: false,
			primaryKey: true
		},
		negociotipoprojeto_nome: {
			type: DataTypes.STRING(100),
			allowNull: false
		}
	}, {
		sequelize,
		tableName: 'negociotipoprojetos',
		schema: 'public',
		timestamps: false,
		indexes: [
			{
				name: "pk_negociotipoprojetos",
				unique: true,
				fields: [
					{ name: "negociotipoprojeto_id" },
				]
			},
		]
	});
};
