const Sequelize = require('sequelize');
module.exports = function (sequelize, DataTypes) {
	return sequelize.define('candidaturaestados', {
		candidaturaestado_id: {
			autoIncrement: true,
			type: DataTypes.INTEGER,
			allowNull: false,
			primaryKey: true
		},
		candidaturaestado_nome: {
			type: DataTypes.STRING(100),
			allowNull: false
		}
	}, {
		sequelize,
		tableName: 'candidaturaestados',
		schema: 'public',
		timestamps: false,
		indexes: [
			{
				name: "pk_candidaturaestados",
				unique: true,
				fields: [
					{ name: "candidaturaestado_id" },
				]
			},
		]
	});
};
