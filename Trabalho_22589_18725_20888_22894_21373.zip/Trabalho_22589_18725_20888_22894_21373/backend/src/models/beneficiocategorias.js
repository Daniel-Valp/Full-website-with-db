const Sequelize = require('sequelize');
module.exports = function (sequelize, DataTypes) {
	return sequelize.define('beneficiocategorias', {
		beneficiocategoria_id: {
			autoIncrement: true,
			type: DataTypes.INTEGER,
			allowNull: false,
			primaryKey: true
		},
		beneficiocategoria_nome: {
			type: DataTypes.STRING(200),
			allowNull: false
		}
	}, {
		sequelize,
		tableName: 'beneficiocategorias',
		schema: 'public',
		timestamps: false,
		indexes: [
			{
				name: "pk_beneficiocategorias",
				unique: true,
				fields: [
					{ name: "beneficiocategoria_id" },
				]
			},
		]
	});
};
