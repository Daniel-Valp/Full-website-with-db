const Sequelize = require('sequelize');
const { printLog } = require('../utils/modelUtils');
module.exports = function (sequelize, DataTypes) {
	const Vaga = sequelize.define('vagas', {
		vaga_id: {
			autoIncrement: true,
			type: DataTypes.INTEGER,
			allowNull: false,
			primaryKey: true
		},
		vaga_tipo: {
			type: DataTypes.INTEGER,
			allowNull: false,
			references: {
				model: 'vagatipos',
				key: 'vagatipo_id'
			}
		},
		vaga_modalidadecontratacao: {
			type: DataTypes.INTEGER,
			allowNull: false,
			references: {
				model: 'modalidadescontratacao',
				key: 'modalidadecontratacao_id'
			}
		},
		vaga_titulo: {
			type: DataTypes.STRING(500),
			allowNull: false
		},
		vaga_localizacao: {
			type: DataTypes.STRING(500),
			allowNull: false
		},
		vaga_oferecemos: {
			type: DataTypes.TEXT,
			allowNull: false
		},
		vaga_descricao: {
			type: DataTypes.TEXT,
			allowNull: false
		},
		vaga_utilizadorcriou: {
			type: DataTypes.INTEGER,
			allowNull: false,
			references: {
				model: 'utilizadores',
				key: 'utilizador_id'
			}
		},
		vaga_datacriacao: {
			type: DataTypes.DATE,
			allowNull: false,
			defaultValue: Sequelize.Sequelize.fn('now')
		},
		vaga_dataencerrado: {
			type: DataTypes.DATE,
			allowNull: true
		},
		vaga_numerocandidatos: {
			type: DataTypes.INTEGER,
			allowNull: false,
			defaultValue: 1
		}
	}, {
		sequelize,
		tableName: 'vagas',
		schema: 'public',
		timestamps: false,
		indexes: [
			{
				name: "pk_vagas",
				unique: true,
				fields: [
					{ name: "vaga_id" },
				]
			},
		]
	});

	Vaga.afterCreate(async (vaga, options) => {
		printLog("Vaga.afterCreate");
		criarNotificacao(vaga);
	});

	const criarNotificacao = async (vaga) => {
		sequelize.models.notificacoes.create({
			notificacao_titulo: 'Nova vaga disponível: ' + vaga.vaga_titulo,
			notificacao_descricao: vaga.vaga_descricao,
			notificacao_automatica: true,
			notificacao_utilizador: vaga.vaga_utilizadorcriou,
			notificacao_vaga: vaga.vaga_id
		})
			.then(notificacao => {
				return sequelize.models.utilizadores.findAll()
					.then(utilizadores => {
						const notificacaoUtilizadores = utilizadores.map(utilizador => ({
							notificacaoutilizador_utilizador: utilizador.utilizador_id,
							notificacaoutilizador_notificacao: notificacao.notificacao_id
						}));
						return sequelize.models.notificacaoutilizadores.bulkCreate(notificacaoUtilizadores);
					});
			})
			.catch(error => {
				console.error('Erro ao criar a notificação:', error);
			});
	}
	return Vaga;
};
