const Sequelize = require('sequelize');
const { printLog } = require('../utils/modelUtils');
const notificacaoutilizadores = require('./notificacaoutilizadores');
const { mandarEmailNotificacao, mandarEmailReuniaoIniciando } = require('../utils/emailUtils');
const schedule = require('node-schedule');
const { AVISO_REUNIAO_COMECANDO_MIN } = require('../data/constants');

module.exports = function (sequelize, DataTypes) {
	const Reuniao = sequelize.define('reunioes', {
		reuniao_id: {
			autoIncrement: true,
			type: DataTypes.INTEGER,
			allowNull: false,
			primaryKey: true
		},
		reuniao_titulo: {
			type: DataTypes.STRING(500),
			allowNull: false
		},
		reuniao_assunto: {
			type: DataTypes.STRING(1000),
			allowNull: false
		},
		reuniao_datacriacao: {
			type: DataTypes.DATE,
			allowNull: false,
			defaultValue: Sequelize.Sequelize.fn('now')
		},
		reuniao_datainicio: {
			type: DataTypes.DATE,
			allowNull: false
		},
		reuniao_datafim: {
			type: DataTypes.DATE,
			allowNull: true
		},
		reuniao_local: {
			type: DataTypes.STRING(500),
			allowNull: false
		},
		reuniao_utilizadoragendou: {
			type: DataTypes.INTEGER,
			allowNull: false,
			references: {
				model: 'utilizadores',
				key: 'utilizador_id'
			}
		},
		reuniao_candidatura: {
			type: DataTypes.INTEGER,
			allowNull: true,
			references: {
				model: 'candidaturas',
				key: 'candidatura_id'
			}
		},
		reuniao_negocio: {
			type: DataTypes.INTEGER,
			allowNull: true,
			references: {
				model: 'negocios',
				key: 'negocio_id'
			}
		}
	}, {
		sequelize,
		tableName: 'reunioes',
		schema: 'public',
		timestamps: false,
		indexes: [
			{
				name: "pk_reunioes",
				unique: true,
				fields: [
					{ name: "reuniao_id" },
				]
			},
		]
	});

	Reuniao.afterCreate(async (reuniao, options) => {
		printLog("Reuniao.afterCreate");
		await adicionarUtilizadores(reuniao) // quando é criado uma reunião, adicona os utilizadores dos parametros associados à reuniãoutilizadores
			.then(() => agendarInicioReuniao(reuniao))
		await criarNotificacao(reuniao); // quando é criado uma reunião é criada uma notificação
	});

	const criarNotificacao = async (reuniao) => {
		await sequelize.models.notificacoes.create({
			notificacao_titulo: 'Reunião foi agendada: ' + reuniao.reuniao_titulo,
			notificacao_descricao: reuniao.reuniao_assunto,
			notificacao_automatica: true,
			notificacao_utilizador: reuniao.reuniao_utilizadoragendou,
			notificacao_reuniao: reuniao.reuniao_id
		})
			.then(notificacao => {
				return sequelize.models.reuniaoutilizadores.findAll({
					where: { reuniaoutilizador_reuniao: reuniao.reuniao_id },
					include: [
						{
							model: sequelize.models.utilizadores,
							as: "reunutil"
						}
					]
				})
					.then(async reuniaoUtilizadores => {
						const notificacaoUtilizadores = reuniaoUtilizadores.map(reuniaoUtilizador => ({
							notificacaoutilizador_notificacao: notificacao.notificacao_id,
							notificacaoutilizador_utilizador: reuniaoUtilizador.reuniaoutilizador_utilizador
						}));
						return sequelize.models.notificacaoutilizadores.bulkCreate(notificacaoUtilizadores)
							.then(async notificacaoUtilizadores => {
								if (notificacao.notificacao_reuniao) {
									const utilizadorEmailArray = reuniaoUtilizadores.map(item => item.reunutil.utilizador_email);
									mandarEmailNotificacao(utilizadorEmailArray, notificacao);
								} else {
								}
							});

					});
			})
			.catch(error => {
				console.error('Erro ao criar a notificação:', error);
			});
	}

	const adicionarUtilizadores = async (reuniao) => {
		if (reuniao.reuniao_candidatura) {
			const candidatura = await sequelize.models.candidaturas.findOne({
				where: { candidatura_id: reuniao.reuniao_candidatura }
			});
			if (candidatura) {
				await sequelize.models.reuniaoutilizadores.create({
					reuniaoutilizador_reuniao: reuniao.reuniao_id,
					reuniaoutilizador_utilizador: candidatura.candidatura_utilizador
				});
			}
		}
		else if (reuniao.reuniao_negocio) {
			const negocioUtilizadores = await sequelize.models.negocioutilizadores.findAll({
				where: { negocioutilizador_negocio: reuniao.reuniao_negocio }
			});
			if (negocioUtilizadores) {
				const reuniaoUtilizadores = negocioUtilizadores.map((negUtil) => ({
					reuniaoutilizador_reuniao: reuniao.reuniao_id,
					reuniaoutilizador_utilizador: negUtil.negocioutilizador_utilizador
				}));
				await sequelize.models.reuniaoutilizadores.bulkCreate(reuniaoUtilizadores); // adiciona utilizadores associados ao negocio
			}
			const negocio = await sequelize.models.negocios.findOne({
				where: { negocio_id: reuniao.reuniao_negocio }
			});
			if (negocio) { // adiciona utilizador que agendou o negocio
				await sequelize.models.reuniaoutilizadores.create({
					reuniaoutilizador_reuniao: reuniao.reuniao_id,
					reuniaoutilizador_utilizador: negocio.negocio_utilizadorcriou
				});
			}
		}
		await sequelize.models.reuniaoutilizadores.create({
			reuniaoutilizador_reuniao: reuniao.reuniao_id,
			reuniaoutilizador_utilizador: reuniao.reuniao_utilizadoragendou
		});
	}


	async function iniciarReuniao(reuniao, participantesArray) {
		mandarEmailReuniaoIniciando(participantesArray, reuniao);
	}

	async function agendarInicioReuniao(reuniao) {
		const dataInicio = new Date(reuniao.reuniao_datainicio);
		dataInicio.setMinutes(dataInicio.getMinutes() - AVISO_REUNIAO_COMECANDO_MIN);
		if (dataInicio < new Date()) return false;
		const participantes = await sequelize.models.reuniaoutilizadores.findAll({
			where: { reuniaoutilizador_reuniao: reuniao.reuniao_id },
			include: [{ model: sequelize.models.utilizadores, as: "reunutil" }]
		});

		const participantesArray = participantes.map(participante => participante.reunutil.utilizador_email);

		const job = schedule.scheduleJob(dataInicio, () => {
			iniciarReuniao(reuniao, participantesArray);
		});

		console.log(`Reunião '${reuniao.reuniao_titulo}' agendada para iniciar às ${new Date(reuniao.reuniao_datainicio)}\n`);
	}

	async function agendarReunioes() {
		const reunioes = await sequelize.models.reunioes.findAll();
		reunioes.forEach((reuniao) => {
			agendarInicioReuniao(reuniao);
		});
	}

	agendarReunioes();

	return Reuniao;
};
