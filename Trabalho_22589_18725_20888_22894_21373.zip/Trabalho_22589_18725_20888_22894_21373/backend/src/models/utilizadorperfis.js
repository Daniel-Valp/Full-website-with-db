const Sequelize = require('sequelize');
module.exports = function (sequelize, DataTypes) {
	return sequelize.define('utilizadorperfis', {
		utilizadorperfil_id: {
			autoIncrement: true,
			type: DataTypes.INTEGER,
			allowNull: false,
			primaryKey: true
		},
		utilizadorperfil_nome: {
			type: DataTypes.STRING(50),
			allowNull: false
		}
	}, {
		sequelize,
		tableName: 'utilizadorperfis',
		schema: 'public',
		timestamps: false,
		indexes: [
			{
				name: "pk_utilizadorperfis",
				unique: true,
				fields: [
					{ name: "utilizadorperfil_id" },
				]
			},
		]
	});
};
