const Sequelize = require('sequelize');
module.exports = function (sequelize, DataTypes) {
	return sequelize.define('reuniaoutilizadores', {
		reuniaoutilizador_id: {
			autoIncrement: true,
			type: DataTypes.INTEGER,
			allowNull: false,
			primaryKey: true
		},
		reuniaoutilizador_reuniao: {
			type: DataTypes.INTEGER,
			allowNull: false,
			references: {
				model: 'reunioes',
				key: 'reuniao_id'
			}
		},
		reuniaoutilizador_utilizador: {
			type: DataTypes.INTEGER,
			allowNull: false,
			references: {
				model: 'utilizadores',
				key: 'utilizador_id'
			}
		}
	}, {
		sequelize,
		tableName: 'reuniaoutilizadores',
		schema: 'public',
		timestamps: false,
		indexes: [
			{
				name: "pk_reuniaoutilizadores",
				unique: true,
				fields: [
					{ name: "reuniaoutilizador_id" },
				]
			},
		]
	});
};
