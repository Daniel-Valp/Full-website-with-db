const Sequelize = require('sequelize');
module.exports = function (sequelize, DataTypes) {
	return sequelize.define('notificacaoutilizadores', {
		notificacaoutilizador_id: {
			autoIncrement: true,
			type: DataTypes.INTEGER,
			allowNull: false,
			primaryKey: true
		},
		notificacaoutilizador_notificacao: {
			type: DataTypes.INTEGER,
			allowNull: false,
			references: {
				model: 'notificacoes',
				key: 'notificacao_id'
			}
		},
		notificacaoutilizador_utilizador: {
			type: DataTypes.INTEGER,
			allowNull: false,
			references: {
				model: 'utilizadores',
				key: 'utilizador_id'
			}
		},
		notificacaoutilizador_vista: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: false
		}
	}, {
		sequelize,
		tableName: 'notificacaoutilizadores',
		schema: 'public',
		timestamps: false,
		indexes: [
			{
				name: "pk_notificacaoutilizadores",
				unique: true,
				fields: [
					{ name: "notificacaoutilizador_id" },
				]
			},
		]
	});
};
