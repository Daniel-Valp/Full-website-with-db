const Sequelize = require('sequelize');
const bcrypt = require('bcrypt');
module.exports = function (sequelize, DataTypes) {
	const Utilizador = sequelize.define('utilizadores', {
		utilizador_id: {
			autoIncrement: true,
			type: DataTypes.INTEGER,
			allowNull: false,
			primaryKey: true
		},
		utilizador_tag: {
			type: DataTypes.STRING(17),
			allowNull: true,
			unique: "utilizadores_utilizador_tag_key"
		},
		utilizador_descricao: {
			type: DataTypes.STRING(200),
			allowNull: true
		},
		utilizador_nome: {
			type: DataTypes.STRING(100),
			allowNull: false
		},
		utilizador_apelido: {
			type: DataTypes.STRING(100),
			allowNull: false
		},
		utilizador_email: {
			type: DataTypes.STRING(300),
			allowNull: false
		},
		utilizador_password: {
			type: DataTypes.STRING(200),
			allowNull: false,
			set(value) {
				const hashedPassword = bcrypt.hashSync(value, 10);
				this.setDataValue('utilizador_password', hashedPassword);
			},
		},
		utilizador_cidade: {
			type: DataTypes.INTEGER,
			allowNull: true,
			references: {
				model: 'cidades',
				key: 'cidade_id'
			}
		},
		utilizador_escola: {
			type: DataTypes.STRING(250),
			allowNull: true
		},
		utilizador_formacaoacademica: {
			type: DataTypes.STRING(250),
			allowNull: true
		},
		utilizador_perfil: {
			type: DataTypes.INTEGER,
			allowNull: false,
			defaultValue: 6,
			references: {
				model: 'utilizadorperfis',
				key: 'utilizadorperfil_id'
			}
		},
		utilizador_datacriacao: {
			type: DataTypes.DATE,
			allowNull: false,
			defaultValue: Sequelize.Sequelize.fn('now')
		},
		utilizador_linguagem: {
			type: DataTypes.INTEGER,
			allowNull: false,
			defaultValue: 1,
			references: {
				model: 'linguagens',
				key: 'linguagem_id'
			}
		},
		utilizador_imagem: {
			type: DataTypes.STRING(256),
			allowNull: true
		},
		utilizador_confirmada: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: false
		}
	}, {
		sequelize,
		tableName: 'utilizadores',
		schema: 'public',
		timestamps: false,
		indexes: [
			{
				name: "pk_utilizadores",
				unique: true,
				fields: [
					{ name: "utilizador_id" },
				]
			},
			{
				name: "utilizadores_utilizador_tag_key",
				unique: true,
				fields: [
					{ name: "utilizador_tag" },
				]
			},
		]
	});

	return Utilizador;
};
