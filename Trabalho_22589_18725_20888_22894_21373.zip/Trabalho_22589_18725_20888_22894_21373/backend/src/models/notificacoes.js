const Sequelize = require('sequelize');
const { mandarEmailNotificacao } = require('../utils/emailUtils');
const { modelosAssociados, printLog } = require('../utils/modelUtils');
module.exports = function (sequelize, DataTypes) {
	const Notificacao = sequelize.define('notificacoes', {
		notificacao_id: {
			autoIncrement: true,
			type: DataTypes.INTEGER,
			allowNull: false,
			primaryKey: true
		},
		notificacao_titulo: {
			type: DataTypes.STRING(500),
			allowNull: false
		},
		notificacao_descricao: {
			type: DataTypes.STRING(1000),
			allowNull: false
		},
		notificacao_datacriacao: {
			type: DataTypes.DATE,
			allowNull: false,
			defaultValue: Sequelize.Sequelize.fn('now')
		},
		notificacao_nivelurgencia: {
			type: DataTypes.INTEGER,
			allowNull: false,
			defaultValue: 0
		},
		notificacao_automatica: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: false
		},
		notificacao_estado: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: false
		},
		notificacao_utilizador: {
			type: DataTypes.INTEGER,
			allowNull: false,
			references: {
				model: 'utilizadores',
				key: 'utilizador_id'
			}
		},
		notificacao_vaga: {
			type: DataTypes.INTEGER,
			allowNull: true,
			references: {
				model: 'vagas',
				key: 'vaga_id'
			}
		},
		notificacao_negocio: {
			type: DataTypes.INTEGER,
			allowNull: true,
			references: {
				model: 'negocios',
				key: 'negocio_id'
			}
		},
		notificacao_candidatura: {
			type: DataTypes.INTEGER,
			allowNull: true,
			references: {
				model: 'candidaturas',
				key: 'candidatura_id'
			}
		},
		notificacao_ideia: {
			type: DataTypes.INTEGER,
			allowNull: true,
			references: {
				model: 'ideias',
				key: 'ideia_id'
			}
		},
		notificacao_beneficio: {
			type: DataTypes.INTEGER,
			allowNull: true,
			references: {
				model: 'beneficios',
				key: 'beneficio_id'
			}
		},
		notificacao_reuniao: {
			type: DataTypes.INTEGER,
			allowNull: true,
			references: {
				model: 'reunioes',
				key: 'reuniao_id'
			}
		}
	}, {
		sequelize,
		tableName: 'notificacoes',
		schema: 'public',
		timestamps: false,
		indexes: [
			{
				name: "pk_notificacoes",
				unique: true,
				fields: [
					{ name: "notificacao_id" },
				]
			},
		]
	});

	Notificacao.afterCreate(async (notificacao, options) => {
		printLog("Notificacao.afterCreate");
		await adicionarUtilizadores(notificacao);
	});

	const adicionarUtilizadores = async (notificacao) => {
		if (notificacao.notificacao_automatica === true) return false;
		const Utilizadores = await sequelize.models.utilizadores.findAll();

		if (Utilizadores) {
			const notificacaoUtilizadores = Utilizadores.map((utilizador) => ({
				notificacaoutilizador_utilizador: utilizador.utilizador_id,
				notificacaoutilizador_notificacao: notificacao.notificacao_id
			}));
			await sequelize.models.notificacaoutilizadores.bulkCreate(notificacaoUtilizadores);
			const utilizadoresEmails = Utilizadores.map(utilizador => utilizador.utilizador_email);
			mandarEmailNotificacao(utilizadoresEmails, notificacao);
		}
	}

	return Notificacao
};
