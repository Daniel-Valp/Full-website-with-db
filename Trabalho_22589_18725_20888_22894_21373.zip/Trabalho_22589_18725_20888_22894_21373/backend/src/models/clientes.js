const Sequelize = require('sequelize');
module.exports = function (sequelize, DataTypes) {
	return sequelize.define('clientes', {
		cliente_id: {
			autoIncrement: true,
			type: DataTypes.INTEGER,
			allowNull: false,
			primaryKey: true
		},
		cliente_empresa: {
			type: DataTypes.STRING(200),
			allowNull: false
		},
		cliente_datacriacao: {
			type: DataTypes.DATE,
			allowNull: false,
			defaultValue: Sequelize.Sequelize.fn('now')
		},
		cliente_telefone: {
			type: DataTypes.CHAR(9),
			allowNull: true
		},
		cliente_email: {
			type: DataTypes.STRING(200),
			allowNull: true
		},
		cliente_nif: {
			type: DataTypes.CHAR(9),
			allowNull: true
		}
	}, {
		sequelize,
		tableName: 'clientes',
		schema: 'public',
		timestamps: false,
		indexes: [
			{
				name: "pk_clientes",
				unique: true,
				fields: [
					{ name: "cliente_id" },
				]
			},
		]
	});
};
