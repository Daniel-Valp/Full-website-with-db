const Sequelize = require('sequelize');
const { printLog } = require('../utils/modelUtils');
module.exports = function (sequelize, DataTypes) {
	const Negocio = sequelize.define('negocios', {
		negocio_id: {
			autoIncrement: true,
			type: DataTypes.INTEGER,
			allowNull: false,
			primaryKey: true
		},
		negocio_titulo: {
			type: DataTypes.STRING(500),
			allowNull: false
		},
		negocio_tipoprojeto: {
			type: DataTypes.INTEGER,
			allowNull: false,
			references: {
				model: 'negociotipoprojetos',
				key: 'negociotipoprojeto_id'
			}
		},
		negocio_area: {
			type: DataTypes.INTEGER,
			allowNull: false,
			references: {
				model: 'negocioareas',
				key: 'negocioarea_id'
			}
		},
		negocio_utilizadorcriou: {
			type: DataTypes.INTEGER,
			allowNull: false,
			references: {
				model: 'utilizadores',
				key: 'utilizador_id'
			}
		},
		negocio_valorestimado: {
			type: DataTypes.DECIMAL(19, 4),
			allowNull: false
		},
		negocio_necessidades: {
			type: DataTypes.TEXT,
			allowNull: true
		},
		negocio_descricao: {
			type: DataTypes.TEXT,
			allowNull: false
		},
		negocio_motivoperda: {
			type: DataTypes.TEXT,
			allowNull: true
		},
		negocio_estado: {
			type: DataTypes.INTEGER,
			allowNull: false,
			defaultValue: 1,
			references: {
				model: 'negocioestados',
				key: 'negocioestado_id'
			}
		},
		negocio_datacriacao: {
			type: DataTypes.DATE,
			allowNull: false,
			defaultValue: Sequelize.Sequelize.fn('now')
		},
		negocio_dataencerrado: {
			type: DataTypes.DATE,
			allowNull: true
		}
	}, {
		sequelize,
		tableName: 'negocios',
		schema: 'public',
		timestamps: false,
		indexes: [
			{
				name: "pk_negocios",
				unique: true,
				fields: [
					{ name: "negocio_id" },
				]
			},
		]
	});

	Negocio.afterCreate(async (negocio, options) => {
		printLog("Negocio.afterCreate");
		await criarNotificacao(negocio);
	});

	const criarNotificacao = async (negocio) => {
		const notificacao = await sequelize.models.notificacoes.create({
			notificacao_titulo: 'Um negócio foi criado: ' + negocio.negocio_titulo,
			notificacao_descricao: negocio.negocio_descricao,
			notificacao_automatica: true,
			notificacao_utilizador: negocio.negocio_utilizadorcriou,
			notificacao_negocio: negocio.negocio_id
		});

		const Utilizadores = await sequelize.models.utilizadores.findAll({
			where: { utilizador_perfil: 4 }
		});

		if (Utilizadores) {
			const notificacaoUtilizadores = Utilizadores.map((utilizador) => ({
				notificacaoutilizador_utilizador: utilizador.utilizador_id,
				notificacaoutilizador_notificacao: notificacao.notificacao_id
			}));
			await sequelize.models.notificacaoutilizadores.bulkCreate(notificacaoUtilizadores);
		}
	}

	return Negocio;
};
