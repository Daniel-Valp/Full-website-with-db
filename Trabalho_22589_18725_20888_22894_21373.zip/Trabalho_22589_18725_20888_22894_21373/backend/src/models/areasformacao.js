const Sequelize = require('sequelize');
module.exports = function (sequelize, DataTypes) {
	return sequelize.define('areasformacao', {
		areaformacao_id: {
			autoIncrement: true,
			type: DataTypes.INTEGER,
			allowNull: false,
			primaryKey: true
		},
		areaformacao_nome: {
			type: DataTypes.STRING(100),
			allowNull: false
		}
	}, {
		sequelize,
		tableName: 'areasformacao',
		schema: 'public',
		timestamps: false,
		indexes: [
			{
				name: "pk_areasformacao",
				unique: true,
				fields: [
					{ name: "areaformacao_id" },
				]
			},
		]
	});
};
