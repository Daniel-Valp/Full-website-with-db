const Sequelize = require('sequelize');
module.exports = function (sequelize, DataTypes) {
	return sequelize.define('negocioestados', {
		negocioestado_id: {
			autoIncrement: true,
			type: DataTypes.INTEGER,
			allowNull: false,
			primaryKey: true
		},
		negocioestado_nome: {
			type: DataTypes.STRING(100),
			allowNull: false
		}
	}, {
		sequelize,
		tableName: 'negocioestados',
		schema: 'public',
		timestamps: false,
		indexes: [
			{
				name: "pk_negocioestados",
				unique: true,
				fields: [
					{ name: "negocioestado_id" },
				]
			},
		]
	});
};
