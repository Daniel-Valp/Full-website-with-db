const Sequelize = require('sequelize');
const { printLog } = require('../utils/modelUtils');
module.exports = function (sequelize, DataTypes) {
	const Candidatura = sequelize.define('candidaturas', {
		candidatura_id: {
			autoIncrement: true,
			type: DataTypes.INTEGER,
			allowNull: false,
			primaryKey: true
		},
		candidatura_datacriacao: {
			type: DataTypes.DATE,
			allowNull: false,
			defaultValue: Sequelize.Sequelize.fn('now')
		},
		candidatura_estado: {
			type: DataTypes.INTEGER,
			allowNull: false,
			defaultValue: 1,
			references: {
				model: 'candidaturaestados',
				key: 'candidaturaestado_id'
			}
		},
		candidatura_descricao: {
			type: DataTypes.TEXT,
			allowNull: false
		},
		candidatura_vaga: {
			type: DataTypes.INTEGER,
			allowNull: false,
			references: {
				model: 'vagas',
				key: 'vaga_id'
			}
		},
		candidatura_utilizador: {
			type: DataTypes.INTEGER,
			allowNull: false,
			references: {
				model: 'utilizadores',
				key: 'utilizador_id'
			}
		},
		candidatura_curriculum: {
			type: DataTypes.STRING(256),
			allowNull: true
		},
		candidatura_dataencerrado: {
			type: DataTypes.DATE,
			allowNull: true
		}
	}, {
		sequelize,
		tableName: 'candidaturas',
		schema: 'public',
		timestamps: false,
		indexes: [
			{
				name: "pk_candidaturas",
				unique: true,
				fields: [
					{ name: "candidatura_id" },
				]
			},
		]
	});

	Candidatura.afterCreate(async (candidatura, options) => {
		printLog("Candidatura.afterCreate");
		await criarNotificacao(candidatura);
	});

	const criarNotificacao = async (candidatura) => {
		const notificacao = await sequelize.models.notificacoes.create({
			notificacao_titulo: 'Nova candidatura do ' + candidatura.candidatura_utilizador,
			notificacao_descricao: candidatura.candidatura_descricao,
			notificacao_automatica: true,
			notificacao_utilizador: candidatura.candidatura_utilizador,
			notificacao_candidatura: candidatura.candidatura_id
		});

		const Utilizadores = await sequelize.models.utilizadores.findAll({
			where: { utilizador_perfil: 2 }
		});

		if (Utilizadores) {
			const notificacaoUtilizadores = Utilizadores.map((utilizador) => ({
				notificacaoutilizador_utilizador: utilizador.utilizador_id,
				notificacaoutilizador_notificacao: notificacao.notificacao_id
			}));
			await sequelize.models.notificacaoutilizadores.bulkCreate(notificacaoUtilizadores);
		}
	}

	return Candidatura;
};
