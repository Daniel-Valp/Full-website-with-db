const Sequelize = require('sequelize');
module.exports = function (sequelize, DataTypes) {
	return sequelize.define('negocioutilizadores', {
		negocioutilizador_id: {
			autoIncrement: true,
			type: DataTypes.INTEGER,
			allowNull: false,
			primaryKey: true
		},
		negocioutilizador_negocio: {
			type: DataTypes.INTEGER,
			allowNull: false,
			references: {
				model: 'negocios',
				key: 'negocio_id'
			}
		},
		negocioutilizador_utilizador: {
			type: DataTypes.INTEGER,
			allowNull: false,
			references: {
				model: 'utilizadores',
				key: 'utilizador_id'
			}
		}
	}, {
		sequelize,
		tableName: 'negocioutilizadores',
		schema: 'public',
		timestamps: false,
		indexes: [
			{
				name: "pk_negocioutilizadores",
				unique: true,
				fields: [
					{ name: "negocioutilizador_id" },
				]
			},
		]
	});
};
