const Sequelize = require('sequelize');
const { printLog } = require('../utils/modelUtils');
module.exports = function (sequelize, DataTypes) {
	const Beneficio = sequelize.define('beneficios', {
		beneficio_id: {
			autoIncrement: true,
			type: DataTypes.INTEGER,
			allowNull: false,
			primaryKey: true
		},
		beneficio_datacriacao: {
			type: DataTypes.DATE,
			allowNull: false,
			defaultValue: Sequelize.Sequelize.fn('now')
		},
		beneficio_titulo: {
			type: DataTypes.STRING(500),
			allowNull: false
		},
		beneficio_categoria: {
			type: DataTypes.INTEGER,
			allowNull: false,
			references: {
				model: 'beneficiocategorias',
				key: 'beneficiocategoria_id'
			}
		},
		beneficio_descricao: {
			type: DataTypes.TEXT,
			allowNull: false
		},
		beneficio_utilizadorcriou: {
			type: DataTypes.INTEGER,
			allowNull: false,
			references: {
				model: 'utilizadores',
				key: 'utilizador_id'
			}
		},
		beneficio_imagem: {
			type: DataTypes.STRING(256),
			allowNull: true
		}
	}, {
		sequelize,
		tableName: 'beneficios',
		schema: 'public',
		timestamps: false,
		indexes: [
			{
				name: "pk_beneficios",
				unique: true,
				fields: [
					{ name: "beneficio_id" },
				]
			},
		]
	});

	Beneficio.afterCreate(async (beneficio, options) => {
		printLog("Beneficio.afterCreate");
		await criarNotificacao(beneficio);
	});

	const criarNotificacao = async (beneficio) => {
		const notificacao = await sequelize.models.notificacoes.create({
			notificacao_titulo: 'Um benefício foi adicionado: ' + beneficio.beneficio_titulo,
			notificacao_descricao: beneficio.beneficio_descricao,
			notificacao_automatica: true,
			notificacao_utilizador: beneficio.beneficio_utilizadorcriou,
			notificacao_beneficio: beneficio.beneficio_id
		});

		const Utilizadores = await sequelize.models.utilizadores.findAll();

		if (Utilizadores) {
			const notificacaoUtilizadores = Utilizadores.map((utilizador) => ({
				notificacaoutilizador_utilizador: utilizador.utilizador_id,
				notificacaoutilizador_notificacao: notificacao.notificacao_id
			}));
			await sequelize.models.notificacaoutilizadores.bulkCreate(notificacaoUtilizadores);
		}
	};

	return Beneficio;
};
