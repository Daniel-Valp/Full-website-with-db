const Sequelize = require('sequelize');
module.exports = function (sequelize, DataTypes) {
	return sequelize.define('vagatipos', {
		vagatipo_id: {
			autoIncrement: true,
			type: DataTypes.INTEGER,
			allowNull: false,
			primaryKey: true
		},
		vagatipo_nome: {
			type: DataTypes.STRING(100),
			allowNull: false
		}
	}, {
		sequelize,
		tableName: 'vagatipos',
		schema: 'public',
		timestamps: false,
		indexes: [
			{
				name: "fk_vagatipos",
				unique: true,
				fields: [
					{ name: "vagatipo_id" },
				]
			},
		]
	});
};
