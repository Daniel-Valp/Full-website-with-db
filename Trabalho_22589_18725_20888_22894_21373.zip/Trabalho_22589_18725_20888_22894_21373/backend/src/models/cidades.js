const Sequelize = require('sequelize');
module.exports = function (sequelize, DataTypes) {
	return sequelize.define('cidades', {
		cidade_id: {
			autoIncrement: true,
			type: DataTypes.INTEGER,
			allowNull: false,
			primaryKey: true
		},
		cidade_nome: {
			type: DataTypes.STRING(100),
			allowNull: false
		},
		cidade_pais: {
			type: DataTypes.INTEGER,
			allowNull: false,
			references: {
				model: 'paises',
				key: 'pais_id'
			}
		}
	}, {
		sequelize,
		tableName: 'cidades',
		schema: 'public',
		timestamps: false,
		indexes: [
			{
				name: "pk_cidades",
				unique: true,
				fields: [
					{ name: "cidade_id" },
				]
			},
		]
	});
};
