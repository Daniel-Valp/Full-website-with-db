const Sequelize = require('sequelize');
module.exports = function (sequelize, DataTypes) {
	return sequelize.define('grausacademicos', {
		grauacademico_id: {
			autoIncrement: true,
			type: DataTypes.INTEGER,
			allowNull: false,
			primaryKey: true
		},
		grauacademico_nome: {
			type: DataTypes.STRING(100),
			allowNull: false
		}
	}, {
		sequelize,
		tableName: 'grausacademicos',
		schema: 'public',
		timestamps: false,
		indexes: [
			{
				name: "pk_grausacademicos",
				unique: true,
				fields: [
					{ name: "grauacademico_id" },
				]
			},
		]
	});
};
