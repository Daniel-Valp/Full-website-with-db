const Sequelize = require('sequelize');
module.exports = function (sequelize, DataTypes) {
	return sequelize.define('ideiaestados', {
		ideiaestado_id: {
			autoIncrement: true,
			type: DataTypes.INTEGER,
			allowNull: false,
			primaryKey: true
		},
		ideiaestado_nome: {
			type: DataTypes.STRING(100),
			allowNull: false
		}
	}, {
		sequelize,
		tableName: 'ideiaestados',
		schema: 'public',
		timestamps: false,
		indexes: [
			{
				name: "pk_ideiaestados",
				unique: true,
				fields: [
					{ name: "ideiaestado_id" },
				]
			},
		]
	});
};
