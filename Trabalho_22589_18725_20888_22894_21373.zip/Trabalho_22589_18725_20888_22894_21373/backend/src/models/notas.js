const Sequelize = require('sequelize');
module.exports = function (sequelize, DataTypes) {
	return sequelize.define('notas', {
		nota_id: {
			autoIncrement: true,
			type: DataTypes.INTEGER,
			allowNull: false,
			primaryKey: true
		},
		nota_titulo: {
			type: DataTypes.STRING(500),
			allowNull: true
		},
		nota_descricao: {
			type: DataTypes.TEXT,
			allowNull: true
		},
		nota_classificacao: {
			type: DataTypes.SMALLINT,
			allowNull: true
		},
		nota_reuniao: {
			type: DataTypes.INTEGER,
			allowNull: false,
			references: {
				model: 'reunioes',
				key: 'reuniao_id'
			}
		},
		nota_utilizador: {
			type: DataTypes.INTEGER,
			allowNull: false,
			references: {
				model: 'utilizadores',
				key: 'utilizador_id'
			}
		},
		nota_datacriacao: {
			type: DataTypes.DATE,
			allowNull: false,
			defaultValue: Sequelize.Sequelize.fn('now')
		}
	}, {
		sequelize,
		tableName: 'notas',
		schema: 'public',
		timestamps: false,
		indexes: [
			{
				name: "pk_notas",
				unique: true,
				fields: [
					{ name: "nota_id" },
				]
			},
		]
	});
};
