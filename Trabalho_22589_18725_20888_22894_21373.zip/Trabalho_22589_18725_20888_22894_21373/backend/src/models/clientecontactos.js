const Sequelize = require('sequelize');
module.exports = function (sequelize, DataTypes) {
	return sequelize.define('clientecontactos', {
		clientecontacto_id: {
			autoIncrement: true,
			type: DataTypes.INTEGER,
			allowNull: false,
			primaryKey: true
		},
		clientecontacto_cliente: {
			type: DataTypes.INTEGER,
			allowNull: false,
			references: {
				model: 'clientes',
				key: 'cliente_id'
			}
		},
		clientecontacto_nome: {
			type: DataTypes.STRING(150),
			allowNull: false
		},
		clientecontacto_cargo: {
			type: DataTypes.STRING(100),
			allowNull: false
		},
		clientecontacto_telefone: {
			type: DataTypes.CHAR(9),
			allowNull: true
		},
		clientecontacto_email: {
			type: DataTypes.STRING(200),
			allowNull: true
		}
	}, {
		sequelize,
		tableName: 'clientecontactos',
		schema: 'public',
		timestamps: false,
		indexes: [
			{
				name: "pk_clientecontactos",
				unique: true,
				fields: [
					{ name: "clientecontacto_id" },
				]
			},
		]
	});
};
