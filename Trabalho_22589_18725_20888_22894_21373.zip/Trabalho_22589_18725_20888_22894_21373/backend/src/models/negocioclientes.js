const Sequelize = require('sequelize');
module.exports = function (sequelize, DataTypes) {
	return sequelize.define('negocioclientes', {
		negociocliente_id: {
			autoIncrement: true,
			type: DataTypes.INTEGER,
			allowNull: false,
			primaryKey: true
		},
		negociocliente_negocio: {
			type: DataTypes.INTEGER,
			allowNull: false,
			references: {
				model: 'negocios',
				key: 'negocio_id'
			}
		},
		negociocliente_cliente: {
			type: DataTypes.INTEGER,
			allowNull: false,
			references: {
				model: 'clientes',
				key: 'cliente_id'
			}
		}
	}, {
		sequelize,
		tableName: 'negocioclientes',
		schema: 'public',
		timestamps: false,
		indexes: [
			{
				name: "pk_negocioclientes",
				unique: true,
				fields: [
					{ name: "negociocliente_id" },
				]
			},
		]
	});
};
