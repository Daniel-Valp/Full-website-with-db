const Sequelize = require('sequelize');
module.exports = function (sequelize, DataTypes) {
	return sequelize.define('recomendacoes', {
		recomendacao_id: {
			autoIncrement: true,
			type: DataTypes.INTEGER,
			allowNull: false,
			primaryKey: true
		},
		recomendacao_datacriacao: {
			type: DataTypes.DATE,
			allowNull: false,
			defaultValue: Sequelize.Sequelize.fn('now')
		},
		recomendacao_motivo: {
			type: DataTypes.STRING(500),
			allowNull: false
		},
		recomendacao_vaga: {
			type: DataTypes.INTEGER,
			allowNull: false,
			references: {
				model: 'vagas',
				key: 'vaga_id'
			}
		},
		recomendacao_utilizadorrecomendado: {
			type: DataTypes.STRING(250),
			allowNull: false
		},
		recomendacao_utilizador: {
			type: DataTypes.INTEGER,
			allowNull: false,
			references: {
				model: 'utilizadores',
				key: 'utilizador_id'
			}
		},
		recomendacao_curriculum: {
			type: DataTypes.STRING(256),
			allowNull: true
		}
	}, {
		sequelize,
		tableName: 'recomendacoes',
		schema: 'public',
		timestamps: false,
		indexes: [
			{
				name: "pk_recomendacoes",
				unique: true,
				fields: [
					{ name: "recomendacao_id" },
				]
			},
		]
	});
};
