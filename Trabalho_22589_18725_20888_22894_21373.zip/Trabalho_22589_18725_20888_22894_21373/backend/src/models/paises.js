const Sequelize = require('sequelize');
module.exports = function (sequelize, DataTypes) {
	return sequelize.define('paises', {
		pais_id: {
			autoIncrement: true,
			type: DataTypes.INTEGER,
			allowNull: false,
			primaryKey: true
		},
		pais_nome: {
			type: DataTypes.STRING(100),
			allowNull: false
		}
	}, {
		sequelize,
		tableName: 'paises',
		schema: 'public',
		timestamps: false,
		indexes: [
			{
				name: "pk_paises",
				unique: true,
				fields: [
					{ name: "pais_id" },
				]
			},
		]
	});
};
