const Sequelize = require('sequelize');
module.exports = function (sequelize, DataTypes) {
	return sequelize.define('utilizadoresinativos', {
		utilizadorinativo_id: {
			autoIncrement: true,
			type: DataTypes.INTEGER,
			allowNull: false,
			primaryKey: true
		},
		utilizadorinativo_utilizador: {
			type: DataTypes.INTEGER,
			allowNull: false,
			references: {
				model: 'utilizadores',
				key: 'utilizador_id'
			}
		},
		utilizadorinativo_motivo: {
			type: DataTypes.STRING(500),
			allowNull: false
		},
		utilizadorinativo_estado: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: true
		},
		utilizadorinativo_datacriacao: {
			type: DataTypes.DATE,
			allowNull: false,
			defaultValue: Sequelize.Sequelize.fn('now')
		},
		utilizadorinativo_dataencerramento: {
			type: DataTypes.DATE,
			allowNull: false,
		}
	}, {
		sequelize,
		tableName: 'utilizadoresinativos',
		schema: 'public',
		timestamps: false,
		indexes: [
			{
				name: "pk_utilizadoresinativos",
				unique: true,
				fields: [
					{ name: "utilizadorinativo_id" },
				]
			},
		]
	});
};
