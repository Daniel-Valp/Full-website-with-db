const Sequelize = require('sequelize');
module.exports = function (sequelize, DataTypes) {
	return sequelize.define('negociointeracoes', {
		negociointeracao_id: {
			autoIncrement: true,
			type: DataTypes.INTEGER,
			allowNull: false,
			primaryKey: true
		},
		negociointeracao_negocio: {
			type: DataTypes.INTEGER,
			allowNull: false,
			references: {
				model: 'negocios',
				key: 'negocio_id'
			}
		},
		negociointeracao_clientecontacto: {
			type: DataTypes.INTEGER,
			allowNull: false,
			references: {
				model: 'clientecontactos',
				key: 'clientecontacto_id'
			}
		},
		negociointeracao_utilizador: {
			type: DataTypes.INTEGER,
			allowNull: false,
			references: {
				model: 'utilizadores',
				key: 'utilizador_id'
			}
		},
		negociointeracao_descricao: {
			type: DataTypes.STRING(500),
			allowNull: false
		},
		negociointeracao_datacriacao: {
			type: DataTypes.DATE,
			allowNull: false,
			defaultValue: Sequelize.Sequelize.fn('now')
		}
	}, {
		sequelize,
		tableName: 'negociointeracoes',
		schema: 'public',
		timestamps: false,
		indexes: [
			{
				name: "pk_negociointeracoes",
				unique: true,
				fields: [
					{ name: "negociointeracao_id" },
				]
			},
		]
	});
};
