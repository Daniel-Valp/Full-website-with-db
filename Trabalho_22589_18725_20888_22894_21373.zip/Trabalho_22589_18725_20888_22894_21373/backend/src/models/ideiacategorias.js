const Sequelize = require('sequelize');
module.exports = function (sequelize, DataTypes) {
	return sequelize.define('ideiacategorias', {
		ideiacategoria_id: {
			autoIncrement: true,
			type: DataTypes.INTEGER,
			allowNull: false,
			primaryKey: true
		},
		ideiacategoria_nome: {
			type: DataTypes.STRING(100),
			allowNull: false
		}
	}, {
		sequelize,
		tableName: 'ideiacategorias',
		schema: 'public',
		timestamps: false,
		indexes: [
			{
				name: "pk_ideiacategorias",
				unique: true,
				fields: [
					{ name: "ideiacategoria_id" },
				]
			},
		]
	});
};
