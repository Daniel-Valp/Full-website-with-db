const Sequelize = require('sequelize');
module.exports = function (sequelize, DataTypes) {
	return sequelize.define('linguagens', {
		linguagem_id: {
			autoIncrement: true,
			type: DataTypes.INTEGER,
			allowNull: false,
			primaryKey: true
		},
		linguagem_nome: {
			type: DataTypes.STRING(100),
			allowNull: false
		}
	}, {
		sequelize,
		tableName: 'linguagens',
		schema: 'public',
		timestamps: false,
		indexes: [
			{
				name: "pk_linguagens",
				unique: true,
				fields: [
					{ name: "linguagem_id" },
				]
			},
		]
	});
};
