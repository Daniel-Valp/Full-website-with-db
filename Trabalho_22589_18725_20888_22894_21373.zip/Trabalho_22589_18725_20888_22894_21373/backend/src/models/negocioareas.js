const Sequelize = require('sequelize');
module.exports = function (sequelize, DataTypes) {
	return sequelize.define('negocioareas', {
		negocioarea_id: {
			autoIncrement: true,
			type: DataTypes.INTEGER,
			allowNull: false,
			primaryKey: true
		},
		negocioarea_nome: {
			type: DataTypes.STRING(100),
			allowNull: false
		}
	}, {
		sequelize,
		tableName: 'negocioareas',
		schema: 'public',
		timestamps: false,
		indexes: [
			{
				name: "pk_negocioareas",
				unique: true,
				fields: [
					{ name: "negocioarea_id" },
				]
			},
		]
	});
};
