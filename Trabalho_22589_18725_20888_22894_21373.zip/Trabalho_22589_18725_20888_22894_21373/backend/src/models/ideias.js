const Sequelize = require('sequelize');
const { printLog } = require('../utils/modelUtils');
module.exports = function (sequelize, DataTypes) {
	const Ideia = sequelize.define('ideias', {
		ideia_id: {
			autoIncrement: true,
			type: DataTypes.INTEGER,
			allowNull: false,
			primaryKey: true
		},
		ideia_titulo: {
			type: DataTypes.STRING(500),
			allowNull: false
		},
		ideia_categoria: {
			type: DataTypes.INTEGER,
			allowNull: false,
			references: {
				model: 'ideiacategorias',
				key: 'ideiacategoria_id'
			}
		},
		ideia_descricao: {
			type: DataTypes.TEXT,
			allowNull: false
		},
		ideia_utilizador: {
			type: DataTypes.INTEGER,
			allowNull: false,
			references: {
				model: 'utilizadores',
				key: 'utilizador_id'
			}
		},
		ideia_estado: {
			type: DataTypes.INTEGER,
			allowNull: false,
			defaultValue: 1,
			references: {
				model: 'ideiaestados',
				key: 'ideiaestado_id'
			}
		},
		ideia_datacriacao: {
			type: DataTypes.DATE,
			allowNull: false,
			defaultValue: Sequelize.Sequelize.fn('now')
		},
		ideia_dataencerrado: {
			type: DataTypes.DATE,
			allowNull: true
		}
	}, {
		sequelize,
		tableName: 'ideias',
		schema: 'public',
		timestamps: false,
		indexes: [
			{
				name: "pk_ideias",
				unique: true,
				fields: [
					{ name: "ideia_id" },
				]
			},
		]
	});

	Ideia.afterCreate(async (ideia, options) => {
		printLog("Ideia.afterCreate");
		await criarNotificacao(ideia);
	});

	const criarNotificacao = async (ideia) => {
		const notificacao = await sequelize.models.notificacoes.create({
			notificacao_titulo: 'Nova ideia lançada: ' + ideia.ideia_titulo,
			notificacao_descricao: ideia.ideia_descricao,
			notificacao_automatica: true,
			notificacao_utilizador: ideia.ideia_utilizador,
			notificacao_ideia: ideia.ideia_id
		});

		const Utilizadores = await sequelize.models.utilizadores.findAll({
			where: { utilizador_perfil: 3 }
		});

		if (Utilizadores) {
			const notificacaoUtilizadores = Utilizadores.map((utilizador) => ({
				notificacaoutilizador_utilizador: utilizador.utilizador_id,
				notificacaoutilizador_notificacao: notificacao.notificacao_id
			}));
			await sequelize.models.notificacaoutilizadores.bulkCreate(notificacaoUtilizadores);
		}
	}

	return Ideia;
};
