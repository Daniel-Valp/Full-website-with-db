const Sequelize = require('sequelize');
module.exports = function (sequelize, DataTypes) {
	return sequelize.define('negocioficheiros', {
		negocioficheiro_id: {
			autoIncrement: true,
			type: DataTypes.INTEGER,
			allowNull: false,
			primaryKey: true
		},
		negocioficheiro_negocio: {
			type: DataTypes.INTEGER,
			allowNull: false,
			references: {
				model: 'negocios',
				key: 'negocio_id'
			}
		},
		negocioficheiro_ficheiro: {
			type: DataTypes.STRING(254),
			allowNull: false
		},
		negocioficheiro_ficheironome: {
			type: DataTypes.STRING(254),
			allowNull: false
		},
		negocioficheiro_datacriacao: {
			type: DataTypes.DATE,
			allowNull: false,
			defaultValue: Sequelize.Sequelize.fn('now')
		}
	}, {
		sequelize,
		tableName: 'negocioficheiros',
		schema: 'public',
		timestamps: false,
		indexes: [
			{
				name: "pk_negocioficheiros",
				unique: true,
				fields: [
					{ name: "negocioficheiro_id" },
				]
			},
		]
	});
};
