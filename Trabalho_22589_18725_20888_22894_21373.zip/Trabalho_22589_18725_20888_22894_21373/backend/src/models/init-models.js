var DataTypes = require("sequelize").DataTypes;
var _utilizadorperfis = require("./utilizadorperfis");
var _paises = require("./paises");
var _cidades = require("./cidades");
var _linguagens = require("./linguagens");
var _utilizadores = require("./utilizadores");
var _utilizadoresinativos = require("./utilizadoresinativos");
var _ideiaestados = require("./ideiaestados");
var _ideiacategorias = require("./ideiacategorias");
var _ideias = require("./ideias");
var _clientes = require("./clientes");
var _clientecontactos = require("./clientecontactos");
var _negocioestados = require("./negocioestados");
var _negocioareas = require("./negocioareas");
var _negociotipoprojetos = require("./negociotipoprojetos");
var _negocios = require("./negocios");
var _negociointeracoes = require("./negociointeracoes");
var _negocioficheiros = require("./negocioficheiros");
var _negocioclientes = require("./negocioclientes");
var _negocioutilizadores = require("./negocioutilizadores");
var _vagatipos = require("./vagatipos");
var _modalidadescontratacao = require("./modalidadescontratacao");
var _vagas = require("./vagas");
var _candidaturaestados = require("./candidaturaestados");
var _grausacademicos = require("./grausacademicos");
var _areasformacao = require("./areasformacao");
var _candidaturas = require("./candidaturas");
var _recomendacoes = require("./recomendacoes");
var _reunioes = require("./reunioes");
var _reuniaoutilizadores = require("./reuniaoutilizadores");
var _notas = require("./notas");
var _notaficheiros = require("./notaficheiros");
var _beneficiocategorias = require("./beneficiocategorias");
var _beneficios = require("./beneficios");
var _notificacoes = require("./notificacoes");
var _notificacaoutilizadores = require("./notificacaoutilizadores");

function defineAssociation(childModel, parentModel, asKeyword, foreignKeyKeyword) {
	childModel.belongsTo(parentModel, { as: asKeyword, foreignKey: foreignKeyKeyword, onDelete: 'CASCADE', onUpdate: 'CASCADE' });
	parentModel.hasMany(childModel, { as: asKeyword, foreignKey: foreignKeyKeyword, onDelete: 'CASCADE', onUpdate: 'CASCADE' });
}

function initModels(sequelize) {
	var utilizadorperfis = _utilizadorperfis(sequelize, DataTypes);
	var paises = _paises(sequelize, DataTypes);
	var cidades = _cidades(sequelize, DataTypes);
	var linguagens = _linguagens(sequelize, DataTypes);
	var utilizadores = _utilizadores(sequelize, DataTypes);
	var utilizadoresinativos = _utilizadoresinativos(sequelize, DataTypes);
	var ideiaestados = _ideiaestados(sequelize, DataTypes);
	var ideiacategorias = _ideiacategorias(sequelize, DataTypes);
	var ideias = _ideias(sequelize, DataTypes);
	var clientes = _clientes(sequelize, DataTypes);
	var clientecontactos = _clientecontactos(sequelize, DataTypes);
	var negocioestados = _negocioestados(sequelize, DataTypes);
	var negocioareas = _negocioareas(sequelize, DataTypes);
	var negociotipoprojetos = _negociotipoprojetos(sequelize, DataTypes);
	var negocios = _negocios(sequelize, DataTypes);
	var negociointeracoes = _negociointeracoes(sequelize, DataTypes);
	var negocioficheiros = _negocioficheiros(sequelize, DataTypes);
	var negocioclientes = _negocioclientes(sequelize, DataTypes);
	var negocioutilizadores = _negocioutilizadores(sequelize, DataTypes);
	var vagatipos = _vagatipos(sequelize, DataTypes);
	var modalidadescontratacao = _modalidadescontratacao(sequelize, DataTypes);
	var vagas = _vagas(sequelize, DataTypes);
	var candidaturaestados = _candidaturaestados(sequelize, DataTypes);
	var areasformacao = _areasformacao(sequelize, DataTypes);
	var grausacademicos = _grausacademicos(sequelize, DataTypes);
	var candidaturas = _candidaturas(sequelize, DataTypes);
	var recomendacoes = _recomendacoes(sequelize, DataTypes);
	var reunioes = _reunioes(sequelize, DataTypes);
	var reuniaoutilizadores = _reuniaoutilizadores(sequelize, DataTypes);
	var notas = _notas(sequelize, DataTypes);
	var notaficheiros = _notaficheiros(sequelize, DataTypes);
	var beneficiocategorias = _beneficiocategorias(sequelize, DataTypes);
	var beneficios = _beneficios(sequelize, DataTypes);
	var notificacoes = _notificacoes(sequelize, DataTypes);
	var notificacaoutilizadores = _notificacaoutilizadores(sequelize, DataTypes);


	defineAssociation(notificacoes, beneficios, "notif_benef", "notificacao_beneficio");
	defineAssociation(notificacoes, candidaturas, "notif_cand", "notificacao_candidatura");
	defineAssociation(notificacoes, negocios, "notif_neg", "notificacao_negocio");
	defineAssociation(notificacoes, ideias, "notif_ideia", "notificacao_ideia");
	defineAssociation(notificacoes, reunioes, "notif_reun", "notificacao_reuniao");
	defineAssociation(notificacoes, utilizadores, "notif_util", "notificacao_utilizador");
	defineAssociation(notificacoes, vagas, "notif_vaga", "notificacao_vaga");
	defineAssociation(notificacaoutilizadores, utilizadores, "notifutil", "notificacaoutilizador_utilizador");
	defineAssociation(notificacaoutilizadores, notificacoes, "utilnotif", "notificacaoutilizador_notificacao");
	defineAssociation(candidaturas, utilizadores, "cand_util", "candidatura_utilizador");
	defineAssociation(candidaturas, vagas, "cand_vaga", "candidatura_vaga");
	defineAssociation(candidaturas, candidaturaestados, "cand_estado", "candidatura_estado");
	defineAssociation(candidaturas, areasformacao, "cand_areafor", "candidatura_areaformacao");
	defineAssociation(candidaturas, grausacademicos, "cand_grauacad", "candidatura_grauacademico");
	defineAssociation(negociointeracoes, clientecontactos, "negint_client", "negociointeracao_clientecontacto");
	defineAssociation(negociointeracoes, utilizadores, "negint_util", "negociointeracao_utilizador");
	defineAssociation(negociointeracoes, negocios, "negint_neg", "negociointeracao_negocio");
	defineAssociation(clientecontactos, clientes, "cont_cliente", "clientecontacto_cliente");
	defineAssociation(negocioclientes, clientes, "neg_cli", "negociocliente_cliente");
	defineAssociation(negocioclientes, negocios, "negcl_neg", "negociocliente_negocio");
	defineAssociation(ideias, ideiacategorias, "ideia_cat", "ideia_categoria");
	defineAssociation(ideias, ideiaestados, "ideia_est", "ideia_estado");
	defineAssociation(ideias, utilizadores, "ideia_util", "ideia_utilizador");
	defineAssociation(negocios, negocioareas, "neg_area", "negocio_area");
	defineAssociation(negocios, negocioestados, "neg_estado", "negocio_estado");
	defineAssociation(negocios, negociotipoprojetos, "neg_tipoproj", "negocio_tipoprojeto");
	defineAssociation(negocios, utilizadores, "neg_util", "negocio_utilizadorcriou");
	defineAssociation(negocioficheiros, negocios, "negfich_neg", "negocioficheiro_negocio");
	defineAssociation(notaficheiros, notas, "notafich_nota", "notaficheiro_nota");
	defineAssociation(cidades, paises, "cid_pais", "cidade_pais");
	defineAssociation(notas, reunioes, "nota_reun", "nota_reuniao");
	defineAssociation(notas, utilizadores, "nota_util", "nota_utilizador");
	defineAssociation(beneficios, beneficiocategorias, "beneficio_cat", "beneficio_categoria");
	defineAssociation(beneficios, utilizadores, "benef_util", "beneficio_utilizadorcriou");
	defineAssociation(negocioutilizadores, negocios, "negutil_neg", "negocioutilizador_negocio");
	defineAssociation(negocioutilizadores, utilizadores, "negutil_util", "negocioutilizador_utilizador");
	defineAssociation(reuniaoutilizadores, reunioes, "reunutil_reun", "reuniaoutilizador_reuniao");
	defineAssociation(reuniaoutilizadores, utilizadores, "reunutil", "reuniaoutilizador_utilizador");
	defineAssociation(utilizadoresinativos, utilizadores, "util_inativo", "utilizadorinativo_utilizador");
	defineAssociation(utilizadores, cidades, "util_cidade", "utilizador_cidade");
	defineAssociation(utilizadores, linguagens, "util_ling", "utilizador_linguagem");
	defineAssociation(utilizadores, utilizadorperfis, "util_perfil", "utilizador_perfil");
	defineAssociation(recomendacoes, utilizadores, "recom_util", "recomendacao_utilizador");
	defineAssociation(recomendacoes, vagas, "recom_vaga", "recomendacao_vaga");
	defineAssociation(reunioes, negocios, "reun_neg", "reuniao_negocio");
	defineAssociation(reunioes, utilizadores, "reun_util", "reuniao_utilizadoragendou");
	defineAssociation(reunioes, candidaturas, "reun_cand", "reuniao_candidatura");
	defineAssociation(vagas, utilizadores, "vaga_util", "vaga_utilizadorcriou");
	defineAssociation(vagas, vagatipos, "vaga_tipos", "vaga_tipo");
	defineAssociation(vagas, modalidadescontratacao, "vaga_modal", "vaga_modalidadecontratacao");


	return {
		utilizadorperfis,
		paises,
		cidades,
		linguagens,
		utilizadores,
		utilizadoresinativos,
		ideiaestados,
		ideiacategorias,
		ideias,
		clientes,
		clientecontactos,
		negocioestados,
		negocioareas,
		negociotipoprojetos,
		negocios,
		negociointeracoes,
		negocioficheiros,
		negocioclientes,
		negocioutilizadores,
		vagatipos,
		modalidadescontratacao,
		vagas,
		candidaturaestados,
		grausacademicos,
		areasformacao,
		candidaturas,
		recomendacoes,
		reunioes,
		reuniaoutilizadores,
		notas,
		notaficheiros,
		beneficiocategorias,
		beneficios,
		notificacoes,
		notificacaoutilizadores
	};
}
module.exports = initModels;
module.exports.initModels = initModels;
module.exports.default = initModels;