const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const { PORT } = require('./data/constants');

const crudRoutes = require('./routes/crud.routes');
const fileRoutes = require('./routes/file.routes.js');
const utilizadorRoutes = require('./routes/utilizador.routes.js');
const negocioRoutes = require('./routes/negocio.routes.js');
const clienteRoutes = require('./routes/cliente.routes.js');
const notaRoutes = require('./routes/nota.routes.js');
const reuniaoRoutes = require('./routes/reuniao.routes.js');

/* Configurar CORS */
app.use((req, res, next) => {
	res.header('Access-Control-Allow-Origin', '*');
	res.header('Access-Control-Allow-Headers', 'Authorization, X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Allow-Request-Method');
	res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, DELETE');
	res.header('Allow', 'GET, POST, OPTIONS, PUT, DELETE');
	next();
});

/* Configurações */
app.set('port', PORT);

/* Middlewares */
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

/* Rotas */
app.use('/file', fileRoutes);
app.use('/cliente', crudRoutes({ directory: 'cliente' }), clienteRoutes);
app.use('/cliente/contacto', crudRoutes({ directory: 'clientecontacto' }));
app.use('/beneficio', crudRoutes({ directory: 'beneficio' }));
app.use('/beneficio/categoria', crudRoutes({ directory: 'enum/beneficoocategoria' }));
app.use('/candidatura', crudRoutes({ directory: 'candidatura' }));
app.use('/candidatura/estado', crudRoutes({ directory: 'enum/candidaturaestado' }));
app.use('/candidatura/areaformacao', crudRoutes({ directory: 'enum/areaformacao' }));
app.use('/candidatura/grauacademico', crudRoutes({ directory: 'enum/grauacademico' }));
app.use('/ideia', crudRoutes({ directory: 'ideia' }));
app.use('/ideia/categoria', crudRoutes({ directory: 'enum/ideiacategoria' }));
app.use('/ideia/estado', crudRoutes({ directory: 'enum/ideiaestado' }));
app.use('/negocio', crudRoutes({ directory: 'negocio' }), negocioRoutes);
app.use('/negocio/estado', crudRoutes({ directory: 'enum/negocioestado' }));
app.use('/negocio/tipoprojeto', crudRoutes({ directory: 'enum/negociotipoprojeto' }));
app.use('/negocio/area', crudRoutes({ directory: 'enum/negocioarea' }));
app.use('/negocio/interacao', crudRoutes({ directory: 'enum/negociointeracao' }));
app.use('/negocio/cliente', crudRoutes({ directory: 'negociocliente' }));
app.use('/nota', crudRoutes({ directory: 'nota' }));
app.use('/nota/ficheiro', crudRoutes({ directory: 'notaficheiro' }), notaRoutes);
app.use('/recomendacao', crudRoutes({ directory: 'recomendacao' }));
app.use('/notificacao', crudRoutes({ directory: 'notificacao' }));
app.use('/notificacao/utilizador', crudRoutes({ directory: 'notificacaoutilizador' }));
app.use('/reuniao', crudRoutes({ directory: 'reuniao' }), reuniaoRoutes);
app.use('/reuniao/utilizador', crudRoutes({ directory: 'reuniaoutilizador' }));
app.use('/utilizador', crudRoutes({ directory: 'utilizador' }), utilizadorRoutes);
app.use('/utilizador/perfil', crudRoutes({ directory: 'enum/perfil' }));
app.use('/utilizador/pais', crudRoutes({ directory: 'enum/pais' }));
app.use('/utilizador/cidade', crudRoutes({ directory: 'enum/cidade' }));
app.use('/utilizador/linguagem', crudRoutes({ directory: 'enum/linguagem' }));
app.use('/utilizador/inativo', crudRoutes({ directory: 'enum/inativo' }));
app.use('/vaga', crudRoutes({ directory: 'vaga' }));
app.use('/vaga/tipo', crudRoutes({ directory: 'enum/vagatipo' }));
app.use('/vaga/modalidadecontratacao', crudRoutes({ directory: 'enum/modalidadecontratacao' }));

/* Listen */
app.listen(app.get('port'), () => {
	console.log("Sever aberto na porta: " + PORT)
})