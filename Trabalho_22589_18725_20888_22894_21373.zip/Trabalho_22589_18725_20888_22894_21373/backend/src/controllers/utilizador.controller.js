const db = require('../db/database').models;
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const { JWT_CONFIG } = require('../data/constants')
const { criar, obter, listar, atualizar, apagar, pesquisar, pesquisarExato, handleResponse, SuccessJSON, ErrorJSON } = require('../utils/modelFunctions');
const { modelosAssociados, handleError, printLog, handleSuccess } = require('../utils/modelUtils');
const { createAuthToken, createEmailVerificationToken, createForgetPasswordConfirmationToken } = require('../utils/authUtils');

const controllers = {}
const mainModel = db.utilizadores;
const mainIdentifier = "utilizador_id";
const attributesToRemove = ['utilizador_password']


controllers.create = async (req, res) => {
	handleResponse(res, () => criar({ body: req.body, model: mainModel }));
}

controllers.get = async (req, res) => {
	handleResponse(res, () => obter({ params: req.params, model: mainModel, identifier: mainIdentifier, modelosIncluir: IncludeModels, atributosRemover: attributesToRemove, incluirModelosAutomaticamente: false }));
}

controllers.gettag = async (req, res) => {
	handleResponse(res, () => obter({ params: req.params, model: mainModel, identifier: "utilizador_tag", modelosIncluir: IncludeModelsGET, atributosRemover: attributesToRemove, incluirModelosAutomaticamente: false }));
}

controllers.list = async (req, res) => {
	handleResponse(res, () => listar({ body: req.body, model: mainModel, modelosIncluir: IncludeModels, atributosRemover: attributesToRemove, incluirModelosAutomaticamente: false }))
}

controllers.update = async (req, res) => {
	handleResponse(res, () => atualizar({ params: req.params, body: req.body, model: mainModel, identifier: mainIdentifier }))
}

controllers.delete = async (req, res) => {
	handleResponse(res, () => apagar({ params: req.params, model: mainModel, identifier: mainIdentifier }));
}

controllers.searchGeral = async (req, res) => {
	const values = Object.keys(req.body);
	pesquisar(req, res, mainModel, values[0], attributesToRemove)
}

controllers.searchExactMatch = async (req, res) => {
	const values = Object.keys(req.body);
	handleResponse(res, () =>
		pesquisarExato(req, res, mainModel, values[0], attributesToRemove)
	);
}

controllers.login = async (req, res) => {
	printLog("login");
	try {
		const login = req.body.login;
		const password = req.body.password;
		const utilizador_login = login.startsWith("@") ? 'utilizador_tag' : 'utilizador_email';

		if (!password || !login) {
			return res.status(403).json({ success: false, message: 'Campos em Branco' });
		}

		const utilizador = await mainModel.findOne({
			where: { [utilizador_login]: login },
		})

		if (!utilizador) {
			return res.status(403).json({ success: false, message: 'Utilizador não existe' });
		}
		const isMatch = bcrypt.compareSync(password, utilizador.utilizador_password);
		if (((login === utilizador.utilizador_email) || (login === utilizador.utilizador_tag)) && isMatch) {
			if (utilizador.utilizador_confirmada) { // conta ja foi confirmada
				await createAuthToken(res, utilizador);
			}
			else {
				createEmailVerificationToken(utilizador);
				res.json({ success: true, message: "Email de confirmação enviado" });
			}
		} else {
			res.status(403).json({ success: false, message: 'Dados de autenticação inválidos.' });
		}
	} catch (error) {
		handleError(res, error);
	}
}

controllers.confirmacao = async (req, res) => {
	printLog("confirmacao");
	let token = req.headers['x-access-token'] || req.headers['authorization'];
	if (token && token.startsWith('Bearer '))
		token = token.slice(7, token.length);
	try {
		const decodedToken = jwt.verify(token, JWT_CONFIG.EMAIL_SECRET);

		if (!decodedToken && !decodedToken.id && !decodedToken.email) {
			return res.status(401).json({ message: 'O token não é válido.' });
		}

		const utilizador = await mainModel.findOne({
			where: { utilizador_id: decodedToken.id, utilizador_email: decodedToken.email },
		})

		if (utilizador && !utilizador.utilizador_confirmada) {
			await mainModel.update(
				{ utilizador_confirmada: true },
				{ where: { utilizador_id: decodedToken.id } }
			)
			return await createAuthToken(res, utilizador);
		}
	} catch (error) {
		return res.status(401).json({ message: 'O token não é válido.' });
	}
}

controllers.forgetPasswordEmail = async (req, res) => {
	try {
		printLog("forgetPasswordEmail");
		const { email } = req.body;
		if (!email) {
			return res.status(403).json({ success: false, message: 'Campos em Branco' });
		}

		const utilizador = await mainModel.findOne({
			where: { utilizador_email: email }
		})

		if (!utilizador) {
			return res.status(403).json({ success: false, message: 'Email é inválido' });
		}
		const token = await createForgetPasswordConfirmationToken(utilizador);
		return handleSuccess(res, SuccessJSON({ message: "Email é válido", token: token }));

	} catch (error) {
		handleError(res, error);
	}
}

controllers.forgetPasswordConfirmacao = async (req, res) => {
	printLog("forgetPasswordConfirmacao");
	let token = req.headers['x-access-token'] || req.headers['authorization'];
	if (token && token.startsWith('Bearer '))
		token = token.slice(7, token.length);
	const { utilizador_password } = req.body;
	try {
		const decodedToken = jwt.verify(token, JWT_CONFIG.FORGET_PASSWORD_SECRET);

		if (!decodedToken && !decodedToken.id && !decodedToken.email)
			return res.status(401).json({ message: 'O token não é válido.' });

		const utilizador = await mainModel.findOne({
			where: { utilizador_id: decodedToken.id, utilizador_email: decodedToken.email },
		})

		if (utilizador) {
			const updatedUtilizador = await mainModel.update(
				{ utilizador_password: utilizador_password },
				{ where: { utilizador_id: decodedToken.id } }
			)
			return handleSuccess(res, SuccessJSON({ data: "Email confirmado" }));
		}
		else {
			return handleError(res, ErrorJSON({ data: "Ocorreu algum erro" }));
		}
	} catch (error) {
		return res.status(401).json({ message: 'O token não é válido.' });
	}
}

controllers.dados = async (req, res) => {
	let token = req.headers['x-access-token'] || req.headers['authorization'];
	if (token && token.startsWith('Bearer '))
		token = token.slice(7, token.length);
	try {
		const decodedToken = jwt.verify(token, JWT_CONFIG.PASSWORD_SECRET);
		const userData = {
			id: decodedToken.id,
			tag: decodedToken.tag,
			email: decodedToken.email,
			perfil: decodedToken.perfil,
			imagem: decodedToken.imagem,
		};
		return res.json({ success: true, data: userData });
	} catch (error) {
		return res.status(401).json({ message: 'O token não é válido.' });
	}
}

controllers.refreshToken = async (req, res) => {
	try {
		const token = req.body.token;
		jwt.verify(token, JWT_CONFIG.PASSWORD_SECRET, async (err, decoded) => {
			if (err) {
				res.status(401).json({ success: false, message: 'Invalid refresh token' });
				return;
			}
			const updatedUser = await mainModel.findOne({ where: { utilizador_id: decoded.id }, include: modelosAssociados(mainModel) });
			if (!updatedUser) {
				res.status(404).json({ success: false, message: 'User not found' });
				return;
			}
			const accessToken = jwt.sign(
				{
					id: updatedUser.utilizador_id,
					tag: updatedUser.utilizador_tag,
					email: updatedUser.utilizador_email,
					perfil: updatedUser.utilizador_perfil,
					imagem: updatedUser.utilizador_imagem,
				},
				JWT_CONFIG.PASSWORD_SECRET,
				{
					expiresIn: '30d'
				}
			);
			res.json({ success: true, token: accessToken });
		});
	} catch (error) {
		res.status(500).json({ success: false, error: error.message });
	}
}


function IncludeModels() {
	return [
		{
			model: db.cidades,
			as: 'util_cidade',
			include: [
				{
					model: db.paises,
					as: 'cid_pais',
				}
			]
		},
		{
			model: db.notificacaoutilizadores,
			as: 'notifutil',
			include: [
				{
					model: db.notificacoes,
					as: 'utilnotif',
					include: [
						{ model: db.vagas, as: 'notif_vaga' },
						{ model: db.ideias, as: 'notif_ideia' },
						{ model: db.negocios, as: 'notif_neg' },
						{ model: db.beneficios, as: 'notif_benef' },
						{ model: db.reunioes, as: 'notif_reun' },
						{ model: db.candidaturas, as: 'notif_cand' }
					]
				}
			]
		},
		{
			model: db.utilizadoresinativos,
			as: 'util_inativo'
		}
	];
}

function IncludeModelsGET() {
	return [
		{
			model: db.cidades,
			as: 'util_cidade',
			include: [
				{
					model: db.paises,
					as: 'cid_pais',
				}
			]
		},
		{
			model: db.notificacaoutilizadores,
			as: 'notifutil',
			include: [
				{
					model: db.notificacoes,
					as: 'utilnotif',
					include: [
						{ model: db.vagas, as: 'notif_vaga' },
						{ model: db.ideias, as: 'notif_ideia' },
						{ model: db.negocios, as: 'notif_neg' },
						{ model: db.beneficios, as: 'notif_benef' },
						{ model: db.reunioes, as: 'notif_reun' },
						{ model: db.candidaturas, as: 'notif_cand' }
					]
				}
			]
		},
		{
			model: db.utilizadoresinativos,
			as: 'util_inativo'
		},
		{
			model: db.negocios,
			as: 'neg_util'
		},
		{
			model: db.candidaturas,
			as: 'cand_util'
		},
		{
			model: db.ideias,
			as: 'ideia_util'
		}
	];
}

module.exports = controllers;