const { getFile, listFile, createFile, uploadFile, deleteFile } = require("../utils/fileHandler");
const fs = require('fs');
const { DRIVE_BASE_URL } = require("../data/constants");

const controllers = {}


controllers.create = async (req, res) => {
	try {
		const file = req.file;
		if (!file)
			return res.status(400).send('No file uploaded');
		const response = await createFile(file);
		fs.unlink(file.path, (err) => {
			if (err)
				console.error('Error deleting file:', err);
			else
				console.log('File deleted from the backend:', file.filename);
		});
		res.json({ success: true, message: 'File uploaded successfully!', data: response.data });
	} catch (error) {
		console.error('Error creating file:', error);
		res.status(500).send('Error creating file.');
	}
};

controllers.get = async (req, res) => {
	try {
		const id = req.params.id;
		const imageUrl = DRIVE_BASE_URL + id;
		const htmlImage = `<img src="${imageUrl}" alt="Image">`;
		res.send(htmlImage);
	} catch (error) {
		console.error('Error getting file:', error);
		res.status(500).send('Error getting file');
	}
}

controllers.list = async (req, res) => {
	try {
		const files = await listFile();
		res.json({ success: true, message: 'File listed successfully!', data: files });
	} catch (error) {
		console.error('Error listing files:', error);
		res.status(500).send('Error listing files');
	}
}

controllers.update = async (req, res) => {
	const id = req.params.id;
	const file = req.file;
	try {
		const response = await uploadFile(id, file);
		res.json({ success: true, message: 'File has been replaced successfully', data: response.data });
	} catch (error) {
		console.error('Error updating file:', error);
		res.status(500).send('Error updating file.');
	}
};

controllers.delete = async (req, res) => {
	try {
		const id = req.params.id;
		const response = await deleteFile(id);
		res.json({ success: true, message: 'File has been deleted successfully', data: response.data });
	} catch (error) {
		console.error('Error deleting file:', error);
		res.status(500).send('Error deleting file');
	}
};


module.exports = controllers;