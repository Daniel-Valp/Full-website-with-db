const db = require('../../db/database').models;
const { criar, obter, listar, atualizar, apagar, handleResponse } = require('../../utils/modelFunctions');

const controllers = {}
const mainModel = db.negociotipoprojetos;
const mainIdentifier = "negociotipoprojeto_id";


controllers.create = async (req, res) => {
	handleResponse(res, () => criar({ body: req.body, model: mainModel }));
}

controllers.get = async (req, res) => {
	handleResponse(res, () => obter({ params: req.params, model: mainModel, identifier: mainIdentifier }));
}

controllers.list = async (req, res) => {
	handleResponse(res, () => listar({ body: req.body, model: mainModel }))
}

controllers.update = async (req, res) => {
	handleResponse(res, () => atualizar({ params: req.params, body: req.body, model: mainModel, identifier: mainIdentifier }))
}

controllers.delete = async (req, res) => {
	handleResponse(res, () => apagar({ params: req.params, model: mainModel, identifier: mainIdentifier }));
}


module.exports = controllers;