const db = require('../db/database').models;
const { criar, obter, listar, atualizar, apagar, handleResponse } = require('../utils/modelFunctions');

const controllers = {}
const mainModel = db.notificacaoutilizadores;
const mainIdentifier = "notificacaoutilizador_id";


controllers.create = async (req, res) => {
	handleResponse(res, () => criar({ body: req.body, model: mainModel }));
}

controllers.get = async (req, res) => {
	handleResponse(res, () => obter({ params: req.params, model: mainModel, identifier: mainIdentifier, modelosIncluir: IncludeModels }));
}

controllers.list = async (req, res) => {
	handleResponse(res, () => listar({ body: req.body, model: mainModel, modelosIncluir: IncludeModels }))
}

controllers.update = async (req, res) => {
	handleResponse(res, () => atualizar({ params: req.params, body: req.body, model: mainModel, identifier: mainIdentifier }))
}

controllers.delete = async (req, res) => {
	handleResponse(res, () => apagar({ params: req.params, model: mainModel, identifier: mainIdentifier }));
}

function IncludeModels() {
	return [
		{
			model: db.notificacoes,
			as: 'utilnotif',
			include: [
				{
					model: db.ideias,
					as: 'notif_ideia',
				},
				{
					model: db.vagas,
					as: 'notif_vaga',
				},
				{
					model: db.negocios,
					as: 'notif_neg',
				},
				{
					model: db.candidaturas,
					as: 'notif_cand',
				},
				{
					model: db.beneficios,
					as: 'notif_benef',
				},
				{
					model: db.reunioes,
					as: 'notif_reun',
				}
			]
		},

	];
}


module.exports = controllers;