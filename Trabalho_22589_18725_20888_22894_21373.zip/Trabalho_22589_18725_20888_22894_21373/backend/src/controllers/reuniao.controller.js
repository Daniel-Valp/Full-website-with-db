const db = require('../db/database').models;
const { criar, obter, listar, atualizar, apagar, handleResponse, ErrorJSON, SuccessJSON } = require('../utils/modelFunctions');
const { getInclude, printLog } = require('../utils/modelUtils');

const controllers = {}
const mainModel = db.reunioes;
const mainIdentifier = "reuniao_id";


controllers.create = async (req, res) => {
	handleResponse(res, () => criar({ body: req.body, model: mainModel }));
}

controllers.get = async (req, res) => {
	handleResponse(res, () => obter({ params: req.params, model: mainModel, identifier: mainIdentifier, modelosIncluir: IncludeModels }));
}

controllers.list = async (req, res) => {
	handleResponse(res, () => listar({ body: req.body, model: mainModel, modelosIncluir: IncludeModels }))
}

controllers.listUtilizador = async (req, res) => {
	handleResponse(res, async () => {
		printLog("listarUtilizador " + mainModel.name);
		try {
			const defaultOptions = {
				where: {},
				include: getInclude(IncludeModels, mainModel),
			};
			console.log(defaultOptions)

			if (req.body.id) {
				defaultOptions.where['$reunutil_reun.reuniaoutilizador_utilizador$'] = req.body.id;
			}

			const response = await mainModel.findAll(defaultOptions);
			return SuccessJSON(response);
		} catch (error) {
			return ErrorJSON(error.message);
		}
	})
};

controllers.update = async (req, res) => {
	handleResponse(res, () => atualizar({ params: req.params, body: req.body, model: mainModel, identifier: mainIdentifier }))
}

controllers.delete = async (req, res) => {
	handleResponse(res, () => apagar({ params: req.params, model: mainModel, identifier: mainIdentifier }));
}

function IncludeModels() {
	return [
		{
			model: db.utilizadores,
			as: 'reun_util'
		},
		{
			model: db.reuniaoutilizadores,
			as: 'reunutil_reun',
			include: [
				{
					model: db.utilizadores,
					as: 'reunutil',
				}
			]
		},
		{
			model: db.negocios,
			as: 'reun_neg'
		},
		{
			model: db.candidaturas,
			as: 'reun_cand'
		},
		{
			model: db.notas,
			as: 'nota_reun',
			include: [
				{
					model: db.notaficheiros,
					as: 'notafich_nota',
				},
				{
					model: db.utilizadores,
					as: 'nota_util',
				}
			]
		}
	];
}


module.exports = controllers;