const db = require('../db/database').models;
const { criar, obter, listar, atualizar, apagar, handleResponse, SuccessJSON, ErrorJSON } = require('../utils/modelFunctions');

const controllers = {}
const mainModel = db.negocios;
const mainIdentifier = "negocio_id";


controllers.create = async (req, res) => {
	handleResponse(res, () => criar({ body: req.body, model: mainModel }));
}

controllers.get = async (req, res) => {
	handleResponse(res, () => obter({ params: req.params, model: mainModel, identifier: mainIdentifier, modelosIncluir: IncludeModels }));
}

controllers.list = async (req, res) => {
	handleResponse(res, () => listar({ body: req.body, model: mainModel, modelosIncluir: IncludeModels }))
}

controllers.adicionarUtilizador = async (req, res) => {
	handleResponse(res, () => criar({ body: req.body, model: db.negocioutilizadores }));
}

controllers.update = async (req, res) => {
	handleResponse(res, () => atualizar({ params: req.params, body: req.body, model: mainModel, identifier: mainIdentifier }))
}

controllers.delete = async (req, res) => {
	handleResponse(res, () => apagar({ params: req.params, model: mainModel, identifier: mainIdentifier }));
}

function IncludeModels() {
	return [
		{
			model: db.negocioutilizadores,
			as: 'negutil_neg',
			include: [
				{
					model: db.utilizadores,
					as: 'negutil_util',
				}
			]
		},
		{
			model: db.negocioclientes,
			as: 'negcl_neg',
			include: [
				{
					model: db.clientes,
					as: 'neg_cli',
					include: [
						{
							model: db.clientecontactos,
							as: 'cont_cliente',
						}
					]
				},
			]
		},
		{
			model: db.reunioes,
			as: 'reun_neg',
			include: [
				{
					model: db.utilizadores,
					as: 'reun_util'
				},
				{
					model: db.negocios,
					as: 'reun_neg'
				},
				{
					model: db.candidaturas,
					as: 'reun_cand'
				}
			]
		},
		{
			model: db.negociointeracoes,
			as: 'negint_neg',
			include: [
				{
					model: db.utilizadores,
					as: 'negint_util',
				},
				{
					model: db.clientecontactos,
					as: 'negint_client',
				},
			]
		},
	];
}


module.exports = controllers;