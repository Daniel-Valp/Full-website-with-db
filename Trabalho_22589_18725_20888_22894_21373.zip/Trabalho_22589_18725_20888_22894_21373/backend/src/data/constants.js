const JWT_CONFIG = {
	PASSWORD_SECRET: "trMCqw7EUQn4FwRyiH9w5jW",
	EMAIL_SECRET: "PjC7q2wspXMhgDZ",
	FORGET_PASSWORD_SECRET: "7AXPRpy1rG22ZSG1hamQ"
};

const PORT = process.env.PORT || 3000;

const DRIVE_PARENT_FOLDER = "1Du8VsJnW7MmOcQmVihB-MwKBAHQFCyNH";
const DRIVE_BASE_URL = "https://drive.google.com/uc?export=view&id=";

const emailInfo = {
	user: "pintegrado23@gmail.com",
	pass: "xerqqpeqtpvdkiam",
};

const FRONTEND_URL = "http://localhost:3001";
const CONFIRMACAO_PARAM = "confirmacao"

const DB_CONFIG = {
	DATABASE: 'projeto_integrado_nwgp',
	USERNAME: 'pint',
	PASSWORD: 'G4Ofqv2YuoG35dZkGc4XbyXaXNZkoDzZ',
	HOST: 'dpg-chjtrju7avjd6drfrf10-a.frankfurt-postgres.render.com',
	PORT: '5432',
	DIALECT: 'postgres',
};

const AVISO_REUNIAO_COMECANDO_MIN = 10;

module.exports = {
	JWT_CONFIG,
	PORT,
	DRIVE_PARENT_FOLDER,
	DRIVE_BASE_URL,
	emailInfo,
	FRONTEND_URL,
	CONFIRMACAO_PARAM,
	DB_CONFIG,
	AVISO_REUNIAO_COMECANDO_MIN
};
