import { Link } from "react-router-dom";
import './header.css'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import logo from 'src/assets/images/softinsa-logo.png'
import PopupNotificacao from 'src/components/Pop-up/PopupNotificacao';
import { useData } from "src/api/dataComponents";
import { useAuth } from "src/hooks/useAuth";


function Header() {
	const userData = useAuth();
	var numNotif = 0;
	const utilizadorTag = userData.tag
	const [dataNotificacoes, loading] = useData('/utilizador/get/1');

	LoadNotificacao(); // calcula o número de notificações
	function LoadNotificacao() {
		return (
			<ul className="list-unstyled">
				{dataNotificacoes?.notifutil?.map((item, i) => {
					let url = null;
					numNotif++;
					if (item.utilnotif.notificacao_estado)
						numNotif--;
					if (item.utilnotif.notifvaga.length > 0)
						url = `/vagas/${item.utilnotif.notifvaga.notificacaovaga_vaga}`;
					else if (item.utilnotif.notifideia.length > 0)
						url = `/ideias/${item.utilnotif.notifideia.notificacaoideia_ideia}`;
					else if (item.utilnotif.notifneg.length > 0)
						url = `/negocios/${item.utilnotif.notifneg.notificacaonegocio_negocio}`;
					else if (item.utilnotif.notifbenef.length > 0)
						url = `/beneficios/${item.utilnotif.notifbenef.notificacaobeneficio_beneficio}`;
					else if (item.utilnotif.notifreun.length > 0)
						url = `/reunioes/${item.utilnotif.notifreun.notificacaoreuniao_reuniao}`;
					else
						numNotif--
					return (
						<div key={i}>
							<div className="border-bottom border-dark mt-3" />
							<li className="mt-3">
								{url ? (
									<Link to={url}>
										<h4>{item.utilnotif.notificacao_titulo}</h4>
										<h5>{item.utilnotif.notificacao_descricao}</h5>
									</Link>
								) : (
									<div>
										<h4>{item.utilnotif.notificacao_titulo}</h4>
										<h5>{item.utilnotif.notificacao_descricao}</h5>
									</div>
								)}
							</li>
						</div>
					);
				})}
			</ul>
		);
	}
	return (
		<div className="Header">
			<nav className="navbar navbar-expand-lg navbar-dark fixed-top" id="menusuperior">
				<Link className='navbar-brand' to="/">
					<img src={logo} className="header-logo-size d-inline-block align-top" alt="Logo do Site" />
				</Link>
				<div>
					<div className="navigation">
						<ul className="navbar-nav mr-auto">
							<li className="nav-item">
								<Link className='nav-link' to="/negocios">Negócios</Link>
							</li>
							<li className="nav-item">
								<Link className='nav-link' to="/vagas">Vagas</Link>
							</li>
							<li className="nav-item">
								<Link className='nav-link' to="/ideias">Ideias</Link>
							</li>
							<li className="nav-item">
								<Link className='nav-link' to="/beneficios">Benefícios</Link>
							</li>
						</ul>
					</div>
					<div className="icons">
						<ul className="navbar-nav">
							<li className="nav-item">
								<Link className='text-white nav-link' to="/dashboard">
									<FontAwesomeIcon icon={["fas", "gauge"]} className='FontAwesomeIcons nav-conta' />
								</Link>
							</li>
							<li className="nav-item" to="">
								<Link className='text-white nav-link' to="/calendario">
									<FontAwesomeIcon icon={["fas", "fa-calendar-alt"]} className='FontAwesomeIcons nav-calendario' />
								</Link>
							</li>
							<li className="nav-item">
								<Link className="text-white nav-link">
									<div className="notification-icon">
										<PopupNotificacao
											LoadNotificacao={<LoadNotificacao />}
											trigger={
												<FontAwesomeIcon
													icon={["fas", "fa-bell"]}
													className={`FontAwesomeIcons ${numNotif !== 0 ? 'nav-notificacao' : ''}`}
												/>
											}
										/>
										{numNotif !== 0 && <span className="notification-count">{numNotif}</span>}
									</div>
								</Link>
								<div>
								</div>
							</li>
							<li className="nav-item">
								<Link className='text-white nav-link' to={`/conta/${utilizadorTag}`}>
									<FontAwesomeIcon icon={["fas", "fa-user"]} className='FontAwesomeIcons nav-conta' />
								</Link>
							</li>
						</ul>
					</div>
				</div>
			</nav>
		</div>
	);
}

export default Header;