import React from "react";
import { BrowserRouter as Router, Route, Link, Routes } from "react-router-dom";
import "./footer.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

/** Icons */
import facebookIcon from "src/assets/icons/facebook-icon.png";
import instagramIcon from "src/assets/icons/instagram-icon.png";
import linkedinIcon from "src/assets/icons/linkedin-icon.png";

function Footer() {
	return (
		<footer className="text-center text-white">
			<section className="top-footer mb-4 p-4 pb-0">
				{/* <Link className="text-white footer-element" to="/contactos">
					Contactos
				</Link> */}
				<Link className="text-white footer-element" to="https://www.softinsa.pt/pt/condicoes-de-utilizacao/">
					Condições de utilização
				</Link>
				<Link className="text-white footer-element" to="https://www.softinsa.pt/pt/politica-de-privacidade/">
					Políticas de privacidade
				</Link>
			</section>
			<section className="bottom-footer p-3">
				<Link to="https://www.facebook.com/Softinsa/">
					<img src={facebookIcon} alt="Facebook" className="footer-icons" />
				</Link>
				<Link to="https://www.instagram.com/softinsa/">
					<img src={instagramIcon} alt="Instagram" className="footer-icons" />
				</Link>
				<Link to="https://pt.linkedin.com/company/softinsa">
					<img src={linkedinIcon} alt="LinkedIn" className="footer-icons" />
				</Link>
				<h4 className="text-white">© Softinsa 2023. Todos os direitos reservados</h4>
			</section>
		</footer>
	);
}

export default Footer;
