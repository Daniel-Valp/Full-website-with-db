import { Link, useLocation } from "react-router-dom";
import { toUpperFirstLetter } from "src/utils/functionUtils";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

function RemoveMinusAddsSpace(string) {
	return string.replace(/-/g, " ").replace(/^\w/, (c) => c.toUpperCase());
}

export function Breadcrumb() {
	const backofficeName = "dashboard";
	const location = useLocation();
	const pathnames = location.pathname.split("/").filter((path) => path !== "");
	var isBackoffice = false;
	if (pathnames.some((pathname) => pathname === backofficeName)) isBackoffice = true;

	if (pathnames.length === 0) return null;
	var breadcrumbPath = "";
	return (
		<nav>
			<ol className="d-flex gap-3">
				<li className="d-flex">
					<h5>
						{!isBackoffice && (
							<Link to="/">
								<FontAwesomeIcon icon={["fas", "house"]} />
							</Link>
						)}
						{isBackoffice && (
							<Link to={`/${backofficeName}`}>
								<FontAwesomeIcon icon={["fas", "house-lock"]} />
							</Link>
						)}
					</h5>
				</li>
				{pathnames.map((item, index) => {
					breadcrumbPath += `/${item}`;
					if (item === backofficeName) return false;
					return (
						<li className="d-flex gap-3" key={index}>
							<h5>
								<FontAwesomeIcon icon={["fas", "chevron-right"]} />
							</h5>
							<h5>
								<Link to={breadcrumbPath}>{toUpperFirstLetter(RemoveMinusAddsSpace(item))}</Link>
							</h5>
						</li>
					);
				})}
			</ol>
		</nav>
	);
}
