import { useEffect, useState } from 'react';
import { Outlet } from 'react-router-dom';

/** Components */
import HeaderSidebar from '../Header & Sidebar/header-sidebar';
import Footer from '../Footer/footer';
import { Breadcrumb } from '../Breadcrumb/breadcrumb';

function Layout() {
	return (
		<div className='Layout'>
			<HeaderSidebar />
			<main className='content-wrapper'>
				<Breadcrumb />
				<Outlet />
			</main>
			<Footer />
		</div>
	);
}

export default Layout;