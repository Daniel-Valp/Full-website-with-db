import React, { useState } from "react";
import { Link } from "react-router-dom";
import "./header-sidebar.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import logo from "src/assets/images/softinsa-logo.png";
import { useEffect } from "react";
import { useRef } from "react";
import MenuDropdown from "src/components/OverlayTooltip/menuDropdown";
import { useAuth } from "src/hooks/useAuth";
import { makeImageUrl } from "src/components/Imagens/utilizadorImagem";
import { iconsString, perfisId } from "src/data/constants";
import { myAxios } from "src/lib/axios";
import { UserTemPerfis, getPerfilById } from "src/utils/functionUtils";
import { Pode } from "src/components/Permissoes/Pode";

function SideBarItems({ titulo, icon, route }) {
	return (
		<li key={route} className={"nav-text align-items-center"}>
			<Link to={route}>
				{icon}
				<h4 className="nome-item text-white">{titulo}</h4>
			</Link>
		</li>
	);
}

export default function Header() {
	const [utilizadorEstado, setutilizadorEstado] = useState(0);
	const [sidebar, setSidebar] = useState(false);
	const showSidebar = () => setSidebar(!sidebar);
	const utilizadorAtual = useAuth();
	const sidebarRef = useRef(null);

	const [imagemUrl, setimagemUrl] = useState("");
	const [notificacoesUnseen, setNotificacoesUnseen] = useState(false);

	useEffect(() => {
		const fetchData = async () => {
			if (!utilizadorAtual) return false;
			const options = {
				data: { notificacaoutilizador_utilizador: utilizadorAtual.id },
				method: "post",
			};
			const response = await myAxios({ url: "/notificacao/utilizador/list", ...options });
			const data = response?.data?.data;
			const hasUnseenNotification = data.some((item) => item.notificacaoutilizador_vista === false);
			setNotificacoesUnseen(hasUnseenNotification);
		};

		fetchData();
	}, [utilizadorAtual]);

	useEffect(() => {
		setimagemUrl(utilizadorAtual.imagem);
	}, [utilizadorAtual]);

	useEffect(() => {
		if (!utilizadorAtual) setutilizadorEstado(0);
		else setutilizadorEstado(1);
	}, [utilizadorAtual]);

	useEffect(() => {
		const handleClickOutside = (event) => {
			if (sidebarRef.current && !sidebarRef.current.contains(event.target)) {
				setSidebar(false);
			}
		};

		document.addEventListener("mouseup", handleClickOutside);
		return () => {
			document.removeEventListener("mouseup", handleClickOutside);
		};
	}, []);

	useEffect(() => {
		const handleKeyUp = (event) => {
			if (event.key === "Escape") {
				setSidebar(false);
			}
		};

		window.addEventListener("keyup", handleKeyUp);

		return () => {
			window.removeEventListener("keyup", handleKeyUp);
		};
	}, []);

	const Sidebar = () => (
		<nav className={sidebar ? "nav-menu active" : "nav-menu"} ref={sidebarRef}>
			<ul className="nav-menu-items">
				<li className="navbar-toggle">
					<div className="d-flex align-items-center bars-logo">
						<div className="text-white">
							<FontAwesomeIcon
								icon={["fas", "xmark"]}
								className="FontAwesomeIconsStatic hover-regular"
								onClick={showSidebar}
							/>
						</div>
						<div>
							<Link className="navbar-brand" to="/">
								<img src={logo} className="navbar-logo-size d-inline-block align-top" alt="Logo do Site" />
							</Link>
						</div>
					</div>
				</li>
				<div className="d-flex flex-column justify-content-between item-list">
					<div>
						<SideBarItems
							titulo={"Negócios"}
							route={"/negocios"}
							icon={<FontAwesomeIcon icon={["fas", iconsString.negocios]} className="text-white" />}
						/>
						<SideBarItems
							titulo={"Vagas"}
							route={"/vagas"}
							icon={<FontAwesomeIcon icon={["fas", iconsString.vagas]} className="text-white" />}
						/>
						<Pode se={UserTemPerfis([perfisId.Colaborador, perfisId.GIdeias], utilizadorAtual.perfil)}>
							<SideBarItems
								titulo={"Ideias"}
								route={"/ideias"}
								icon={<FontAwesomeIcon icon={["fas", iconsString.ideias]} className="text-white" />}
							/>
						</Pode>
						<SideBarItems
							titulo={"Benefícios"}
							route={"/beneficios"}
							icon={<FontAwesomeIcon icon={["fas", iconsString.beneficios]} className="text-white" />}
						/>
						<Pode se={UserTemPerfis([perfisId.GNegocios], utilizadorAtual.perfil)}>
							<SideBarItems
								titulo={"Clientes"}
								route={"/clientes"}
								icon={<FontAwesomeIcon icon={["fas", iconsString.clientes]} className="text-white" />}
							/>
						</Pode>
					</div>
					<div>
						{/* <SideBarItems
							titulo={"Contactos"}
							route={"/contactos"}
							icon={<FontAwesomeIcon icon={["fas", iconsString.contactos]} className="text-white" />}
						/> */}
						<Pode se={UserTemPerfis([perfisId.Admin], utilizadorAtual.perfil)}>
							<SideBarItems
								titulo={"Dashboard"}
								route={"/dashboard"}
								icon={<FontAwesomeIcon icon={["fas", iconsString.dashboard]} className="text-white" />}
							/>
						</Pode>
					</div>
				</div>
			</ul>
		</nav>
	);

	const Header = () => (
		<header className="header d-flex justify-content-between align-items-center">
			<div className="d-flex align-items-center bars-logo">
				<div className="menu-bars text-white">
					<FontAwesomeIcon
						icon={["fas", "bars"]}
						className="FontAwesomeIconsStatic hover-regular"
						onClick={showSidebar}
					/>
				</div>
				<div>
					<Link className="navbar-brand" to="/">
						<img src={logo} className="navbar-logo-size d-inline-block align-top" alt="Logo do Site" />
					</Link>
				</div>
			</div>
			<div>
				<ul className="d-flex sem-ponto gap-3 header-items">
					<li className="header-item">
						{utilizadorEstado === 1 && (
							<Link className="text-white" to={"/notificacoes"}>
								<FontAwesomeIcon
									icon={["fas", iconsString.notificacoes]}
									className={`FontAwesomeIconsStatic hover-regular ${
										notificacoesUnseen ? "notification-unseen" : ""
									}`}
								/>
							</Link>
						)}
					</li>
					<li className="header-item">
						{utilizadorEstado === 1 ? (
							<MenuDropdown
								trigger={
									<div className="hover-regular align-items-center cursor-ponteiro d-flex gap-2">
										<div>
											<h4 className="text-white remove-margin-padding">{utilizadorAtual.tag}</h4>
											<Pode se={utilizadorAtual.perfil !== perfisId.Visitante}>
												<h5 className="text-white remove-margin-padding">
													{getPerfilById(utilizadorAtual.perfil)}
												</h5>
											</Pode>
										</div>
										<div>
											<img
												src={makeImageUrl(imagemUrl)}
												alt="Imagem de perfil"
												className="conta-imagem rounded-circle utilizadorIcon"
											/>
											<FontAwesomeIcon
												icon={["fas", "chevron-down"]}
												className="FontAwesomeIconsSmaller text-white"
											/>
										</div>
									</div>
								}
								items={[
									{ nome: "Minha conta", rota: `/conta/${utilizadorAtual.tag}`, icon: iconsString.conta },
									{
										nome: "Editar conta",
										rota: `/conta/${utilizadorAtual.tag}/editar`,
										icon: "pen-to-square",
									},
									{ nome: "Terminar sessão", rota: `/terminar-sessao`, icon: "right-from-bracket" },
									{ nome: "Reuniões", rota: `/reunioes`, icon: iconsString.reunioes, newGroup: true },
									{ nome: "Calendário", rota: `/calendario`, icon: iconsString.calendario },
									{ nome: "Candidaturas", rota: `/candidaturas`, icon: iconsString.candidaturas },
									{ nome: "Recomendações", rota: `/recomendacoes`, icon: iconsString.recomendacoes },
								]}
							/>
						) : (
							<Link className="text-white" to={`/iniciar-sessao`}>
								<FontAwesomeIcon icon={["fas", "user-plus"]} className="FontAwesomeIconsStatic hover-regular" />
							</Link>
						)}
					</li>
				</ul>
			</div>
		</header>
	);

	return (
		<div className="no-select">
			{Header()}
			{Sidebar()}
		</div>
	);
}
