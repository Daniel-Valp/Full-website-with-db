export default function RowFill({ children }) {
	return (
		<div className="d-flex justify-content-between gap-4">
			{children.map(child =>
				<div className='flex-grow-1' style={{ flex: '1 1 0'}}>{child}</div>
			)}
		</div>
	);
}