
export default function BoxData({ children }) {
	return (
		<div className="box-info">
			{children}
		</div>
	);
}