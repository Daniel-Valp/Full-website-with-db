import React from 'react';

export default function Row({ children, ...props }) {
	return (
		<div {...props}>
			<div className="row">
				{children.map(child =>
					<div className="col">{child}</div>
				)}
			</div>
		</div>
	);
}
