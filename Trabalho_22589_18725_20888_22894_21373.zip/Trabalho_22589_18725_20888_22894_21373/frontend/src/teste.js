import React from 'react';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const Teste = () => {
  const handleSuccess = () => {
    toast.success('Action completed successfully!');
  };

  const handleFailure = () => {
    toast.error('Oops, something went wrong!');
  };

  return (
    <div>
      <h1>My App</h1>
      <button onClick={handleSuccess}>Show Success Notification</button>
      <button onClick={handleFailure}>Show Error Notification</button>
      <ToastContainer position="top-right" autoClose={3000} hideProgressBar={true} />
    </div>
  );
};

export default Teste;
