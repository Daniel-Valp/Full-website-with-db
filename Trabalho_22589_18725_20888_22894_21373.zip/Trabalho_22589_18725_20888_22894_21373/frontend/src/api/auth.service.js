import axios from "axios";
import { backendUrl, userAuthLocalStorageItem } from '../data/constants'
import { myAxios } from "src/lib/axios";


class AuthService {
	iniciar_sessao(login, password) {
		return axios
			.post(`${backendUrl}/utilizador/login`, { login, password })
			.then(res => {
				try {
					if (res.data.token) {
						localStorage.setItem(userAuthLocalStorageItem, JSON.stringify(res.data));
					}
					return res.data;
				} catch (error) {
					return null;
				}
			}, reason => { throw new Error('Utilizador Inválido'); });
	}
	terminar_sessao() {
		localStorage.removeItem(userAuthLocalStorageItem);
	}
	getCurrentUser() {
		const permissoes = { isAdmin: false, isRH: false, isGIdeias: false, isGNegocios: false, isColaborador: false, isCandidato: false, isVisitante: false }
		try {
			const user = this.getToken()
			if (!user && !user.token)
				return false;
			return new Promise((resolve, reject) => {
				axios.get(`${backendUrl}/utilizador/dados`, { headers: { Authorization: `Bearer ${user.token}` } })
					.then(response => {
						const data = response.data.data;
						if (data.perfil === 1)
							permissoes.isAdmin = true
						if (data.perfil === 2)
							permissoes.isRH = true
						if (data.perfil === 3)
							permissoes.isGIdeias = true
						if (data.perfil === 4)
							permissoes.isGNegocios = true
						if (data.perfil === 5)
							permissoes.isColaborador = true
						if (data.perfil === 6)
							permissoes.isCandidato = true
						if (data.perfil === 7)
							permissoes.isVisitante = true
						resolve({
							id: data.id,
							tag: data.tag,
							email: data.email,
							perfil: data.perfil,
							imagem: data.imagem,
							permissoes,
						});
					})
					.catch(error => {
						reject(error);
					});
			});
		} catch (error) {
			return false;
		}
	}
	confirmarUtilizador(token) {
		try {
			if (!token)
				return false;
			return new Promise((resolve, reject) => {
				axios.get(`${backendUrl}/utilizador/confirmacao`, { headers: { Authorization: `Bearer ${token}` } })
					.then(response => {
						if (response.data.token) {
							localStorage.setItem(userAuthLocalStorageItem, JSON.stringify(response.data));
						}
						resolve(response.data);
					})
					.catch(error => {
						reject(null);
					});
			});
		} catch (error) {
			return false;
		}
	}
	refreshAuth() {
		const token = this.getToken().token
		return axios
			.post(`${backendUrl}/utilizador/auth/refresh`, { token })
			.then(res => {
				try {
					if (res.data.token) {
						localStorage.setItem(userAuthLocalStorageItem, JSON.stringify(res.data));
					}
					return res.data;
				} catch (error) {
					return null;
				}
			}, reason => { throw new Error('Utilizador Inválido'); });
	}
	getToken() {
		return JSON.parse(localStorage.getItem(userAuthLocalStorageItem));
	}
}

export default new AuthService();