import axios from "axios";
import { backendUrl } from "src/data/constants";

export const deleteFile = async (id) => {
	const routePath = `${backendUrl}/file/delete/${id}`;
	return axios
		.get(routePath)
		.then(response => {
			return response;
		})
		.catch(error => {
			console.error(error);
			return error;
		});
};