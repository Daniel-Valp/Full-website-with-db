import axios from "axios";
import { backendUrl } from "src/data/constants";

export const createFile = async (ficheiro) => {
	const routePath = `${backendUrl}/file/create`;
	const formData = new FormData();
	formData.append('file', ficheiro);
	return axios
		.post(routePath, formData, { headers: { 'Content-Type': 'multipart/form-data' } })
		.then(response => {
			return response;
		})
		.catch(error => {
			console.error(error);
			return error;
		});
};