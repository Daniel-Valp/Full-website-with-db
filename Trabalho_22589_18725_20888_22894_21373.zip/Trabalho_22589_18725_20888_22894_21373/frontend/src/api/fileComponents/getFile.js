import axios from "axios";
import { backendUrl } from "src/data/constants";

export const getFile = async (id) => {
	const routePath = `${backendUrl}/file/get/${id}`;
	return axios
		.get(routePath)
		.then(response => {
			return response;
		})
		.catch(error => {
			console.error(error);
			return error;
		});
};