import axios from "axios";
import { backendUrl } from "src/data/constants";

export const listFile = async () => {
	const routePath = `${backendUrl}/file/list`;
	return axios
		.get(routePath)
		.then(response => {
			return response;
		})
		.catch(error => {
			console.error(error);
			return error;
		});
};