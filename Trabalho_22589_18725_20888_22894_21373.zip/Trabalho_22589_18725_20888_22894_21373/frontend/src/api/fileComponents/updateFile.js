import axios from "axios";
import { backendUrl } from "src/data/constants";

export const updateFile = async (id, ficheiro) => {
	const routePath = `${backendUrl}/file/update/${id}`;
	const formData = new FormData();
	formData.append('file', ficheiro);
	return axios
		.get(routePath, formData, { headers: { 'Content-Type': 'multipart/form-data' } })
		.then(response => {
			return response;
		})
		.catch(error => {
			console.error(error);
			return error;
		});
};