import { userAuthLocalStorageItem } from "src/data/constants";

export function authHeader() {
	try {
		const user = JSON.parse(localStorage.getItem(userAuthLocalStorageItem));
		if (user && user.token) {
			return { Authorization: 'Bearer ' + user.token };
		} else {
			return {};
		}
	} catch (error) {
		return null;
	}
}