import { useState } from "react";
import { useEffect } from "react";
import authService from "src/api/auth.service";
import { createContext } from "react";


export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
	const [userData, setUserData] = useState(false);

	useEffect(() => {
		const getUserData = async () => {
			try {
				const data = await authService.getCurrentUser();
				setUserData(data);
			} catch (error) {
				console.error('Error fetching user data:', error);
			}
		};
		getUserData();
	}, []);

	return (
		<AuthContext.Provider value={userData}>
			{children}
		</AuthContext.Provider>
	);
}