import { deleteData } from 'src/api/dataComponents';
import Swal from 'sweetalert2/dist/sweetalert2.js'


export function filterDataByAllColumns(data, searchTerm) {
	var filteredData = data;
	if (!searchTerm) return filteredData;

	filteredData = data.filter((item) => {
		return searchItem(item, searchTerm.toLowerCase(), 0);
	});

	return filteredData;
}

function searchItem(item, searchTerm, level) {
	if (level > 2) return false; // Limit search to three levels deep

	for (let key in item) {
		if (item.hasOwnProperty(key)) {
			const columnValue = item[key];
			if (isString(columnValue)) {
				const columnValueLowerCase = columnValue.toLowerCase();
				if (columnValueLowerCase.includes(searchTerm)) {
					return true;
				}
			} else if (isNumber(columnValue)) {
				const columnValueString = columnValue.toString();
				if (columnValueString.includes(searchTerm)) {
					return true;
				}
			} else if (isObject(columnValue)) {
				if (searchItem(columnValue, searchTerm, level + 1)) {
					return true;
				}
			}
		}
	}

	return false;
}

export function filterByComboBox(data, option, campo, defaultValue = -1) {
	var filteredData = data
	if (Number(option) !== defaultValue) {
		filteredData = data.filter(item => {
			if (item[campo] === parseInt(option))
				return true;
			else
				return false;
		});
	}
	return filteredData;
}

export function sortByNumber(data, campo, ascending = false) {
	const sortedData = data.sort((a, b) => {
		const A = Number(a[campo]);
		const B = Number(b[campo]);
		if (ascending)
			return A - B;
		else
			return B - A;
	});

	return sortedData;
}

export function sortByString(data, campo, ascending = false) {
	const sortedData = data.sort((a, b) => {
		const A = a[campo].toString();
		const B = b[campo].toString();
		if (ascending)
			return A - B;
		else
			return B - A;
	});
	return sortedData;
}

export function sortByDate(data, campo, ascending = false) {
	if (!data) return false;
	const sortedData = data.sort((a, b) => {
		const campoA = getFieldByNestedPath(a, campo);
		const campoB = getFieldByNestedPath(b, campo);
		const A = new Date(campoA);
		const B = new Date(campoB);
		if (ascending)
			return A - B;
		else
			return B - A;
	});
	return sortedData;
}

export function filterByDate(data, campo, startDate, endDate) {
	console.log(data)
	return data.filter(item => {
		const nestedField = getFieldByNestedPath(item, campo);
		const itemDate = new Date(nestedField);
		const startDateTime = startDate ? new Date(startDate) : null;
		const endDateTime = endDate ? new Date(endDate) : null;
		if (startDateTime && endDateTime) {
			return itemDate >= startDateTime && itemDate <= endDateTime;
		} else if (startDateTime) {
			return itemDate >= startDateTime;
		} else if (endDateTime) {
			return itemDate <= endDateTime;
		} else {
			return itemDate;
		}
	});
}


export function isNumber(value) {
	return typeof value === 'number';
}

export function isString(value) {
	return typeof value === 'string';
}

export function isFunction(value) {
	return typeof value === 'function';
}

export function isFile(value) {
	return value instanceof File;
}

export function isObject(value) {
	return typeof value === 'object' && value !== null;
}

export function isEmail(value) {
	if (!value) return false;
	const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
	return emailRegex.test(value);
}

export function isURL(value) {
	if (!value) return false;
	const patternRegex = /^(?:https?:\/\/)?[\w.-]+\.[\w.-]+(?:\/[\w.-]*)*\/?$/;
	return patternRegex.test(value);
}

export function getFieldByNestedPath(obj, path, splitter = '.') {
	const nestedFields = path.split(splitter);
	let field = obj;
	for (let nestedField of nestedFields) {
		field = field[nestedField];
		if (typeof field === 'undefined') {
			break;
		}
	}
	return field;
}

export default function ApagarConfirmacao({ route, handleSuccess }) {
	Swal.fire({
		title: 'Apagar',
		text: "Tem certeza que deseja apagar?",
		type: 'warning',
		showCancelButton: true,
		confirmButtonText: 'Confirmar',
		cancelButtonText: 'Cancelar'
	}).then((result) => {
		if (result.value) {
			const response = deleteData(`${route}`);
			if (response) {
				Swal.fire('Apagado!', "Item apagado com sucesso", 'success');
				if (isFunction(handleSuccess)) handleSuccess();
			}
			else
				Swal.fire({ icon: 'error', title: 'Error', text: 'Error 325' });
		}
	})
}