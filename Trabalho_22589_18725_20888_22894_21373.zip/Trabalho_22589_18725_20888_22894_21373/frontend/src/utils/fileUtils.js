import axios from "axios";
import { backendUrl } from "../data/constants";

export async function handleFileChange(file) {
	const formData = new FormData();
	formData.append('file', file);
	axios.post(backendUrl + '/file/upload', formData, {
		headers: {
			'Content-Type': 'multipart/form-data'
		}
	})
		.then(response => {
			return response.data.data.filename;
		})
		.catch(error => {
			return false;
		});
};