import { isFunction } from "./dataManipulation";

const { PopupStatus } = require("src/components/Pop-up/popupStatus");

export function checkCamposInvalidos(...variables) {
	const isInvalido = variables.some((variable) => variable === null || variable === undefined || variable === -1 || variable === false || variable === " " || variable === "");
	if (isInvalido) {
		PopupStatus('Existem campos inválidos', 'warn');
		return true;
	}
	return false;
}

export function checkStatus(status) {
	if (status)
		PopupStatus('Cliente adicionado com sucesso!', 'success');
	else
		PopupStatus('Ocurreu algum erro!', 'error');
}

export function isUserLogged(utilizadorAtual, handleNotLogged = null) {
	if (!utilizadorAtual) {
		PopupStatus("Você não está logado", "warn");
		if (isFunction(handleNotLogged))
			handleNotLogged();
		return false;
	}
	return true;
}
