import { useCarregando } from "src/hooks/useCarregando";
import { isEmail, isFunction } from "./dataManipulation";
const { PopupStatus } = require("src/components/Pop-up/popupStatus");

export async function statusResponse({ asyncFunction, successMessage = null, successMessageIcon = "success", errorMessage = "Ocorreu algum erro!", errorMessageIcon = "error", handleSucess = null, handleError = null }) {
	try {
		const response = await asyncFunction();
		if (response) {
			if (successMessage)
				PopupStatus(successMessage, successMessageIcon);
			if (isFunction(handleSucess))
				handleSucess();
			return response;
		} else {
			throw new Error();
		}
	} catch (error) {
		if (errorMessage)
			console.log(error)
			PopupStatus(errorMessage, errorMessageIcon);
		if (isFunction(handleError))
			handleError();
	}
}

export function checkTag(value, atChar = false) {
	if (!value) {
		PopupStatus("Tag inválida", "warn");
		return false;
	}
	else if (!(value.length >= 3 && value.length <= 16)) {
		PopupStatus("Tag inválida", "warn");
		return false;
	}
	else {
		if (value.startsWith("@") && atChar) {
			value = value.substring(1);
		}
		const regex = /^[a-zA-Z0-9_]+$/;
		if (!regex.test(value)) {
			PopupStatus("Tag inválida", "warn");
			return false;
		}
	}
	return true;
}

export function checkEmail(value) {
	if (!value) {
		PopupStatus("Email inválido", "warn");
		return false;
	}
	else if (!isEmail(value)) {
		PopupStatus("Email inválido", "warn");
		return false;
	}
	return true;
}