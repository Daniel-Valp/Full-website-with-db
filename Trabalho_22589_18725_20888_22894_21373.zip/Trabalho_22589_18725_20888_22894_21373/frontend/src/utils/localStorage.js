import axios from "axios";
import { backendUrl } from "../data/constants";


export async function getUtilizador() {
	const Permissoes = { isAdmin: false, isRH: false, isGIdeias: false, isGNegocios: false, isColaborador: false, isCandidato: false, isVisitante: false }
	const userData = { Id: null, Tag: null, Email: null, Perfil: null };
	try {
		const user = JSON.parse(localStorage.getItem('user'));
		if (!user && !user.token)
			return false;
		return new Promise((resolve, reject) => {
			axios.get(`${backendUrl}/utilizador/dados`, { headers: { Authorization: `Bearer ${user.token}` } })
				.then(response => {
					const data = response.data.data;
					if (data.perfil === 'Administrador')
						Permissoes.isAdmin = true
					if (data.perfil === 'Recursos Humanos')
						Permissoes.isRH = true
					if (data.perfil === 'Gestor Ideias')
						Permissoes.isGIdeias = true
					if (data.perfil === 'Gestor Negócios')
						Permissoes.isGNegocios = true
					if (data.perfil === 'Colaborador')
						Permissoes.isColaborador = true
					if (data.perfil === 'Candidato')
						Permissoes.isCandidato = true
					if (data.perfil === 'Visitante')
						Permissoes.isVisitante = true
					resolve({
						Id: data.id,
						Tag: data.tag,
						Email: data.email,
						Perfil: data.perfil,
						Permissoes,
					});
				})
				.catch(error => {
					reject(error);
				});
		});
	} catch (error) {
		return false;
	}
}