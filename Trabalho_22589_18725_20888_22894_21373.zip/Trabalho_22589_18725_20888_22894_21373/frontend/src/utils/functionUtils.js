import { getFieldByNestedPath } from "./dataManipulation";
import { perfisId, perfisNome } from "src/data/constants";

/** Date's */
export function getMonthNames() {
	return [
		"Janeiro",
		"Fevereiro",
		"Março",
		"Abril",
		"Maio",
		"Junho",
		"Julho",
		"Agosto",
		"Setembro",
		"Outubro",
		"Novembro",
		"Dezembro",
	];
}

export function getWeeDayNames() {
	return [
		"Segunda-feira",
		"Terça-feira",
		"Quarta-feira",
		"Quinta-feira",
		"Sexta-feira",
		"Sabado",
		"Domingo",
	];
}

export function addLeadingZero(value) {
	return value.toString().padStart(2, "0");
}

export function parseDate(date = null) {
	var dateObj;
	if (date === null) dateObj = new Date();
	else dateObj = new Date(date);
	return {
		date: dateObj,
		year: dateObj.getFullYear(),
		monthName: getMonthNames()[dateObj.getMonth()],
		month: addLeadingZero(dateObj.getMonth() + 1),
		week: getWeeDayNames[dateObj.getDay()],
		day: addLeadingZero(dateObj.getDate()),
		hour: addLeadingZero(dateObj.getHours()),
		minute: addLeadingZero(dateObj.getMinutes()),
		second: addLeadingZero(dateObj.getSeconds()),
	};
}

export function getDateDiff(firstDate, secondDate) {
	const date1 = new Date(firstDate);
	const date2 = new Date(secondDate);
	const diff = Math.abs(date1 - date2);

	const millisecondsInSecond = 1000;
	const millisecondsInMinute = millisecondsInSecond * 60;
	const millisecondsInHour = millisecondsInMinute * 60;
	const millisecondsInDay = millisecondsInHour * 24;
	const millisecondsInMonth = millisecondsInDay * 30;
	return {
		year: Math.floor(diff / (millisecondsInDay * 365)),
		month: Math.floor(diff / millisecondsInMonth),
		day: Math.floor(diff / millisecondsInDay),
		hour: Math.floor(diff / millisecondsInHour),
		minute: Math.floor(diff / millisecondsInMinute),
		second: Math.floor(diff / millisecondsInSecond),
		millisecond: diff,
	};
}

export function getStringDateDiff(date, dateFirst = new Date()) {
	const diff = getDateDiff(date, dateFirst);
	const dataCriacao = parseDate(date);
	if (diff.second < 60) return `${diff.second}s`;
	else if (diff.second < 3600) return `${diff.minute}m`;
	else if (diff.second < 86400) return `${diff.hour}h`;
	else if (diff.year === 0)
		return `${dataCriacao.day} de ${toLowerFirstLetter(dataCriacao.monthName)}`;
	else
		return `${dataCriacao.day} de ${toLowerFirstLetter(
			dataCriacao.monthName
		)} de ${dataCriacao.year}`;
}

export function getMonthName(monthNumber) {
	if (monthNumber >= 1 && monthNumber <= 12)
		return getMonthNames()[monthNumber - 1];
	return null;
}

export function formatDayMonthYear(date) {
	return date.day + "/" + date.month + "/" + date.year;
}

export function formatDateTime(date) {
	return formatDayMonthYear(date) + " " + date.hour + ":" + date.minute;
}

export function formatComplete(date) {
	return formatDateTime(date) + ":" + date.second;
}

export function parsedFormatComplete(date) {
	return formatComplete(parseDate(date));
}

export function formatTime(date) {
	return date.hour + ":" + date.minute + ":" + date.second;
}

/** Strings */
export function toUpperFirstLetter(string) {
	return string.charAt(0).toUpperCase() + string.slice(1);
}

export function toLowerFirstLetter(string) {
	return string.charAt(0).toLowerCase() + string.slice(1);
}

export function toUpper(string) {
	return string.toUpperCase();
}

export function toLower(string) {
	return string.toLowerCase();
}

export function generateRandomValue(X = 256) {
	return Math.floor(Math.random() * (X + 1));
}

export function generateNumbers(count) {
	var num = "";
	for (var i = 0; i < count; i++) num += generateRandomValue(9);
	return num;
}

export function generateRandomColor(numColors = 1, trasparencia = 1) {
	const colors = [];
	for (let i = 0; i < numColors; i++)
		colors.push(
			`rgba(${generateRandomValue()}, ${generateRandomValue()}, ${generateRandomValue()}, ${trasparencia})`
		);
	return colors;
}

export function addMapCounter(str, map) {
	if (map.has(str)) {
		const count = map.get(str);
		map.set(str, count + 1);
	} else {
		map.set(str, 1);
	}
}

export function comboBoxOptions(data, id, nome, more) {
	const options = data?.map((item) => {
		let nomeValue = getFieldByNestedPath(item, nome);
		if (more) {
			const nestedValues = getFieldByNestedPath(item, more);
			nomeValue += nestedValues ? ` (${nestedValues})` : "";
		}
		return {
			id: item[id],
			nome: nomeValue,
		};
	});

	return options;
}

export function comboBoxManualLoop(data) {
	if (!data) return null;
	const options = data?.map((item) => {
		return {
			id: item.id,
			nome: item.nome,
		};
	});

	return options;
}

export function comboBoxManualOptions(opcoes) {
	var i = 0;
	const options = opcoes.map((item) => ({
		id: ++i,
		nome: item,
	}));
	return options;
}

export function comboBoxManual(id, opcao) {
	return [
		{
			id: id,
			nome: opcao,
		},
	];
}

export function dropdownSectionOptions(
	option,
	id,
	user,
	action,
	interaction,
	more,
	dateAdded,
	content,
	imgSrc,
	imgAlt = "Imagem em falta."
) {
	option.push({
		id: id,
		user: user,
		action: action,
		interaction: interaction,
		more: more,
		dateAdded: dateAdded,
		content: content,
		imgSrc: imgSrc,
		imgAlt: imgAlt,
	});
	return option;
}

export function formatFile(coluna, ficheiro) {
	const formData = new FormData();
	formData.append([coluna], ficheiro);
	return formData;
}

export function navigateBack() {
	setTimeout(() => {
		window.history.back();
	}, 0);
}

export function removeDateMS(timestamp) {
	if (!timestamp) return null;
	const dotIndex = timestamp.indexOf('.');
	if (dotIndex !== -1)
		timestamp = timestamp.substring(0, dotIndex);
	return timestamp;
}

export const UserTemPerfis = (perfisPermitidos, perfisUtilizador) => {
	if (!perfisUtilizador || !perfisPermitidos) return false;
	if (!perfisPermitidos.includes(perfisId.Admin)) perfisPermitidos.push(perfisId.Admin);
	return perfisPermitidos.includes(perfisUtilizador)
}

export const getPerfilById = (perfilId) => (
	perfisNome[perfilId]
)

export function getFileExtension(fileName) {
	const lastDotIndex = fileName.lastIndexOf(".");
	if (lastDotIndex !== -1) {
		return fileName.substring(lastDotIndex);
	}
	return "";
}


export function clearFileName(str) {
	const parts = str.split("-");
	const fileName = parts[0].trim();
	return fileName;
}
