import React from 'react';
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";

/** Bootstrap */
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import 'bootstrap/dist/js/bootstrap.min.js';

/** Toastify */
import 'react-toastify/dist/ReactToastify.css';
import "react-toastify/dist/ReactToastify.css";

/** Sweet Alert */
import 'sweetalert2/src/sweetalert2.scss'

/** CSS */
import './assets/styles/global.css';

/** Pages */
import PaginaInicial from './pages/Frontoffice/inicial/inicial';
import NegocioDetalhes from './pages/Frontoffice/negocio/negocioDetalhe';
import Candidatura from './pages/Frontoffice/candidatura/candidaturaLista';
import Beneficios from './pages/Frontoffice/beneficios/beneficioLista';
import NegocioCriar from './pages/Frontoffice/negocio/negocioCriar';
import NegocioLista from './pages/Frontoffice/negocio/negocioLista';
import Conta from './pages/Frontoffice/conta/contaDetalhe';
import Calendario from './pages/Frontoffice/calendario/calendario';
import IdeiaCriar from './pages/Frontoffice/ideia/ideiaCriar';
import Reuniao from './pages/Frontoffice/reuniao/reuniaoLista';
import NegocioListaBoard from './pages/Frontoffice/negocio/negocioListaBoard';
import Reporting from './pages/Backoffice/Reporting/reporting';
import ReportingNegocios from './pages/Backoffice/Reporting/reportingNegocios';
import ReportingIdeias from './pages/Backoffice/Reporting/reportingIdeias';
import ReportingContratacoes from './pages/Backoffice/Reporting/reportingContratacoes';
import ReportingCandidaturas from './pages/Backoffice/Reporting/reportingCandidaturas';
import ReportingRegistos from './pages/Backoffice/Reporting/reportingRegistos';
import Dashboard from './pages/Backoffice/dashboard/dashboard'
import TabelaUtilizadores from './pages/Backoffice/Tabelas/utilizador/utilizadorLista';
import Tabelas from './pages/Backoffice/Tabelas/tabelas';
import ContaEditar from './pages/Frontoffice/conta/contaEditar';
import Vaga from './pages/Frontoffice/vaga/vagaLista'
import IniciarSessao from './pages/Frontoffice/autenticacao/iniciarSessao';
import CriarConta from './pages/Frontoffice/autenticacao/criarConta';
import EsqueceuSenha from './pages/Frontoffice/autenticacao/esqueceuSenha';
import VagaCriar from './pages/Frontoffice/vaga/vagaCriar';
import Candidatarme from './pages/Frontoffice/candidatura/candidaturaCriar';
import RecomendacaoLista from './pages/Frontoffice/recomendacao/recomendacaoLista';
import VagaDetalhe from './pages/Frontoffice/vaga/vagaDetalhe';
import ReuniaoDetalhes from './pages/Frontoffice/reuniao/reuniaoDetalhe';
import TabelaNegocios from './pages/Backoffice/Tabelas/negocio/negocioLista';
import IdeiaLista from './pages/Frontoffice/ideia/ideiaLista';
import ErrorPage from './components/errorPage/errorPage';
import TabelaUtilizadorCriar from './pages/Backoffice/Tabelas/utilizador/utilizadorCriar';
import TabelaUtilizadorEditar from './pages/Backoffice/Tabelas/utilizador/utilizadorEditar';
import NotificacaoLista from './pages/Frontoffice/notificacao/notificacaoLista';
import Layout from './layouts/PageLayout/layout';
import { AuthProvider } from './context/authContext';
import RequireAuth from './auth/requireAuth';
import { perfisId } from './data/constants';
import ReuniaoAgendar from './pages/Frontoffice/reuniao/reuniaoAgendar';
import IdeiaListaBoard from './pages/Frontoffice/ideia/ideiaListaBoard';
import Definicoes from './pages/Frontoffice/conta/definicoes';
import TerminarSessao from './pages/Frontoffice/autenticacao/terminarSessao';
import ClienteLista from './pages/Frontoffice/cliente/clienteLista';
import VagaEditar from './pages/Frontoffice/vaga/vagaEditar';
import ReuniaoEditar from './pages/Frontoffice/reuniao/reuniaoEditar';
import BeneficioEditar from './pages/Frontoffice/beneficios/beneficioEditar';
import NegocioEditar from './pages/Frontoffice/negocio/negocioEditar';
import IdeiaEditar from './pages/Frontoffice/ideia/ideiaEditar';
import Contacto from './pages/Frontoffice/contacto/contacto';
import TabelaNegocioCriarArea from './pages/Backoffice/Tabelas/negocio/negocioCriarArea';
import TabelaNegocioCriarEstado from './pages/Backoffice/Tabelas/negocio/negocioCriarEstado';
import TabelaNegocioCriarTipoProjeto from './pages/Backoffice/Tabelas/negocio/negocioCriarTipoProjeto';
import { ToastContainer } from 'react-toastify';
import AuthConfirmacao from './pages/Frontoffice/autenticacao/authConfirmacao';
import { LoadingProvider } from './context/loadingContext';
import ForgetPasswordTrocarPassword from './pages/Frontoffice/autenticacao/forgetPasswordTrocarPassword';
import CarregandoDados from './components/LoadingPage/carregandoDados';
import TabelaUtilizadorCriarLocalizacao from './pages/Backoffice/Tabelas/utilizador/utilizadorLocalizacao';
import CandidaturaDetalhe from './pages/Frontoffice/candidatura/candidaturaDetalhe';


export default function App() {
	return (
		<Router>
			<ToastContainer />
			<LoadingProvider>
				<AuthProvider>
					<Routes>
						<Route path="/" element={<Layout />} >
							<Route path="/" element={<PaginaInicial />} />
							<Route path="/negocios" element={<NegocioLista />} />
							<Route path="/beneficios" element={<Beneficios />} />
							<Route path="/vagas" element={<Vaga />} />

							<Route element={<RequireAuth perfis={[perfisId.RH]} />}>
								<Route path="/vagas/editar/:id" element={<VagaEditar />} />
								<Route path="/vagas/criar" element={<VagaCriar />} />
								<Route path="/beneficios/editar/:id" element={<BeneficioEditar />} />
							</Route>

							<Route element={<RequireAuth perfis={[perfisId.RH]} />}>
								<Route path="/vagas/:id" element={<VagaDetalhe />} />
							</Route>

							<Route element={<RequireAuth perfis={[perfisId.Colaborador, perfisId.GIdeias]} />}>
								<Route path="/ideias" element={<IdeiaLista />} />
								<Route path="/ideias/criar" element={<IdeiaCriar />} />
							</Route>

							<Route element={<RequireAuth perfis={[perfisId.Colaborador, perfisId.GIdeias]} />}>
								<Route path="/ideias/board" element={<IdeiaListaBoard />} />
							</Route>

							<Route element={<RequireAuth perfis={[perfisId.Visitante, perfisId.Colaborador, perfisId.GNegocios, perfisId.GIdeias, perfisId.RH]} />}>
								<Route path="/reunioes/:id" element={<ReuniaoDetalhes />} />
								<Route path="/reunioes" element={<Reuniao />} />
								<Route path="/conta/:tag" element={<Conta />} />
								<Route path="/conta/:tag/editar" element={<ContaEditar />} />
								<Route path="/notificacoes" element={<NotificacaoLista />} />
								<Route path="/calendario" element={<Calendario />} />
								<Route path="/recomendacoes" element={<RecomendacaoLista />} />
								<Route path="/candidaturas" element={<Candidatura />} />
								<Route path="/vagas/candidatar-me/:id" element={<Candidatarme />} />
								<Route path="/negocios/criar" element={<NegocioCriar />} />
								<Route path="/negocios/:id" element={<NegocioDetalhes />} />

							</Route>

							<Route element={<RequireAuth perfis={[perfisId.GIdeias, perfisId.GNegocios]} />}>
								<Route path="/reunioes/criar" element={<ReuniaoAgendar />} />
								<Route path="/reunioes/editar/:id" element={<ReuniaoEditar />} />
							</Route>

							<Route element={<RequireAuth perfis={[perfisId.Admin]} />}>
								<Route path="/dashboard/tabelas" element={<TabelaUtilizadores />} />
								<Route path="/dashboard/tabelas/utilizadores" element={<TabelaUtilizadores />} />
								<Route path="/dashboard/tabelas/utilizadores/criar" element={<TabelaUtilizadorCriar />} />
								<Route path="/dashboard/tabelas/utilizadores/editar/:id" element={<TabelaUtilizadorEditar />} />
								<Route path="/dashboard/tabelas/negocios" element={<TabelaNegocios />} />
								<Route path="/dashboard/tabelas/negocios/area" element={<TabelaNegocioCriarArea />} />
								<Route path="/dashboard/tabelas/negocios/estado" element={<TabelaNegocioCriarEstado />} />
								<Route path="/dashboard/tabelas/utilizadores/localizacao" element={<TabelaUtilizadorCriarLocalizacao />} />
								<Route path="/dashboard/tabelas/negocios/tipo-projeto" element={<TabelaNegocioCriarTipoProjeto />} />
								<Route path="/dashboard/reporting/registos" element={<ReportingRegistos />} />
							</Route>

							<Route element={<RequireAuth perfis={[perfisId.GIdeias, perfisId.GNegocios, perfisId.RH]} />}>
								<Route path="/clientes" element={<ClienteLista />} />
								<Route path="/reunioes/editar/:id" element={<Reuniao />} />
								<Route path="/dashboard" element={<Dashboard />} />
								<Route path="/dashboard/reporting" element={<Reporting />} />
							</Route>

							<Route element={<RequireAuth perfis={[perfisId.GIdeias]} />}>
								<Route path="/dashboard/reporting/ideias" element={<ReportingIdeias />} />
								<Route path="/ideias/editar/:id" element={<IdeiaEditar />} />
							</Route>

							<Route element={<RequireAuth perfis={[perfisId.GNegocios]} />}>
								<Route path="/dashboard/reporting/negocios" element={<ReportingNegocios />} />
								<Route path="/negocios/board" element={<NegocioListaBoard />} />
								<Route path="/negocios/editar/:id" element={<NegocioEditar />} />
							</Route>

							<Route element={<RequireAuth perfis={[perfisId.RH]} />}>
								<Route path="/dashboard/reporting/candidaturas" element={<ReportingCandidaturas />} />
								<Route path="/dashboard/reporting/contratacoes" element={<ReportingContratacoes />} />
							</Route>


							<Route element={<RequireAuth perfis={[perfisId.Visitante, perfisId.Colaborador, perfisId.RH]} />}>
								<Route path="/candidaturas/:id" element={<CandidaturaDetalhe />} />
							</Route>


							<Route element={<RequireAuth perfis={[perfisId.Visitante, perfisId.Colaborador, perfisId.GNegocios, perfisId.GIdeias, perfisId.RH]} />}>
								<Route path="/terminar-sessao" element={<TerminarSessao />} />
								<Route path="/definicoes" element={<Definicoes />} />
							</Route>


							<Route path='/testando' element={<CarregandoDados />} />
							<Route path="/contactos" element={<Contacto />} />
							<Route path="/iniciar-sessao" element={<IniciarSessao />} />
							<Route path="/criar-conta" element={<CriarConta />} />
							<Route path="/confirmacao/:token" element={<AuthConfirmacao />} />
							<Route path="/esqueceu-senha" element={<EsqueceuSenha />} />
							<Route path="/esqueceu-senha/trocar-senha/:token" element={<ForgetPasswordTrocarPassword />} />
							<Route path="/inexistente" element={<ErrorPage error={'Está página não existe!'} />} />
							<Route path="/*" element={<ErrorPage error={'Está página não existe!'} />} />
						</Route>
					</Routes>
				</AuthProvider>
			</LoadingProvider>
		</Router>
	);
};