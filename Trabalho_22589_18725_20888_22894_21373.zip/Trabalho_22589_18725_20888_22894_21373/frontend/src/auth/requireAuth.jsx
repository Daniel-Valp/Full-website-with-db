import { perfisId } from "src/data/constants";

const { useLocation, Outlet, Navigate } = require("react-router-dom");
const { useAuth } = require("../hooks/useAuth");

const RequireAuth = ({ perfis }) => {
	const user = useAuth();
	const location = useLocation();
	if (!user) return null;
	if (!perfis.includes(perfisId.Admin)) perfis.push(perfisId.Admin);
	console.log("Permitidos:", perfis);
	return perfis.includes(user?.perfil || perfisId.Admin) ? (
		<Outlet />
	) : user?.id ? (
		<Navigate to="/inexistente" state={{ from: location }} replace />
	) : (
		<Navigate to="/iniciar-sessao" state={{ from: location }} replace />
	);
};

export default RequireAuth;
