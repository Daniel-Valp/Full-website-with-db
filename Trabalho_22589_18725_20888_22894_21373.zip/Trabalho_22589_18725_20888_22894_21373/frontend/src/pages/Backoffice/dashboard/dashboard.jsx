import { Link } from "react-router-dom";
import SubheaderMenu from "./components/subHeaderMenu";

export default function Deashboard() {
	return (
		<div>
			<SubheaderMenu />
		</div>
	);
}
