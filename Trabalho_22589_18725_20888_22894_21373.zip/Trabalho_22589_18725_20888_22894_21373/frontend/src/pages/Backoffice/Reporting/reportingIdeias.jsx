import React from "react";

import './reporting.css'

/** Componentes */
import { ReportingComponent } from "./reportingComponent";


function ReportingIdeias() {
	return (
		<div>
			<ReportingComponent
				active={4}
			/>
		</div>
	);
}

export default ReportingIdeias;