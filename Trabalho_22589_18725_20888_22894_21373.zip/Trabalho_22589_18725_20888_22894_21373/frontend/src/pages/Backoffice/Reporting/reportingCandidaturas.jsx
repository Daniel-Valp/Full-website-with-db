import React from "react";

import './reporting.css'

/** Funções */
import { addMapCounter, parseDate } from "src/utils/functionUtils";

/** Componentes */
import { ReportingComponent } from "./reportingComponent";
import { useData } from "src/api/dataComponents";
import BarChart from "src/components/Graficos/barChart";
import LineChart from "src/components/Graficos/lineChart";
import LoadingPage from "src/components/LoadingPage/loadingPage";


function ReportingCandidaturas() {
	const [dataVagas, loading] = useData('/vaga/list')
	if (loading)
		return <LoadingPage/>;
	const localizacaoMap = new Map();
	const mesEncerradoMap = new Map();
	const chartLabels = []
	const datasetsData = []
	for (var i = 0; i < dataVagas.length; i++){
		addMapCounter(dataVagas[i].vaga_localizacao, localizacaoMap)
		addMapCounter(parseDate(dataVagas[i].vaga_dataencerrado).monthName, mesEncerradoMap)
	}
	mesEncerradoMap.forEach((count, location) => {
		chartLabels.push(location)
		datasetsData.push(count)
	});

	const chartDatasets = [
		{
			label: 'Número de Candidatos',
			data: datasetsData
		}
	];
	return (
		<div>
			<ReportingComponent
				active={1}
			/>
			<div className="chart-size">
				<BarChart labels={chartLabels} datasets={chartDatasets} />
			</div>
			<LineChart />
		</div>
	);
}

export default ReportingCandidaturas;