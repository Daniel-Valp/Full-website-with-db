import React from "react";

import './reporting.css'

/** Componentes */
import { ReportingComponent } from "./reportingComponent";


function ReportingNegocios() {
	return (
		<div>
			<ReportingComponent
				active={3}
			/>
		</div>
	);
}

export default ReportingNegocios;