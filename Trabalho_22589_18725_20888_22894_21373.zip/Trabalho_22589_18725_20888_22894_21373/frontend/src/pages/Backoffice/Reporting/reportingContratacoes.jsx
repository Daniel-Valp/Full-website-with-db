import React from "react";

import './reporting.css'

/** Componentes */
import { ReportingComponent } from "./reportingComponent";


function ReportingContratacoes() {
	return (
		<div>
			<ReportingComponent
				active={2}
			/>
		</div>
	);
}

export default ReportingContratacoes;