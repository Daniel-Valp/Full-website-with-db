import { createData } from "src/api/dataComponents";
import TabelaCriar from "src/components/Tabelas/tabelaCriar";
import { useState } from "react";
import { checkCamposInvalidos } from "src/utils/dataControl";
import { statusResponse } from "src/utils/statusUtils";
import { useCarregando } from "src/hooks/useCarregando";

export default function TabelaNegocioCriarTipoProjeto() {
	const { startLoading, stopLoading } = useCarregando();
	const [nome, setnome] = useState("");

	async function handleSubmit() {
		if (checkCamposInvalidos(nome)) return false;
		startLoading();
		const data = {
			negociotipoprojeto_nome: nome,
		};
		await statusResponse({ asyncFunction: () => createData("/negocio/tipoprojeto/create", data), successMessage: "Tipo de Projeto adicionada com sucesso!"});
		stopLoading();
	}

	const form = [
		{
			label: "Tipo Projeto",
			getter: nome,
			setter: setnome,
			comp: "text",
		},
	];

	return (
		<div>
			<TabelaCriar form={form} handleSubmit={handleSubmit} titulo={"Tipo Projeto"} />
		</div>
	);
}
