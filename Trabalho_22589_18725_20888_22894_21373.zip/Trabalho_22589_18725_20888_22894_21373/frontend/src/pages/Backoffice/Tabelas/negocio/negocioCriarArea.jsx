import { createData } from "src/api/dataComponents";
import TabelaCriar from "src/components/Tabelas/tabelaCriar";
import { useState } from "react";
import { checkCamposInvalidos } from "src/utils/dataControl";
import { statusResponse } from "src/utils/statusUtils";
import { useCarregando } from "src/hooks/useCarregando";

export default function TabelaNegocioCriarArea() {
	const { startLoading, stopLoading } = useCarregando();
	const [nome, setnome] = useState("");

	async function handleSubmit() {
		if (checkCamposInvalidos(nome)) return false;
		startLoading();
		const data = {
			negocioarea_nome: nome,
		};
		await statusResponse({ asyncFunction: () => createData("/negocio/area/create", data), successMessage: "Area adicionada com sucesso!"});
		stopLoading();
	}

	const form = [
		{
			label: "Área",
			getter: nome,
			setter: setnome,
			comp: "text",
		},
	];

	return (
		<div>
			<TabelaCriar form={form} handleSubmit={handleSubmit} titulo={"Área"} />
		</div>
	);
}
