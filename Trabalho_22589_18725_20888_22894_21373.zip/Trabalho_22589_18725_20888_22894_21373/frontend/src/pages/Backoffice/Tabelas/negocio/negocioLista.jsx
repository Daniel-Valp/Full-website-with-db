import React from "react";
import TabelaLista from "src/components/Tabelas/tabelaLista";
import { useData } from "src/api/dataComponents";
import LoadingPage from "src/components/LoadingPage/loadingPage";
import { parsedFormatComplete } from "src/utils/functionUtils";
import { Button } from "src/components/Form";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

export default function TabelaNegocios() {
	const [dataNegocios, loadingNegocios] = useData("/negocio/list");
	if (loadingNegocios) return <LoadingPage />;
	const table = dataNegocios.map((data) => {
		return {
			ID: data.negocio_id,
			Título: data.negocio_titulo,
			"Tipo Projeto": data.neg_tipoproj.negociotipoprojeto_nome,
			Área: data.neg_area.negocioarea_nome,
			Estado: data.neg_estado.negocioestado_nome,
			Utilizador: data.neg_util.utilizador_tag,
			"Valor Estimado": data.negocio_valorestimado,
			Necessidades: data.negocio_necessidades,
			Descrição: data.negocio_descricao,
			"Motivo Perda": data.negocio_motivoperda,
			"Data Criação": parsedFormatComplete(data.negocio_datacriacao),
			"Data Encerrado": parsedFormatComplete(data.negocio_dataencerrado),
		};
	});

	return (
		<div>
			<TabelaLista
				table={table}
				tableName={"Negócios"}
				tableDeleteRoute={"negocio"}
				removerAdicionar={true}
				removerEditar={true}
				children={
					<div className="d-flex gap-3 mt-2">
						<Button label={"Área"} icon={<FontAwesomeIcon icon={["fas", "plus"]} />} directTo={"/dashboard/tabelas/negocios/area"} />
						<Button label={"Estado"} icon={<FontAwesomeIcon icon={["fas", "plus"]} />} directTo={"/dashboard/tabelas/negocios/estado"} />
						<Button label={"Tipo Projeto"} icon={<FontAwesomeIcon icon={["fas", "plus"]} />} directTo={"/dashboard/tabelas/negocios/tipo-projeto"} />
					</div>
				}
			/>
		</div>
	);
}
