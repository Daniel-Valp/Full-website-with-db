import { createData, useData } from "src/api/dataComponents";
import TabelaCriar from "src/components/Tabelas/tabelaCriar";
import { useState } from "react";
import { checkCamposInvalidos } from "src/utils/dataControl";
import { statusResponse } from "src/utils/statusUtils";
import { useCarregando } from "src/hooks/useCarregando";
import { LoadWhile } from "src/components/LoadingPage/loadWhile";
import LoadingPage from "src/components/LoadingPage/loadingPage";
import { comboBoxOptions } from "src/utils/functionUtils";

export default function TabelaUtilizadorCriarLocalizacao() {
	const { startLoading, stopLoading } = useCarregando();
	const [cidade, setcidade] = useState("");
	const [pais, setpais] = useState("");
	const [dataPaises, loadingPaises] = useData("/utilizador/pais/list");

	if (LoadWhile(loadingPaises)) return <LoadingPage />;

	async function handleSubmit() {
		if (checkCamposInvalidos(cidade, pais)) return false;
		startLoading();
		const data = {
			cidade_nome: cidade,
			cidade_pais: pais,
		};
		await statusResponse({
			asyncFunction: () => createData("/utilizador/cidade/create", data),
			successMessage: "Cidade adicionada com sucesso!",
		});
		stopLoading();
	}

	const form = [
		{
			label: "Cidade",
			getter: cidade,
			setter: setcidade,
			comp: "text",
		},
		{
			label: "Paises",
			getter: pais,
			setter: setpais,
			comp: "list",
			options: comboBoxOptions(dataPaises, "pais_id", "pais_nome"),
		},
	];

	return (
		<div>
			<TabelaCriar form={form} handleSubmit={handleSubmit} titulo={"Localização"} />
		</div>
	);
}
