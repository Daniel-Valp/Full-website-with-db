import React from "react";

export default function Tabelas() {
	return (
		<div>
			ola
		</div>
	);
}
