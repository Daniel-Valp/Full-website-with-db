import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Link, useNavigate } from "react-router-dom";
import { UserTemPerfis, getStringDateDiff } from "src/utils/functionUtils";
import LoadingPage from "src/components/LoadingPage/loadingPage";
import { useData } from "src/api/dataComponents";
import Card from "src/components/Cards/card";
import { IdeiaCriarPopup } from "./components/ideiaCriarPopup";
import IdeiaDetalhePopup from "./components/ideiaDetalhePopup";
import { useUserBasedFetch } from "src/hooks/useUserBasedFetch";
import { perfisId } from "src/data/constants";
import { LoadWhile } from "src/components/LoadingPage/loadWhile";
import { PaginationList } from "src/components/Pagination/paginationList";
import { Pode } from "src/components/Permissoes/Pode";
import { useAuth } from "src/hooks/useAuth";

export default function IdeiaLista() {
	const [dataIdeiaCategoria, loadingIdeiaCategoria] = useData("/ideia/categoria/list");
	const navigate = useNavigate();
	const utilizadorAtual = useAuth();

	const [dataIdeia, setdataIdeia, hasPerfilIdeia] = useUserBasedFetch({
		perfisPermitidos: [perfisId.GIdeias],
		generalBaseUrl: "/ideia/list",
		userIdentifier: "ideia_utilizador",
	});

	if (LoadWhile(!dataIdeia, loadingIdeiaCategoria)) return <LoadingPage />;

	if (!hasPerfilIdeia && dataIdeia.length === 0) {
		setTimeout(() => {
			navigate("/ideias/criar");
		}, 0);
	}

	function Load() {
		const sortedData = dataIdeia.sort((a, b) => {
			const dateA = new Date(a.ideia_datacriacao);
			const dateB = new Date(b.ideia_datacriacao);
			return dateB - dateA;
		});

		const cardElements = sortedData.map((data, index) => {
			return (
				<div className="col-md-4 mt-3">
					<IdeiaDetalhePopup
						trigger={
							<Card
								titulo={data.ideia_titulo}
								descricao={data.ideia_descricao}
								utilizador={data.ideia_util}
								date={getStringDateDiff(data.ideia_datacriacao)}
							/>
						}
						data={data}
					/>
				</div>
			);
		});
		return cardElements;
	}
	return (
		<div>
			<PaginationList
				cardsProps={Load()}
				pageTitulo={"Ideias"}
				pageChildrenIcons={
					<div className="icon-bar d-flex">
						<Pode se={UserTemPerfis([perfisId.GIdeias], utilizadorAtual.perfil)}>
							<Link to={`board`}>
								<FontAwesomeIcon icon={["fas", "table-columns"]} className="FontAwesomeIcons" />
							</Link>
						</Pode>
						<IdeiaCriarPopup
							trigger={<FontAwesomeIcon icon={["fas", "plus"]} className="FontAwesomeIcons" />}
							data={dataIdeiaCategoria}
						/>
					</div>
				}
			/>
		</div>
	);
}
