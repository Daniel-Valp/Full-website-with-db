import React from "react";

/** Components */
import { Button } from "src/components/Form";
import { UserTemPerfis, getStringDateDiff } from "src/utils/functionUtils";
import Popup from "src/components/Pop-up/popup";
import BoxData from "src/layouts/Alignment/boxData";
import UserInfo from "src/components/OverlayTooltip/userInfo";
import RowFill from "src/layouts/Alignment/rowFill";
import { Pode } from "src/components/Permissoes/Pode";
import { useAuth } from "src/hooks/useAuth";
import { perfisId } from "src/data/constants";

export default function IdeiaDetalhePopup({ trigger, data }) {
	const utilizadorAtual = useAuth();

	return (
		<Popup
			popupKey={data.ideia_id}
			trigger={trigger}
			titulo={data.ideia_titulo}
			subtitulo={
				<div className="d-flex">
					<UserInfo utilizador={data.ideia_util} children={<p>{data.ideia_util.utilizador_tag}</p>} />
					<p>&nbsp;{"· " + getStringDateDiff(data.ideia_datacriacao)}</p>
				</div>
			}
			childrenBody={
				<div className="form-row">
					<RowFill>
						<BoxData>
							<h2>Categoria</h2>
							<p>{data.ideia_cat.ideiacategoria_nome}</p>
						</BoxData>
						<BoxData>
							<h2>Estado</h2>
							<p>{data.ideia_est.ideiaestado_nome}</p>
						</BoxData>
					</RowFill>
					<div className="mt-4">
						<BoxData>
							<h2>Descrição</h2>
							<p>{data.ideia_descricao}</p>
						</BoxData>
					</div>
				</div>
			}
			childrenFooter={
				<Pode se={UserTemPerfis([perfisId.GIdeias], utilizadorAtual.perfil)}>
					<Button label={"Editar"} type="secondary" directTo={`/ideias/editar/${data.ideia_id}`} />
				</Pode>
			}
		/>
	);
}
