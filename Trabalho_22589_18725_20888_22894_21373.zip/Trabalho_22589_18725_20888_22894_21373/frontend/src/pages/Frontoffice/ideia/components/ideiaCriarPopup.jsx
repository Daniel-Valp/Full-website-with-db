import React, { useState } from "react";

/** Components */
import Layout from "src/layouts/PageLayout/layout";
import { createData } from "src/api/dataComponents";
import { ComboBox, TextBox, TextArea, Button } from "src/components/Form";
import { getUtilizador } from "src/utils/localStorage";
import { comboBoxOptions } from "src/utils/functionUtils";
import { PopupStatus } from "src/components/Pop-up/popupStatus";
import Popup from "src/components/Pop-up/popup";
import { checkCamposInvalidos, isUserLogged } from "src/utils/dataControl";
import { useAuth } from "src/hooks/useAuth";
import { statusResponse } from "src/utils/statusUtils";

export function IdeiaCriarPopup({ trigger, data }) {
	const [getTitulo, setTitulo] = useState("");
	const [getCategoria, setCategoria] = useState("");
	const [getDescricao, setDescricao] = useState("");
	const utilizadorAtual = useAuth();

	async function handleIdeiaSubmit() {
		if (!isUserLogged(utilizadorAtual)) return false;
		if (checkCamposInvalidos(getTitulo, getCategoria, getDescricao)) return false;
		const data = {
			ideia_titulo: getTitulo,
			ideia_categoria: getCategoria,
			ideia_descricao: getDescricao,
			ideia_utilizador: utilizadorAtual.id,
		};
		await statusResponse({
			asyncFunction: () => createData("/ideia/create", data),
			successMessage: "Ideia adicionada com sucesso",
		});
	}

	function clearForm() {
		setTitulo("");
		setCategoria("");
		setDescricao("");
	}

	return (
		<Popup
			trigger={trigger}
			titulo={"Ideia - Criar"}
			childrenBody={
				<form>
					<div className="form-row">
						<TextBox
							label={"Título"}
							marginTop={3}
							handleChange={(e) => setTitulo(e.target.value)}
							value={getTitulo}
						/>
						<ComboBox
							label={"Categoria"}
							options={comboBoxOptions(data, "ideiacategoria_id", "ideiacategoria_nome")}
							marginTop={3}
							handleChange={(e) => setCategoria(e.target.value)}
							value={getCategoria}
						/>
					</div>
					<TextArea
						label={"Descrição"}
						marginTop={3}
						handleChange={(e) => setDescricao(e.target.value)}
						value={getDescricao}
					/>
				</form>
			}
			childrenFooter={
				<div className="gap-3 d-flex">
					<Button label={"Criar"} marginTop={3} handleClick={handleIdeiaSubmit} />
				</div>
			}
		/>
	);
}
