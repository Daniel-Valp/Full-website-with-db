import React, { useEffect, useState } from "react";

/** Components */
import { createData, useData } from "src/api/dataComponents";
import { ComboBox, TextBox, TextArea, Button } from "src/components/Form";
import LoadingPage from "src/components/LoadingPage/loadingPage";
import { getUtilizador } from "src/utils/localStorage";
import { comboBoxOptions } from "src/utils/functionUtils";
import { PopupStatus } from "src/components/Pop-up/popupStatus";
import { useAuth } from "src/hooks/useAuth";
import { checkCamposInvalidos, isUserLogged } from "src/utils/dataControl";


export default function IdeiaCriar() {
	const [dataCategorias, loadingCategorias] = useData('/ideia/categoria/list')
	const [getTitulo, setTitulo] = useState('');
	const [getCategoria, setCategoria] = useState('');
	const [getDescricao, setDescricao] = useState('');

	const utilizadorAtual = useAuth();

	if (loadingCategorias)
		return <LoadingPage />

	function handleIdeiaSubmit() {
		if (!isUserLogged(utilizadorAtual)) return false;
		if (checkCamposInvalidos(getTitulo, getCategoria, getDescricao)) return false;
		const data = {
			ideia_titulo: getTitulo,
			ideia_categoria: getCategoria,
			ideia_descricao: getDescricao,
			ideia_utilizador: utilizadorAtual.id,
		}
		const response = createData('/ideia/create', data);
		if (response)
			PopupStatus('Ideia adicionada com sucesso!', 'success');
		else
			PopupStatus('Ocurreu algum erro!', 'error');
	}
	return (
		<div>
			<div className="container">
				<div className="row justify-content-center mt-5">
					<div className="col-md-6">
						<h1 className="text-center mb-4">Ideia - Criar</h1>
						<form>
							<div className="form-row">
								<TextBox
									label={"Título"}
									marginTop={3}
									handleChange={(e) => setTitulo(e.target.value)} value={getTitulo}
								/>
								<ComboBox
									label={"Categoria"}
									options={
										comboBoxOptions(dataCategorias, 'ideiacategoria_id', 'ideiacategoria_nome')
									}
									marginTop={3}
									handleChange={(e) => setCategoria(e.target.value)} value={getCategoria}
								/>
							</div>
							<TextArea
								label={"Descrição"}
								marginTop={3}
								handleChange={(e) => setDescricao(e.target.value)} value={getDescricao}
							/>
							<div className="gap-3 d-flex">
								<Button
									label={"Criar"}
									marginTop={3}
									handleClick={handleIdeiaSubmit}
								/>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	);
}