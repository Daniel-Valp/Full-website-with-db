import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { updateData, useData } from "src/api/dataComponents";
import BasicHeader from "src/components/BasicHeader/basicHeader";
import { Button, ComboBox, TextArea, TextBox } from "src/components/Form";
import { LoadWhile } from "src/components/LoadingPage/loadWhile";
import LoadingPage from "src/components/LoadingPage/loadingPage";
import { useAuth } from "src/hooks/useAuth";
import { useCarregando } from "src/hooks/useCarregando";
import { checkCamposInvalidos, isUserLogged } from "src/utils/dataControl";
import { comboBoxOptions, navigateBack } from "src/utils/functionUtils";
import { statusResponse } from "src/utils/statusUtils";

export default function IdeiaEditar() {
	const { id } = useParams();
	const [dataIdeia, loadingIdeia] = useData(`/ideia/get/${id}`);
	const [dataCategoria, loadingCategoria] = useData("/ideia/categoria/list");
	const [dataEstado, loadingEstado] = useData("/ideia/estado/list");
	const utilizadorAtual = useAuth();
	const navigate = useNavigate();
	const { startLoading, stopLoading } = useCarregando();

	const [titulo, settitulo] = useState("");
	const [descricao, setdescricao] = useState("");
	const [categoria, setcategoria] = useState("");
	const [estado, setestado] = useState("");

	useEffect(() => {
		if (dataIdeia) {
			settitulo(dataIdeia.ideia_titulo);
			setdescricao(dataIdeia.ideia_descricao);
			setcategoria(dataIdeia.ideia_categoria);
			setestado(dataIdeia.ideia_estado);
		}
	}, [dataIdeia]);

	if (LoadWhile(loadingEstado, loadingCategoria, loadingIdeia)) return <LoadingPage />;

	async function handleUpdate() {
		if (!isUserLogged(utilizadorAtual)) return false;
		if (checkCamposInvalidos(titulo, descricao, categoria, estado)) return false;
		startLoading();
		const data = {
			vaga_titulo: titulo,
			vaga_categoria: categoria,
			vaga_descricao: descricao,
			vaga_estado: estado,
		};
		await statusResponse({
			asyncFunction: () => updateData(`/ideia/update/${id}`, data),
			successMessage: "Ideia editada com sucesso!",
			handleSucess: () => navigateBack(),
		});
		stopLoading();
	}

	return (
		<div className="container">
			<BasicHeader pageTitulo={"Ideia - Editar"} />
			<TextBox label={"Título"} handleChange={(e) => settitulo(e.target.value)} value={titulo} />
			<TextArea label={"Descrição"} handleChange={(e) => setdescricao(e.target.value)} value={descricao} />
			<ComboBox
				label="Categoria"
				handleChange={(e) => setcategoria(e.target.value)}
				defaultValue={categoria}
				options={comboBoxOptions(dataCategoria, "ideiacategoria_id", "ideiacategoria_nome")}
			/>
			<ComboBox
				label="Estado"
				handleChange={(e) => setestado(e.target.value)}
				defaultValue={estado}
				options={comboBoxOptions(dataEstado, "ideiaestado_id", "ideiaestado_nome")}
			/>
			<Button label={"Confirmar"} handleClick={handleUpdate} marginTop={5} />
		</div>
	);
}
