export default function EsqueceuSenhaNovaSenha() {
	return (
		<div>
			
		</div>
	);
}