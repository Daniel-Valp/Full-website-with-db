import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

import "./log-in.css";

import { Button, TextBox } from "src/components/Form";
import { myAxios } from "src/lib/axios";
import { statusResponse } from "src/utils/statusUtils";
import { useCarregando } from "src/hooks/useCarregando";

export default function EsqueceuSenha() {
	const [email, setemail] = useState("");
	const { startLoading, stopLoading } = useCarregando();
	const navigate = useNavigate();

	async function handleSenhaEsquecida() {
		const data = {
			email: email,
		};
		startLoading();
		var dados = await statusResponse({
			asyncFunction: () => myAxios({ url: "/utilizador/forgetPassword/email", method: "post", data: data }),
			successMessage: "Foi lhe enviado um email!",
			handleSucess: navigate("confirmacao"),
			errorMessage: "Email inválido",
		});
		stopLoading();
	}

	return (
		<div>
			<div className="iniciar-sessao">
				<h1 className="is-title">Esqueceu Senha</h1>
				<div className="is-content">
					<form>
						<TextBox
							label={"Email"}
							marginTop={3}
							handleChange={(e) => setemail(e.target.value)}
							value={email}
						/>
						<div className="d-flex gap-3 mt-4">
							<Button label={"Prosseguir"} handleClick={handleSenhaEsquecida} />
						</div>
					</form>
				</div>
			</div>
		</div>
	);
}
