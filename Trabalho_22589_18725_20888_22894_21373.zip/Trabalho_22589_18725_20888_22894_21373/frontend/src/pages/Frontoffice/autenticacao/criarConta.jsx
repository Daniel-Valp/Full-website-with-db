import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button, TextBox } from "src/components/Form";
import { createData } from "src/api/dataComponents";
import Row from "src/layouts/Alignment/row";
import { useCarregando } from "src/hooks/useCarregando";
import { checkEmail, checkTag, statusResponse } from "src/utils/statusUtils";

import "./log-in.css";
import { checkCamposInvalidos } from "src/utils/dataControl";
import { PopupStatus } from "src/components/Pop-up/popupStatus";
import { myAxios } from "src/lib/axios";

export default function CriarConta() {
	const [getTag, setTag] = useState("");
	const [getNome, setNome] = useState("");
	const [getApelido, setApelido] = useState("");
	const [getEmail, setEmail] = useState("");
	const [getPassword, setPassword] = useState("");
	const [getPasswordConfirmar, setPasswordConfirmar] = useState("");
	const { startLoading, stopLoading } = useCarregando();

	const navigate = useNavigate();

	async function verificarEmail() {
		if (!checkEmail(getEmail)) return true;
		const res = await myAxios({
			url: "/utilizador/search/exactMatch",
			method: "post",
			data: { utilizador_email: getEmail },
		});
		console.log("email", res.data);
		if (res.data.exists) return true;
		return false;
	}

	async function verificarTag() {
		if (!checkTag(getTag)) return true;
		const res = await myAxios({
			url: "/utilizador/search/exactMatch",
			method: "post",
			data: { utilizador_tag: "@" + getTag },
		});
		if (res.data.exists) {
			PopupStatus("A tag já existe, por favor escolha outra.", "warn");
			return true;
		}
		return false;
	}

	async function handleContaSubmit() {
		if (checkCamposInvalidos(getNome, getApelido, getPassword, getPasswordConfirmar)) return false;
		if (await verificarTag()) return false;
		if (await verificarEmail()) return false;
		if (!(getPassword === getPasswordConfirmar)) {
			PopupStatus("As senhas não coincidêm", "warn");
			return false;
		}	
		startLoading();
		const data = {
			utilizador_nome: getNome,
			utilizador_apelido: getApelido,
			utilizador_email: getEmail,
			utilizador_password: getPassword,
			utilizador_tag: "@" + getTag,
		};

		const response = await statusResponse({
			asyncFunction: () => {
				return createData("/utilizador/create", data);
			},
			successMessage: "Conta criada com sucesso",
			handleSucess: () => {
				setTimeout(() => {
					navigate("/iniciar-sessao");
				}, 0);
			},
		});
		stopLoading();
	}

	return (
		<div>
			<div className="iniciar-sessao">
				<div>
					<h1 className="is-title">Criar conta</h1>
					<form className="is-content">
						<Row>
							<TextBox
								label={"Nome"}
								marginTop={3}
								handleChange={(e) => setNome(e.target.value)}
								value={getNome}
							/>
							<TextBox
								label={"Apelido"}
								marginTop={3}
								handleChange={(e) => setApelido(e.target.value)}
								value={getApelido}
							/>
						</Row>
						<div>
							<TextBox
								label={"Tag"}
								marginTop={3}
								handleChange={(e) => setTag(e.target.value)}
								value={getTag}
								addon="@"
							/>
							{/* <h5 className="perigo">asdas</h5> */}
						</div>
						<div>
							<TextBox
								label={"Email"}
								marginTop={3}
								handleChange={(e) => setEmail(e.target.value)}
								value={getEmail}
							/>
						</div>
						<Row className="mt-3">
							<TextBox
								label={"Senha"}
								inputType="password"
								handleChange={(e) => setPassword(e.target.value)}
								value={getPassword}
							/>
							<TextBox
								label={"Senha confirmar"}
								inputType="password"
								handleChange={(e) => setPasswordConfirmar(e.target.value)}
								value={getPasswordConfirmar}
							/>
						</Row>
						<div className="d-flex gap-3 mt-4">
							<Button label={"Criar"} handleClick={handleContaSubmit} />
							<Button label={"Iniciar sessão"} type="outline-primary" directTo={"/iniciar-sessao"} />
						</div>
						<Link to="/esqueceu-senha" className="mt-2">
							Esqueceu-se da senha?
						</Link>
					</form>
				</div>
			</div>
		</div>
	);
}
