import { useEffect } from "react";
import AuthService from "src/api/auth.service";
import { navigateBack } from "src/utils/functionUtils";

export default function TerminarSessao() {
	useEffect(() => {
		const EndSession = async () => {
			AuthService.terminar_sessao();
			window.location.reload();
			window.location.href = "/iniciar-sessao";
		};
		EndSession();
	}, []);
}
