export default function EsqueceuSenhaConfirmacao() {
	return (
		<div>
			
		</div>
	);
}