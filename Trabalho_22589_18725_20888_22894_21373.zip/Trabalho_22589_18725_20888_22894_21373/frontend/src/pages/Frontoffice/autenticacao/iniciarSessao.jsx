import React, { useState } from "react";
import AuthService from "src/api/auth.service";
import { useNavigate, Link } from "react-router-dom";

import "./log-in.css";

import { Button, TextBox } from "src/components/Form";
import { PopupStatus } from "src/components/Pop-up/popupStatus";
import { checkCamposInvalidos } from "src/utils/dataControl";
import { useCarregando } from "src/hooks/useCarregando";

export default function IniciarSessao() {
	const navigate = useNavigate();
	const [login, setlogin] = useState("");
	const [password, setpassword] = useState("");
	const { startLoading, stopLoading } = useCarregando();

	async function HandleLogin(event) {
		if (checkCamposInvalidos(login, password)) return false;
		startLoading();
		event.preventDefault();
		await AuthService.iniciar_sessao(login, password)
			.then((res) => {
				if (res === "" || res === false) {
					PopupStatus("Autenticação1 falhou", "error");
				} else if (res.token) {
					navigate("/");
					window.location.reload();
					PopupStatus("Sessão iniciada com sucesso", "success");
				} else {
					PopupStatus("Um email de confirmação foi enviado", "success");
				}
			})
			.catch((error) => {
				PopupStatus("Autenticação falhou", "error");
			});
		stopLoading();
	}

	return (
		<div>
			<div className="iniciar-sessao">
				<h1 className="is-title">Iniciar sessão</h1>
				<div className="is-content">
					<form>
						<TextBox
							label={"Email ou Tag"}
							marginTop={3}
							handleChange={(e) => setlogin(e.target.value)}
							value={login}
						/>
						<TextBox
							label={"Senha"}
							marginTop={3}
							inputType="password"
							handleChange={(e) => setpassword(e.target.value)}
							value={password}
						/>
						<div className="d-flex gap-3 mt-4">
							<Button label={"Entrar"} handleClick={HandleLogin} />
							<Button label={"Criar conta"} type="outline-primary" directTo={"/criar-conta"} />
						</div>
					</form>
					<Link to="/esqueceu-senha" className="mt-2">
						Esqueceu-se da senha?
					</Link>
				</div>
			</div>
		</div>
	);
}
