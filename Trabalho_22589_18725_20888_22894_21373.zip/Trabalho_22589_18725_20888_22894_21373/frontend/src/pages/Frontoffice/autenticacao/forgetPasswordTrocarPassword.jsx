import axios from "axios";
import { useEffect } from "react";
import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import authService from "src/api/auth.service";
import { Button, TextBox } from "src/components/Form";
import { PopupStatus } from "src/components/Pop-up/popupStatus";
import { backendUrl } from "src/data/constants";
import { myAxios } from "src/lib/axios";

export default function ForgetPasswordTrocarPassword() {
	const [senha, setsenha] = useState("");
	const [senhaConfirmar, setsenhaConfirmar] = useState("");
	const { token } = useParams();
	const navigate = useNavigate();

	async function handleForgetPassword() {
		if (!(senha === senhaConfirmar)) return false;
		if (!token) return false;
		const dados = {
			utilizador_password: senha,
		};
		const response = await axios
			.put(`${backendUrl}/utilizador/forgetPassword/confirmar`, dados, { headers: { Authorization: `Bearer ${token}` } })
			.then((response) => {
				if (response?.data?.success) {
					PopupStatus("Autenticação sucedida", "success");
					navigate("/");
				}
				return response;
			})
			.catch((error) => {
				PopupStatus("Autenticação falhou", "error");
				return null;
			});
	}

	return (
		<div>
			<div className="iniciar-sessao">
				<h1 className="is-title">Nova Senha</h1>
				<div className="is-content">
					<form>
						<TextBox label={"Senha"} marginTop={3} handleChange={(e) => setsenha(e.target.value)} value={senha} />
						<TextBox
							label={"Senha confirmar"}
							marginTop={3}
							handleChange={(e) => setsenhaConfirmar(e.target.value)}
							value={senhaConfirmar}
						/>
						<Button label={"Confirmar"} marginTop={5} handleClick={handleForgetPassword} />
					</form>
				</div>
			</div>
		</div>
	);
}
