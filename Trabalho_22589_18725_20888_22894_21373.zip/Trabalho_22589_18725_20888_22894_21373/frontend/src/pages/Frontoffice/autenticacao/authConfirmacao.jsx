import { useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import authService from "src/api/auth.service";
import LoadingPage from "src/components/LoadingPage/loadingPage";
import { PopupStatus } from "src/components/Pop-up/popupStatus";

export default function AuthConfirmacao() {
	const { token } = useParams();

	useEffect(() => {
		const confirmUser = async () => {
			try {
				const res = await authService.confirmarUtilizador(token); /// rever o await aqui!! NOTE
				if (res === "" || res === false) {
					PopupStatus("Autenticação falhou", "error");
					window.location.href = "/iniciar-sessao";
				} else {
					PopupStatus("Autenticação sucedida", "success");
					window.location.href = "/";
				}
			} catch (error) {
				PopupStatus("Autenticação falhou", "error");
				window.location.href = "/iniciar-sessao";
			}
		};

		confirmUser();
	}, [token]);

	return (
		<div>
			<LoadingPage/>
		</div>
	);
}
