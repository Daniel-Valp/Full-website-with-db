import { useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import authService from "src/api/auth.service";
import { PopupStatus } from "src/components/Pop-up/popupStatus";

export default function ForgetPasswordConfirmacao() {
	const { token } = useParams();

	useEffect(() => {
		const confirmUser = async () => {
			try {
				const res = await authService.confirmarUtilizador(token); /// rever o await aqui!! NOTE
				if (res === "" || res === false) {
					PopupStatus("Autenticação falhou", "error");
					window.location.href = "/";
				} else if (res.data.success) {
					PopupStatus("Autenticação sucedida", "success");
					window.location.href = "/esqueceu-password/trocar-senha";
				}
			} catch (error) {
				PopupStatus("Autenticação falhou", "error");
				window.location.href = "/";
			}
		};

		confirmUser();
	}, [token]);

	return (
		<div>
			<p>a</p>
		</div>
	);
}
