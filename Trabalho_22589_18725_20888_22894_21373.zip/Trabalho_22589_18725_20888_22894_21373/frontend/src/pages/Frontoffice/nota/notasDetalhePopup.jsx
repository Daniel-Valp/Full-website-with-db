import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { createData, updateData, useData } from "src/api/dataComponents";
import { createFile } from "src/api/fileComponents";
import { FileIcon } from "src/components/FileIconPlaceholder/fileIconPlaceholder";
import { Button, FileBox, TextArea, TextBox } from "src/components/Form";
import { makeImageUrl } from "src/components/Imagens/utilizadorImagem";
import { Pode } from "src/components/Permissoes/Pode";
import { useAuth } from "src/hooks/useAuth";
import { usePopupStatic } from "src/hooks/usePopupStatic";
import { myAxios } from "src/lib/axios";
import { clearFileName } from "src/utils/functionUtils";
import { statusResponse } from "src/utils/statusUtils";

export default function NotasDetalhePopup({ psTrigger, startLoad, stopLoad, notaId, reuniaoId, entrevista = false }) {
	const [dataNota, loadingNota] = useData(notaId ? `/nota/get/${notaId}` : null);
	const { psCreate, psOpen, psClose } = usePopupStatic();
	const utilizadorAtual = useAuth();

	const [titulo, settitulo] = useState("");
	const [classificacao, setclassificacao] = useState("");
	const [descricao, setdescricao] = useState("");
	const [ficheiro, setficheiro] = useState([]);

	useEffect(() => {
		if (dataNota) {
			settitulo(dataNota.nota_titulo);
			setdescricao(dataNota.nota_descricao);
			const classificacao = dataNota?.notaentrev_nota;
			if (entrevista) setclassificacao(classificacao ? classificacao[0].notaentrevista_classificacao : null);
		}
	}, [dataNota, entrevista]);

	useEffect(() => {
		if (dataNota) {
			setficheiro(dataNota.notafich_nota);
		}
	});

	async function handleNotas() {
		startLoad();
		const data = {
			nota_titulo: titulo,
			nota_descricao: descricao,
			nota_reuniao: reuniaoId,
			nota_utilizador: utilizadorAtual.id,
		};
		await statusResponse({
			asyncFunction: () => updateData(`/nota/update/${notaId}`, data),
			successMessage: "Nota atualizada com sucesso!",
		});

		stopLoad();
	}

	async function submeterFicheiro(file) {
		const fileObject = await createFile(file);
		const fileName = clearFileName(fileObject.data.data.name);
		console.log(fileName);
		const data = {
			notaficheiro_nota: notaId,
			notaficheiro_ficheiro: fileObject.data.data.id,
			notaficheiro_ficheironome: fileName,
		};
		const res = await statusResponse({
			asyncFunction: () => createData(`/nota/ficheiro/create`, data),
			successMessage: "Ficheiro adicionado com sucesso!",
		});
		console.log(res);
	}

	return (
		<div>
			<div onClick={psOpen}>{psTrigger}</div>
			{psCreate({
				psTitulo: "Nota",
				psSubtitulo: (
					<div className="d-flex">
						<p>Criador: {utilizadorAtual.tag}</p>
					</div>
				),
				psBody: (
					<div>
						<TextBox label={"Título"} handleChange={(e) => settitulo(e.target.value)} value={titulo} />
						<Pode se={entrevista}>
							<TextBox
								label={"Classificação"}
								inputType="number"
								handleChange={(e) => setclassificacao(e.target.value)}
								value={classificacao}
								marginTop={3}
							/>
						</Pode>
						<TextArea
							label={"Descrição"}
							handleChange={(e) => setdescricao(e.target.value)}
							value={descricao}
							marginTop={3}
							linhas={10}
						/>
						<FileBox
							label={"Anexar Ficheiros"}
							handleChange={(e) => submeterFicheiro(e.target.files[0])}
							marginTop={3}
							acceptedTypes={".pdf"}
						/>
						<div className="overflow-auto table-container">
							{ficheiro &&
								ficheiro.map((item) => {
									return (
										<div className="mt-3">
											<FileIcon label={item.notaficheiro_ficheironome} directTo={makeImageUrl(item.notaficheiro_ficheiro)} />
										</div>
									);
								})}
						</div>
					</div>
				),
				psFooter: (
					<div>
						<Button label={"Guardar"} handleClick={handleNotas} />
					</div>
				),
			})}
		</div>
	);
}
