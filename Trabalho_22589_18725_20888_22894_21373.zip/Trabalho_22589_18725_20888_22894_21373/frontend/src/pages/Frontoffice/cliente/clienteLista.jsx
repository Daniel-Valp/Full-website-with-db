import { useData } from "src/api/dataComponents";
import LoadingPage from "src/components/LoadingPage/loadingPage";
import { LoadWhile } from "src/components/LoadingPage/loadWhile";
import { filterDataByAllColumns, sortByDate } from "src/utils/dataManipulation";
import { useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import Card from "src/components/Cards/card";
import Popup from "src/components/Pop-up/popup";
import ClienteCriarPopup from "./components/clienteCriarPopup";
import TabelaApagar from "src/components/Tabelas/tabelaApagar";
import { Button, SearchBox } from "src/components/Form";
import { PaginationList } from "src/components/Pagination/paginationList";

export default function ClienteLista() {
	const [dataClientes, loadingClientes] = useData("/cliente/list");
	const [searchTerm, setsearchTerm] = useState("");

	if (LoadWhile(loadingClientes)) return <LoadingPage />;

	function handleFilterClear() {
		setsearchTerm("");
	}

	function Load() {
		var filteredData = filterDataByAllColumns(dataClientes, searchTerm);
		const sortedData = sortByDate(filteredData, "cliente_datacriacao");
		return sortedData.map((data) => {
			return (
				<div className="col-md-3 mt-3">
					<Popup
						popupKey={data.cliente_id}
						titulo={data.cliente_empresa}
						trigger={
							<Card
								titulo={data.cliente_empresa}
								descricao={
									<div>
										<div className="d-flex align-items-center gap-2">
											<FontAwesomeIcon icon={["fas", "envelope"]} />
											<p>{data.cliente_email}</p>
										</div>
										<div className="d-flex align-items-center gap-2">
											<FontAwesomeIcon icon={["fas", "phone"]} />
											<p>{data.cliente_telefone}</p>
										</div>
									</div>
								}
							/>
						}
						childrenBody={
							<div>
								<div>
									<div className="d-flex align-items-center gap-2">
										<FontAwesomeIcon icon={["fas", "envelope"]} />
										<p>{data.cliente_email}</p>
									</div>
									<div className="d-flex align-items-center gap-2">
										<FontAwesomeIcon icon={["fas", "phone"]} />
										<p>{data.cliente_telefone}</p>
									</div>
								</div>
								<h2 className="mt-4">Contactos</h2>
								<div className="d-flex gap-3">
									{data.cont_cliente.map((contacto) => (
										<div className="col-md-4 mb-3">
											<Card
												titulo={`${contacto.clientecontacto_nome} ${contacto.clientecontacto_cargo}`}
												descricao={
													<div>
														<div className="d-flex align-items-center gap-2">
															<FontAwesomeIcon icon={["fas", "envelope"]} />
															<p>{contacto.clientecontacto_email}</p>
														</div>
														<div className="d-flex align-items-center gap-2">
															<FontAwesomeIcon icon={["fas", "phone"]} />
															<p>{contacto.clientecontacto_telefone}</p>
														</div>
													</div>
												}
											/>
										</div>
									))}
								</div>
							</div>
						}
						childrenFooter={
							<div>
								<Button
									label={"Apagar"}
									type="danger"
									handleClick={() => TabelaApagar(data.cliente_id, "cliente")}
								/>
							</div>
						}
					/>
				</div>
			);
		});
	}

	return (
		<div>
			<PaginationList
				cardsProps={Load()}
				pageTitulo={"Clientes"}
				pageChildrenFilter={
					<div className="gap-3 d-flex justify-content-end">
						<SearchBox handleChange={(e) => setsearchTerm(e.target.value)} value={searchTerm} />
						<div className="d-flex justify-content-end mt-auto">
							<Button label={"Limpar"} handleClick={handleFilterClear} />
						</div>
					</div>
				}
				pageChildrenIcons={
					<div className="d-flex gap-2">
						<ClienteCriarPopup
							trigger={<FontAwesomeIcon icon={["fas", "plus"]} title="Adicionar" className="FontAwesomeIcons" />}
						/>
					</div>
				}
			/>
		</div>
	);
}
