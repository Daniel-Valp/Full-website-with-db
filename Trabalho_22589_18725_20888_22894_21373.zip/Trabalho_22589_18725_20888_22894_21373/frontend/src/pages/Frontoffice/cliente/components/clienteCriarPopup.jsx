import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { useState } from "react";
import { createData } from "src/api/dataComponents";
import { Button, TextBox } from "src/components/Form";
import { PopupStatus } from "src/components/Pop-up/popupStatus";
import { usePopupStatic } from "src/hooks/usePopupStatic";
import { checkCamposInvalidos, isUserLogged } from "src/utils/dataControl";
import { statusResponse } from "src/utils/statusUtils";

export default function ClienteCriarPopup({ trigger }) {
	const [getEmpresa, setEmpresa] = useState("");
	const [getEmail, setEmail] = useState("");
	const [getTelefone, setTelefone] = useState("");
	const [getNif, setNif] = useState("");
	const { psOpen, psClose, psCreate, psCloseClear } = usePopupStatic();

	async function handleClienteSubmit() {
		if (checkCamposInvalidos(getEmpresa)) return false;
		const dataPost = {
			cliente_empresa: getEmpresa,
			cliente_telefone: getTelefone,
			cliente_email: getEmail,
			cliente_nif: getNif,
		};
		psClose();
		await statusResponse({
			asyncFunction: () => createData("/cliente/create", dataPost),
			successMessage: "Cliente adicionado com sucesso!",
		});
	}

	return (
		<div>
			<div onClick={psOpen}>{trigger}</div>
			{psCreate({
				psTitulo: "Adicionar cliente",
				psBody: (
					<div>
						<div className="row">
							<div className="col">
								<TextBox
									label={"Nome"}
									marginTop={3}
									inputType="name"
									handleChange={(e) => setEmpresa(e.target.value)}
									value={getEmpresa}
								/>
							</div>
							<div className="col">
								<TextBox
									label={"Nif"}
									marginTop={3}
									inputType="number"
									handleChange={(e) => setNif(e.target.value)}
									value={getNif}
									maxChar={9}
								/>
							</div>
						</div>
						<div className="row">
							<div className="col">
								<TextBox
									label={"Telefone"}
									marginTop={3}
									inputType="phone"
									handleChange={(e) => setTelefone(e.target.value)}
									value={getTelefone}
								/>
							</div>
							<div className="col">
								<TextBox
									label={"Email"}
									marginTop={3}
									inputType="email"
									handleChange={(e) => setEmail(e.target.value)}
									value={getEmail}
								/>
							</div>
						</div>
					</div>
				),
				psFooter: <Button label={"Adicionar"} handleClick={handleClienteSubmit} />,
			})}
		</div>
	);
}
