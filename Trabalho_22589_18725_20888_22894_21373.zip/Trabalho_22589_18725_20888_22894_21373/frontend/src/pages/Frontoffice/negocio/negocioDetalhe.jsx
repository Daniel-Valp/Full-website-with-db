import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React from "react";
import { Link, useNavigate, useParams } from "react-router-dom";

/** CSS */
import "./negocio.css";

/** Componentes */
import { createData, updateData, useData } from "src/api/dataComponents";
import { Button, ComboBox, TextArea, TextBox } from "src/components/Form";
import UserInfo from "src/components/OverlayTooltip/userInfo";
import BasicInfo from "src/components/OverlayTooltip/basicInfo";
import DropdownSection from "src/components/Section/dropdownSection";
import LoadingPage from "src/components/LoadingPage/loadingPage";
import {
	UserTemPerfis,
	comboBoxOptions,
	dropdownSectionOptions,
	formatComplete,
	navigateBack,
	parseDate,
} from "src/utils/functionUtils";
import Swal from "sweetalert2/dist/sweetalert2.js";
import { useState } from "react";
import RowFill from "src/layouts/Alignment/rowFill";
import Popup from "src/components/Pop-up/popup";
import PopupLoadable from "src/components/Pop-up/popupLoadable";
import { usePopup } from "src/hooks/usePopup";
import BoxData from "src/layouts/Alignment/boxData";
import { checkCamposInvalidos, isUserLogged } from "src/utils/dataControl";
import { PopupStatus } from "src/components/Pop-up/popupStatus";
import { useAuth } from "src/hooks/useAuth";
import { LoadWhile } from "src/components/LoadingPage/loadWhile";
import { checkTag, statusResponse } from "src/utils/statusUtils";
import { makeImageUrl } from "src/components/Imagens/utilizadorImagem";
import { Pode } from "src/components/Permissoes/Pode";
import { perfisId } from "src/data/constants";
import ApagarConfirmacao from "src/utils/dataManipulation";
import { myAxios } from "src/lib/axios";

export default function NegocioDetalhe(interacoes = []) {
	const { id } = useParams();
	const navigate = useNavigate();
	const utilizadorAtual = useAuth();
	const perfilSuperior = [perfisId.GNegocios];

	const [dataNegocios, loadingNegocio] = useData(`/negocio/get/${id}`);
	const [dataNegocioEstado, loadingNegocioEstado] = useData("/negocio/estado/list");
	const [selectedEstado, setSelectedEstado] = useState("");
	const { puIsOpen, puTitulo, puSubtitulo, puIcons, puBody, puFooter, puClose } = usePopup();

	const [clid, setclid] = useState("");
	const [clnome, setclnome] = useState("");
	const [clemail, setclemail] = useState("");
	const [clcargo, setclcargo] = useState("");
	const [cltelefone, setcltelefone] = useState("");

	const [newUtilizador, setNewUtilizador] = useState("");

	const [interaClienteContacto, setinteraClienteContacto] = useState("");
	const [interaDescricao, setinteraDescricao] = useState("");

	if (LoadWhile(loadingNegocio, loadingNegocioEstado)) return <LoadingPage />;

	var opcoesInteracoesContactos = [];

	dataNegocios.negcl_neg.map((cliente) => {
		cliente.neg_cli.cont_cliente?.map((contacto) => {
			opcoesInteracoesContactos.push({
				id: contacto?.clientecontacto_id,
				nome: `${contacto?.clientecontacto_nome} (${cliente?.neg_cli?.cliente_empresa})`,
			});
		});
	});

	var agendados = [];
	dataNegocios.reun_neg.map((item) => {
		agendados = dropdownSectionOptions(
			agendados,
			item.reuniao_id,
			item.reun_util.utilizador_tag,
			"agendou",
			"reunião",
			null,
			formatComplete(parseDate(item.reuniao_datacriacao)),
			<div>
				<h2>{item.reuniao_titulo}</h2>
				<div className="d-flex align-items-center">
					<FontAwesomeIcon icon={["fas", "clock"]} className="FontAwesomeIconsSmaller" />
					<p>{`${formatComplete(parseDate(item.reuniao_datainicio))} até ${formatComplete(
						parseDate(item.reuniao_datafim)
					)}`}</p>
				</div>
				<div className="d-flex align-items-center">
					<FontAwesomeIcon icon={["fas", "location-dot"]} className="FontAwesomeIconsSmaller" />
					<p>{item.reuniao_local}</p>
				</div>
				<br />
				<p>{item.reuniao_assunto}</p>
			</div>,
			<img src={makeImageUrl(item.reun_util.utilizador_imagem)} alt="" />,
			item.reun_util.utilizador_tag
		);
	});

	var interacoesDD = [];
	dataNegocios.negint_neg.map((item) => {
		interacoesDD = dropdownSectionOptions(
			interacoesDD,
			item.negociointeracao_id,
			item.negint_util.utilizador_tag,
			"fez interação com o cliente",
			item.negint_client.clientecontacto_nome,
			null,
			formatComplete(parseDate(item.negociointeracao_datacriacao)),
			<div>
				<p>
					<b>Resumo da interação:</b> {item.negociointeracao_descricao}
				</p>
			</div>,
			<img src={makeImageUrl(item.negint_util.utilizador_imagem)} alt="" />,
			item.negint_util.utilizador_tag
		);
	});

	async function handleEstadoUpdate(event) {
		const estado = event.target.value;
		const data = {
			negocio_estado: estado,
		};
		await updateData(`/negocio/update/${id}`, data);
	}

	function handleEncerrar() {
		return Swal.fire({
			title: "Encerrar",
			text: "O negócio foi concretizado?",
			type: "warning",
			showCancelButton: true,
			confirmButtonText: "Sim",
			cancelButtonText: "Não",
		}).then((result) => {
			if (!result.value) {
				Swal.fire({
					title: "Motivo da Perda",
					input: "textarea",
					inputAttributes: {
						autocapitalize: "off",
						rows: 5,
					},
					showCancelButton: true,
					confirmButtonText: "Confirmar",
				}).then((result) => {
					if (result.isConfirmed) {
						const data = {
							negocio_dataencerrado: new Date(),
							negocio_motivoperda: result.value,
						};
						updateData(`/negocio/update/${id}`, data);
					}
				});
			} else if (result.value) {
				const data = {
					negocio_dataencerrado: new Date(),
				};
				updateData(`/negocio/update/${id}`, data);
			}
		});
	}

	function handleAbrir() {
		return Swal.fire({
			title: "Abrir",
			text: "Tem certeza que pretende re-abrir o negócio?",
			type: "warning",
			showCancelButton: true,
			confirmButtonText: "Sim",
			cancelButtonText: "Não",
		}).then((result) => {
			if (result.value) {
				const data = {
					negocio_dataencerrado: null,
					negocio_motivoperda: result.value,
				};
				updateData(`/negocio/update/${id}`, data);
			}
		});
	}

	async function handleClienteContactoSubmit() {
		if (checkCamposInvalidos(clid, clnome, clcargo)) return false;
		const data = {
			clientecontacto_cliente: clid,
			clientecontacto_nome: clnome,
			clientecontacto_cargo: clcargo,
			clientecontacto_telefone: cltelefone,
			clientecontacto_email: clemail,
		};
		await createData(`/cliente/contacto/create`, data)
			.then((response) => {
				if (response) {
					PopupStatus("Cliente adicionado com sucesso!", "success");
				} else {
					PopupStatus("Ocorreu algum erro!", "error");
				}
			})
			.catch((error) => {
				PopupStatus("Ocorreu algum erro!", "error");
			});
	}

	function handleReuniaoAgendamento() {
		Swal.fire({
			title: "Criar reunião?",
			text: "Você será redirecionado!",
			type: "warning",
			showCancelButton: true,
			confirmButtonText: "Confirmar",
			cancelButtonText: "Cancelar",
		}).then((result) => {
			if (result.value) {
				setTimeout(() => {
					navigate(
						`/reunioes/criar?titulo=${dataNegocios.negocio_titulo}&area=${"Negócio"}&area-item=${
							dataNegocios.negocio_id
						}`
					);
				}, 0);
			}
		});
	}

	async function handleInteracaoSubmit() {
		if (!isUserLogged(utilizadorAtual)) return false;
		if (checkCamposInvalidos(interaClienteContacto, interaDescricao)) return false;
		const data = {
			negociointeracao_negocio: id,
			negociointeracao_clientecontacto: interaClienteContacto,
			negociointeracao_descricao: interaDescricao,
			negociointeracao_utilizador: utilizadorAtual.id,
		};
		await statusResponse({
			asyncFunction: () => createData("/negocio/interacao/create", data),
			successMessage: "Interação adicionada com sucesso!",
		});
	}

	async function handleAdicionarUtilizadorNegocio() {
		if (checkCamposInvalidos(newUtilizador)) return false;
		if (!checkTag(newUtilizador, true)) return false;
		const userExists = await myAxios({
			url: "/utilizador/search/exactMatch",
			method: "post",
			data: { utilizador_tag: newUtilizador },
		});
		if (!userExists.data?.exists) return false;
		const data = {
			negocioutilizador_utilizador: userExists.data.data[0].utilizador_id,
			negocioutilizador_negocio: id
		}
		await statusResponse({
			asyncFunction: () => createData("/negocio/adicionar-utilizador", data),
			successMessage: "Utilizador(es) adicionado(s) com sucesso!",
		});
	}

	return (
		<div>
			<div className="container my-2">
				<div className="row">
					<div className="col-md-12">
						{dataNegocios.negocio_dataencerrado && (
							<span className="badge bg-danger" title={dataNegocios.negocio_motivoperda}>
								Este négocio está encerrado
							</span>
						)}
						<div className="d-flex align-items-center">
							<h1>
								{dataNegocios.negocio_titulo}&nbsp;&nbsp;
								<Pode se={UserTemPerfis(perfilSuperior, utilizadorAtual.perfil)}>
									<Link to={`/negocios/editar/${id}`}>
										<FontAwesomeIcon icon={["fas", "pencil"]} className="FontAwesomeIcons" />
									</Link>
									&nbsp;&nbsp;
									<FontAwesomeIcon
										icon={["fas", "trash"]}
										className="FontAwesomeIcons perigo"
										onClick={() =>
											ApagarConfirmacao({
												route: "/negocio/delete/" + id,
												handleSuccess: () => navigateBack(),
											})
										}
									/>
								</Pode>
							</h1>
						</div>
						<div className="container">
							<div className="row">
								<div className="col-md-12" style={{ padding: 0 }}>
									<div className="d-flex align-items-center">
										<FontAwesomeIcon icon={["fas", "user"]} className="FontAwesomeIconsSmaller" />
										<div className="d-flex">
											<UserInfo
												utilizador={dataNegocios.neg_util}
												children={<p> {dataNegocios.neg_util.utilizador_tag} </p>}
											/>
										</div>
									</div>
									<div className="d-flex align-items-center desc-item">
										<FontAwesomeIcon icon={["fas", "building"]} className="FontAwesomeIconsSmaller" />
										{dataNegocios.negcl_neg.map((item, index) => (
											<div className="d-flex">
												<BasicInfo
													key={item.neg_cli.cliente_empresa}
													childrenOverlay={
														<div>
															<div className="d-flex align-items-center">
																<FontAwesomeIcon
																	icon={["fas", "envelope"]}
																	className="FontAwesomeIconsSmaller"
																/>
																<p>&nbsp; {item.neg_cli.cliente_email}</p>
															</div>
															<div className="d-flex align-items-center">
																<FontAwesomeIcon
																	icon={["fas", "phone"]}
																	className="FontAwesomeIconsSmaller"
																/>
																<p>&nbsp; {item.neg_cli.cliente_telefone}</p>
															</div>
														</div>
													}
													children={<p>{item.neg_cli.cliente_empresa}</p>}
												/>
												{index < dataNegocios.negcl_neg.length - 1 && <span>,&nbsp;</span>}
											</div>
										))}
									</div>
								</div>
							</div>
						</div>
						<div className="body">
							<div className="row" style={{ marginTop: "20px" }}>
								<div className="col-md-6">
									<BoxData>
										<h2>Tipo de Projeto</h2>
										<p>{dataNegocios.neg_tipoproj.negociotipoprojeto_nome}</p>
									</BoxData>
								</div>
								<div className="col-md-6">
									<BoxData>
										<h2>Área</h2>
										<p>{dataNegocios.neg_area.negocioarea_nome}</p>
									</BoxData>
								</div>
							</div>
							<Pode se={UserTemPerfis(perfilSuperior, utilizadorAtual?.perfil)}>
								<div className="row" style={{ marginTop: "20px" }}>
									<div className="col-md-6">
										<BoxData>
											<h2>Estado</h2>
											<div className="col-md-4">
												<ComboBox
													placeHolder="Estado"
													options={comboBoxOptions(
														dataNegocioEstado,
														"negocioestado_id",
														"negocioestado_nome"
													)}
													defaultValue={dataNegocios.negocio_estado}
													handleChange={handleEstadoUpdate}
													value={selectedEstado}
												/>
											</div>
										</BoxData>
									</div>
									<div className="col-md-6">
										<BoxData>
											<div className="d-flex align-items-center gap-2 mb-2">
												<h2 className="remove-margin-padding">Contactos</h2>
												<Popup
													popupKey={"add-contactos"}
													titulo={"Adicionar contactos"}
													trigger={
														<FontAwesomeIcon icon={["fas", "plus"]} className="FontAwesomeIcons" />
													}
													childrenBody={
														<div>
															<ComboBox
																label="Escolha o cliente"
																options={dataNegocios.negcl_neg.map((item) => ({
																	nome: item.neg_cli.cliente_empresa,
																	id: item.neg_cli.cliente_id,
																}))}
																defaultValue={clid}
																handleChange={(e) => setclid(e.target.value)}
																value={clid}
															/>
															<TextBox
																label={"Nome"}
																marginTop={3}
																handleChange={(e) => setclnome(e.target.value)}
															/>
															<TextBox
																label={"Cargo"}
																marginTop={3}
																handleChange={(e) => setclcargo(e.target.value)}
															/>
															<TextBox
																label={"Email (opcional)"}
																marginTop={3}
																handleChange={(e) => setclemail(e.target.value)}
															/>
															<TextBox
																label={"Telefone (opcional)"}
																marginTop={3}
																handleChange={(e) => setcltelefone(e.target.value)}
																inputType="number"
															/>
														</div>
													}
													childrenFooter={
														<Button label={"Adicionar"} handleClick={handleClienteContactoSubmit} />
													}
												/>
											</div>
											{dataNegocios.negcl_neg.map((negociocliente) => {
												return (
													<div className="d-flex">
														<div>
															{negociocliente.neg_cli.cont_cliente.map((contato) => (
																<div className="d-flex">
																	<p>
																		{contato.clientecontacto_nome} (
																		{contato.clientecontacto_cargo})
																	</p>
																	<div className="d-flex">
																		<BasicInfo
																			key={contato.clientecontacto_id}
																			childrenOverlay={
																				<p className="text-white">
																					{contato.clientecontacto_telefone}
																				</p>
																			}
																			children={
																				<FontAwesomeIcon
																					icon={["fas", "phone"]}
																					className="FontAwesomeIconsSmaller"
																				/>
																			}
																		/>
																		<BasicInfo
																			key={contato.clientecontacto_id}
																			childrenOverlay={
																				<p className="text-white">
																					{contato.clientecontacto_email}
																				</p>
																			}
																			children={
																				<FontAwesomeIcon
																					icon={["fas", "envelope"]}
																					className="FontAwesomeIconsSmaller"
																				/>
																			}
																			route={"mailto:" + contato.clientecontacto_email}
																		/>
																	</div>
																</div>
															))}
														</div>
													</div>
												);
											})}
										</BoxData>
									</div>
								</div>
							</Pode>
							<div className="row mt-3">
								<div className="col-md-6">
									<BoxData>
										<h2>Descrição</h2>
										<p>{dataNegocios.negocio_descricao}</p>
									</BoxData>
								</div>
							</div>
						</div>
						<div id="buttons" className="form-row btn-forms d-flex gap-3 mt-4 mb-5">
							<Popup
								popupKey={"adicionar-utilizadores"}
								trigger={<Button label={"Adicionar utilizador"} />}
								titulo={"Adicionar Utilizador"}
								childrenBody={
									<div>
										<TextBox
											label="Tag do utilizador"
											handleChange={(e) => setNewUtilizador(e.target.value)}
											marginTop={3}
										/>
									</div>
								}
								childrenFooter={
									<div>
										<Button label="Adicionar" handleClick={handleAdicionarUtilizadorNegocio} />
									</div>
								}
							/>
							<Pode se={UserTemPerfis(perfilSuperior, utilizadorAtual?.perfil)}>
								{dataNegocios.negocio_dataencerrado && (
									<Button label={"Abrir"} type="success" handleClick={handleAbrir} />
								)}
								{!dataNegocios.negocio_dataencerrado && (
									<Button label={"Encerrar"} type="danger" handleClick={handleEncerrar} />
								)}
							</Pode>
						</div>
						<RowFill>
							<Pode se={UserTemPerfis(perfilSuperior, utilizadorAtual?.perfil)}>
								<DropdownSection
									title={"Interações"}
									icons={
										<Popup
											trigger={
												<div>
													<FontAwesomeIcon icon={["fas", "plus"]} className="FontAwesomeIcons" />
												</div>
											}
											titulo={"Adicionar interação"}
											childrenBody={
												<div>
													<ComboBox
														label="Cliente contacto"
														options={opcoesInteracoesContactos}
														handleChange={(e) => setinteraClienteContacto(e.target.value)}
													/>
													<TextArea
														label={"Interação"}
														linhas={8}
														handleChange={(e) => setinteraDescricao(e.target.value)}
														marginTop={3}
													/>
												</div>
											}
											childrenFooter={<Button label={"Adicionar"} handleClick={handleInteracaoSubmit} />}
										/>
									}
									items={interacoesDD}
								/>
							</Pode>
							<DropdownSection
								title={"Reuniões"}
								icons={
									<Pode se={UserTemPerfis(perfilSuperior, utilizadorAtual.perfil)}>
										<div>
											<FontAwesomeIcon
												icon={["fas", "plus"]}
												className="FontAwesomeIcons"
												onClick={handleReuniaoAgendamento}
											/>
										</div>
									</Pode>
								}
								items={agendados}
							/>
						</RowFill>
					</div>
				</div>
			</div>
			{puIsOpen && (
				<PopupLoadable
					titulo={puTitulo}
					subtitulo={puSubtitulo}
					childrenHeaderIcons={puIcons}
					childrenBody={puBody}
					childrenFooter={puFooter}
					onClose={puClose}
				/>
			)}
		</div>
	);
}
