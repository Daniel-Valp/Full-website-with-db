import { Link } from "react-router-dom";
import React, { useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

import "./negocio.css";

import { Button, TextBox, ComboBox, TextArea } from "src/components/Form";
import { useData, createData } from "src/api/dataComponents";
import LoadingPage from "src/components/LoadingPage/loadingPage";
import { comboBoxOptions, navigateBack } from "src/utils/functionUtils";
import { PopupStatus } from "src/components/Pop-up/popupStatus";
import { useAuth } from "src/hooks/useAuth";
import ClienteCriarPopup from "../cliente/components/clienteCriarPopup";
import { checkCamposInvalidos, isUserLogged } from "src/utils/dataControl";
import { statusResponse } from "src/utils/statusUtils";
import { LoadWhile } from "src/components/LoadingPage/loadWhile";
import { useCarregando } from "src/hooks/useCarregando";

export default function NegocioCriar() {
	const [dataTipoProjetos, loadingTipoProjetos] = useData("/negocio/tipoprojeto/list");
	const [dataAreas, loadingAreas] = useData("/negocio/area/list");
	const [dataClientes, loadingClientes] = useData("/cliente/list");

	const utilizadorAtual = useAuth();
	const { startLoading, stopLoading } = useCarregando();

	/** Negocio submit */
	const [getTitulo, setTitulo] = useState("");
	const [getTipoProjeto, setTipoProjeto] = useState("");
	const [getArea, setArea] = useState("");
	const [getValor, setValor] = useState("");
	const [getCliente, setCliente] = useState("");
	const [getNecessidades, setNecessidades] = useState("");
	const [getDescricao, setDescricao] = useState("");

	if (LoadWhile(loadingTipoProjetos, loadingAreas, loadingClientes)) return <LoadingPage />;

	async function handleSubmit() {
		if (!isUserLogged(utilizadorAtual)) return false;
		if (checkCamposInvalidos(getTitulo, getTipoProjeto, getArea, getValor, getNecessidades, getDescricao)) return false;
		startLoading();
		const dataPost = {
			negocio_titulo: getTitulo,
			negocio_tipoprojeto: getTipoProjeto,
			negocio_area: getArea,
			negocio_valorestimado: getValor,
			negocio_necessidades: getNecessidades,
			negocio_descricao: getDescricao,
			negocio_utilizadorcriou: utilizadorAtual.id,
		};
		await statusResponse({
			asyncFunction: async () =>
				await createData("/negocio/create", dataPost).then( async (res) => {
					const clientenegocio = {
						negociocliente_cliente: getCliente,
						negociocliente_negocio: res.data.data.negocio_id,
					};
					await createData("/negocio/cliente/create", clientenegocio);
					PopupStatus("Negócio criado com sucesso", "success")
				}),
			successMessage: "Negócio criado com sucesso",
			errorMessage: null
		});
		stopLoading();
		navigateBack();
	}

	return (
		<div>
			<div className="NegocioCriar">
				<div className="container">
					<div className="row justify-content-center mt-5">
						<div className="col-md-6">
							<h1 className="text-center mb-4">Negócio - Criar</h1>
							<br />
							<form>
								<div className="form-row">
									<TextBox
										label={"Título"}
										marginTop={3}
										handleChange={(e) => setTitulo(e.target.value)}
										value={getTitulo}
									/>
									<div className="row">
										<div className="col">
											<ComboBox
												label="Tipo de Projeto"
												options={comboBoxOptions(
													dataTipoProjetos,
													"negociotipoprojeto_id",
													"negociotipoprojeto_nome"
												)}
												marginTop={3}
												handleChange={(e) => setTipoProjeto(e.target.value)}
												value={getTipoProjeto}
											/>
										</div>
										<div className="col">
											<ComboBox
												label="Área"
												options={comboBoxOptions(dataAreas, "negocioarea_id", "negocioarea_nome")}
												marginTop={3}
												handleChange={(e) => setArea(e.target.value)}
												value={getArea}
											/>
										</div>
									</div>
									<div className="row">
										<div className="col">
											<TextBox
												label="Valor"
												marginTop={3}
												addon="€"
												inputType="number"
												handleChange={(e) => setValor(e.target.value)}
												value={getValor}
											/>
										</div>
										<div className="col">
											<ComboBox
												label="Cliente"
												labelAddon={
													<ClienteCriarPopup
														trigger={
															<Link>
																<FontAwesomeIcon icon={["fas", "plus"]} />
															</Link>
														}
													/>
												}
												handleChange={(e) => setCliente(e.target.value)}
												value={getCliente}
												options={comboBoxOptions(dataClientes, "cliente_id", "cliente_empresa")}
												marginTop={3}
											/>
										</div>
									</div>
									<TextArea
										label={"Necessidades"}
										marginTop={3}
										handleChange={(e) => setNecessidades(e.target.value)}
										value={getNecessidades}
									/>
									<TextArea
										label={"Descrição"}
										marginTop={3}
										handleChange={(e) => setDescricao(e.target.value)}
										value={getDescricao}
									/>
								</div>
								<div className="d-flex gap-3">
									<Button label={"Criar"} handleClick={handleSubmit} marginTop={5} />
									<Button label={"Limpar"} type="outline-secondary" marginTop={5} />
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	);
}
