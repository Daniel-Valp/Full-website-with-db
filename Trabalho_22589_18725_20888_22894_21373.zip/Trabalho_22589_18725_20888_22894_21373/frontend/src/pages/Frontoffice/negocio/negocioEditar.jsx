import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { updateData, useData } from "src/api/dataComponents";
import BasicHeader from "src/components/BasicHeader/basicHeader";
import { Button, ComboBox, TextArea, TextBox } from "src/components/Form";
import { LoadWhile } from "src/components/LoadingPage/loadWhile";
import LoadingPage from "src/components/LoadingPage/loadingPage";
import { useAuth } from "src/hooks/useAuth";
import { useCarregando } from "src/hooks/useCarregando";
import { checkCamposInvalidos, isUserLogged } from "src/utils/dataControl";
import { comboBoxOptions, navigateBack } from "src/utils/functionUtils";
import { statusResponse } from "src/utils/statusUtils";

export default function NegocioEditar() {
	const { id } = useParams();
	const [dataNegocio, loadingNegocio] = useData(`/negocio/get/${id}`);
	const [dataTipoProjeto, loadingTipoProjeto] = useData("/negocio/tipoprojeto/list");
	const [dataEstado, loadingEstado] = useData("/negocio/estado/list");
	const [dataArea, loadingArea] = useData("/negocio/area/list");
	const utilizadorAtual = useAuth();
	const navigate = useNavigate();
	const { startLoading, stopLoading } = useCarregando();

	const [titulo, settitulo] = useState("");
	const [necessidade, setnecessidade] = useState("");
	const [descricao, setdescricao] = useState("");
	const [valorEstimado, setvalorEstimado] = useState("");
	const [tipoProjeto, settipoProjeto] = useState("");
	const [estado, setestado] = useState("");
	const [area, setarea] = useState("");

	useEffect(() => {
		if (dataNegocio) {
			settitulo(dataNegocio.negocio_titulo);
			setnecessidade(dataNegocio.negocio_necessidades);
			setdescricao(dataNegocio.negocio_descricao);
			setvalorEstimado(dataNegocio.negocio_valorestimado);
			settipoProjeto(dataNegocio.negocio_tipoprojeto);
			setestado(dataNegocio.negocio_estado);
			setarea(dataNegocio.negocio_area);
		}
	}, [dataNegocio]);

	if (LoadWhile(loadingTipoProjeto, loadingEstado, loadingArea, loadingNegocio)) return <LoadingPage />;

	async function handleUpdate() {
		if (!isUserLogged(utilizadorAtual)) return false;
		if (checkCamposInvalidos(titulo, necessidade, descricao, valorEstimado, tipoProjeto, estado, area)) return false;
		startLoading();
		const data = {
			negocio_titulo: titulo,
			negocio_necessidades: necessidade,
			negocio_descricao: descricao,
			negocio_valorestimado: valorEstimado,
			negocio_tipoprojeto: tipoProjeto,
			negocio_estado: estado,
			negocio_area: area,
		};
		await statusResponse({
			asyncFunction: () => updateData(`/negocio/update/${id}`, data),
			successMessage: "Negócio editado com sucesso!",
			handleSucess: () => navigateBack(),
		});
		stopLoading();
	}

	return (
		<div className="container">
			<BasicHeader pageTitulo={"Negócio - Editar"} />
			<TextBox label={"Título"} handleChange={(e) => settitulo(e.target.value)} value={titulo} marginTop={3} />
			<TextArea label={"Necessidades"} handleChange={(e) => setnecessidade(e.target.value)} value={necessidade} marginTop={3} />
			<TextArea label={"Descrição"} handleChange={(e) => setdescricao(e.target.value)} value={descricao} marginTop={3} />
			<TextBox
				label={"Valor estimado"}
				inputType="number"
				handleChange={(e) => setvalorEstimado(e.target.value)}
				value={valorEstimado}
				marginTop={3}
			/>
			<ComboBox
				label="Tipo projeto"
				handleChange={(e) => settipoProjeto(e.target.value)}
				defaultValue={tipoProjeto}
				options={comboBoxOptions(dataTipoProjeto, "negociotipoprojeto_id", "negociotipoprojeto_nome")}
				marginTop={3}
			/>
			<ComboBox
				label="Estado"
				handleChange={(e) => setestado(e.target.value)}
				defaultValue={estado}
				options={comboBoxOptions(dataEstado, "negocioestado_id", "negocioestado_nome")}
				marginTop={3}
			/>
			<ComboBox
				label="Area"
				handleChange={(e) => setarea(e.target.value)}
				defaultValue={area}
				options={comboBoxOptions(dataArea, "negocioarea_id", "negocioarea_nome")}
				marginTop={3}
			/>
			<Button label={"Confirmar"} handleClick={handleUpdate} marginTop={5} />
		</div>
	);
}
