import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Button } from "src/components/Form";
import BasicInfo from "src/components/OverlayTooltip/basicInfo";
import UserInfo from "src/components/OverlayTooltip/userInfo";
import { Link } from "react-router-dom";
import { UserTemPerfis, getStringDateDiff } from "src/utils/functionUtils";
import Popup from "src/components/Pop-up/popup";
import { perfisId } from "src/data/constants";
import { Pode } from "src/components/Permissoes/Pode";
import { useAuth } from "src/hooks/useAuth";

function printUtilizadores(data) {
	return (
		<div className="d-flex align-items-center">
			<FontAwesomeIcon icon={["fas", "users"]} className="FontAwesomeIconsSmaller" />
			{data.negutil_neg.map((item, index) => (
				<div className="d-flex">
					<UserInfo
						utilizador={item.negutil_util}
						children={
							<div className="d-flex">
								{item.negocioutilizador_avaliador ? (
									<div className="d-flex">
										<p>{item.negutil_util.utilizador_tag}</p>
										<FontAwesomeIcon icon={["fas", "crown"]} className="FontAwesomeIconsSmaller" />
									</div>
								) : (
									<p>{item.negutil_util.utilizador_tag}</p>
								)}
							</div>
						}
					/>
					{index < data.negutil_neg.length - 1 && <span>,&nbsp;</span>}
				</div>
			))}
		</div>
	);
}

function printClientes(data) {
	return (
		<div className="d-flex align-items-center desc-item">
			<FontAwesomeIcon icon={["fas", "building"]} className="FontAwesomeIconsSmaller" />
			{data.negcl_neg.map((item, index) => (
				<div className="d-flex">
					<BasicInfo
						key={item.neg_cli.cliente_empresa}
						childrenOverlay={
							<div>
								<div className="d-flex align-items-center">
									<FontAwesomeIcon icon={["fas", "envelope"]} className="FontAwesomeIconsSmaller" />
									<p>&nbsp;{item.neg_cli.cliente_email}</p>
								</div>
								<div className="d-flex align-items-center">
									<FontAwesomeIcon icon={["fas", "phone"]} className="FontAwesomeIconsSmaller" />
									<p>&nbsp;{item.neg_cli.cliente_telefone}</p>
								</div>
							</div>
						}
						children={<p>{item.neg_cli.cliente_empresa}</p>}
					/>
					{index < data.negcl_neg.length - 1 && <span>,&nbsp;</span>}
				</div>
			))}
		</div>
	);
}

export default function NegocioDetalhePopup({ trigger, data }) {
	const utilizadorAtual = useAuth();
	return (
		<Popup
			popupKey={data.negocio_id}
			trigger={trigger}
			titulo={data.negocio_titulo}
			subtitulo={
				<div className="d-flex">
					<UserInfo utilizador={data.neg_util} children={<p>{data.neg_util.utilizador_tag}</p>} />
					<p>&nbsp;{"· " + getStringDateDiff(data.negocio_datacriacao)}</p>
				</div>
			}
			childrenHeaderIcons={
				<Link to={`${data.negocio_id}`}>
					<FontAwesomeIcon
						icon={["fas", "expand"]}
						className="FontAwesomeIcons align-self-center"
						aria-label="Close"
						data-bs-dismiss="modal"
					/>
				</Link>
			}
			childrenBody={
				<div className="row">
					{printUtilizadores(data)}
					{printClientes(data)}
					<div className="box-info" style={{ paddingTop: "20px" }}>
						<h3>Descrição</h3>
						<p>{data.negocio_descricao}</p>
					</div>
				</div>
			}
			childrenFooter={
				<div className="d-flex justify-content-between gap-3">
					<Pode se={UserTemPerfis([perfisId.GNegocios], utilizadorAtual.perfil)}>
						<Button label={"Editar"} type="secondary" directTo={`/negocios/editar/${data.negocio_id}`} />
					</Pode>
				</div>
			}
		/>
	);
}
