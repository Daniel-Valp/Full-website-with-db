import React, { useState, useEffect } from "react";
import { DragDropContext, Draggable, Droppable } from "react-beautiful-dnd";
import { updateData, useData } from "src/api/dataComponents";
import LoadingPage from "src/components/LoadingPage/loadingPage";
import Card from "src/components/Cards/card";
import Popup from "src/components/Pop-up/popup";
import { getCssColors } from "src/data/colors";
import { sortByString } from "src/utils/dataManipulation";

function getItems(items, estado) {
	var itemList = [];
	itemList = items.map((item) => ({
		id: item.negocio_id.toString(),
		titulo: item.negocio_titulo,
		descricao: item.negocio_descricao,
		estado: estado,
	}));
	return itemList;
}

function getColumns(data) {
	const sortedData = sortByString(data, "negocioestado_id", true);
	const dataList = sortedData.map((item) => ({
		id: item.negocioestado_id,
		name: item.negocioestado_nome,
		items: getItems(item.neg_estado, item.negocioestado_id),
	}));

	return dataList;
}

const onDragEnd = (result, columns, setColumns, handleChangeUpdate) => {
	if (!result.destination) return;
	const { source, destination } = result;

	if (source.droppableId !== destination.droppableId) {
		const sourceColumn = columns[source.droppableId];
		const destColumn = columns[destination.droppableId];
		const sourceItems = [...sourceColumn.items];
		const destItems = [...destColumn.items];
		const [removed] = sourceItems.splice(source.index, 1);
		destItems.splice(destination.index, 0, removed);
		setColumns({
			...columns,
			[source.droppableId]: {
				...sourceColumn,
				items: sourceItems,
			},
			[destination.droppableId]: {
				...destColumn,
				items: destItems,
			},
		});

		const droppedItem = removed;
		handleChangeUpdate(droppedItem.id, parseInt(destination.droppableId) + 1);
	} else {
		const column = columns[source.droppableId];
		const copiedItems = [...column.items];
		const [removed] = copiedItems.splice(source.index, 1);
		copiedItems.splice(destination.index, 0, removed);
		setColumns({
			...columns,
			[source.droppableId]: {
				...column,
				items: copiedItems,
			},
		});
	}
};

export default function NegocioListaBoard() {
	const [dataEstado, loadingEstado] = useData("/negocio/estado/list");
	const [columns, setColumns] = useState("");

	useEffect(() => {
		if (!loadingEstado) {
			const initialColumns = getColumns(dataEstado);
			setColumns(initialColumns);
		}
	}, [loadingEstado, dataEstado]);

	if (loadingEstado) {
		return <LoadingPage />;
	}

	async function handleChangeUpdate(id, estado) {
		const data = {
			negocio_estado: estado,
		};
		await updateData(`/negocio/update/${id}`, data);
	}

	return (
		<div>
			<div className="overflow-x no-select d-flex" style={{ height: "100%", overflowX: "auto" }}>
				<DragDropContext onDragEnd={(result) => onDragEnd(result, columns, setColumns, handleChangeUpdate)}>
					{Object.entries(columns).map(([columnId, column], index) => {
						return (
							<div
								className="d-flex align-items-center"
								style={{ flexDirection: "column" }}
								key={index.toString()}
							>
								<h2>{column.name}</h2>
								<div style={{ margin: 8 }}>
									<Droppable droppableId={index.toString()} key={index.toString()}>
										{(provided, snapshot) => {
											return (
												<div
													{...provided.droppableProps}
													ref={provided.innerRef}
													style={{
														background: snapshot.isDraggingOver
															? getCssColors("light-primary-color")
															: getCssColors("divider-color"),
														padding: 4,
														width: 250,
														minHeight: "70vh",
														borderRadius: "10px",
													}}
												>
													{column.items.map((item, index) => {
														return (
															<Draggable key={item.id} draggableId={item.id} index={index}>
																{(provided, snapshot) => {
																	return (
																		<div
																			ref={provided.innerRef}
																			{...provided.draggableProps}
																			{...provided.dragHandleProps}
																			style={{
																				userSelect: "none",
																				margin: "0 0 8px 0",
																				minHeight: "50px",
																				/*backgroundColor: snapshot.isDragging ? "#263B4A" : "#456C86",*/
																				...provided.draggableProps.style,
																			}}
																		>
																			<Card
																				titulo={item.titulo}
																				descricao={item.descricao}
																				directTo={`/negocios/${item.id}`}
																			/>
																		</div>
																	);
																}}
															</Draggable>
														);
													})}
													{provided.placeholder}
												</div>
											);
										}}
									</Droppable>
								</div>
							</div>
						);
					})}
				</DragDropContext>
			</div>
		</div>
	);
}
