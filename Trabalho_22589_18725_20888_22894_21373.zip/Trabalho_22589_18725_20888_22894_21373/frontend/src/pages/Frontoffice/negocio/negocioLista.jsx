import { Link, useNavigate } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

/** Components */
import Card from "src/components/Cards/card";
import { Button, ComboBox, DatePicker, SearchBox } from "src/components/Form";
import { useData } from "src/api/dataComponents";

/** Outros */
import LoadingPage from "src/components/LoadingPage/loadingPage";
import { UserTemPerfis, comboBoxManual, comboBoxOptions, getStringDateDiff } from "src/utils/functionUtils";
import NegocioDetalhePopup from "./components/negocioDetalhePopup";
import { useState } from "react";
import { filterByComboBox, filterByDate, filterDataByAllColumns, sortByDate } from "src/utils/dataManipulation";
import Row from "src/layouts/Alignment/row";
import { useAuth } from "src/hooks/useAuth";
import { useCarregando } from "src/hooks/useCarregando";
import { perfisId } from "src/data/constants";
import { LoadWhile } from "src/components/LoadingPage/loadWhile";
import { useUserBasedFetch } from "src/hooks/useUserBasedFetch";
import { Pode } from "src/components/Permissoes/Pode";
import { PaginationList } from "src/components/Pagination/paginationList";

export default function NegocioLista() {
	const [dataNegocioArea, loadingNegocioArea] = useData("/negocio/area/list");
	const [dataNegocioTipoProjeto, loadingNegocioTipoProjeto] = useData("/negocio/tipoprojeto/list");
	const [dataNegocioEstado, loadingNegocioEstado] = useData("/negocio/estado/list");

	const utilizadorAtual = useAuth();
	const { startLoading, stopLoading } = useCarregando();
	const navigate = useNavigate();

	const [filtersearchTerm, setfiltersearchTerm] = useState("");
	const [filterTipoProjeto, setfilterTipoProjeto] = useState(-1);
	const [filterArea, setfilterArea] = useState(-1);
	const [filterEstado, setfilterEstado] = useState(-1);
	const [filterDataRangeFirst, setfilterDataRangeFirst] = useState("");
	const [filterDataRangeSecond, setfilterDataRangeSecond] = useState("");
	const [filterValor, setfilterValor] = useState("");

	const [dataNegocio, setdataNegocio, hasPerfilNegocio] = useUserBasedFetch({
		perfisPermitidos: [perfisId.GNegocios],
		generalBaseUrl: "/negocio/list",
		userIdentifier: "negocio_utilizadorcriou",
	});

	if (LoadWhile(loadingNegocioArea, loadingNegocioTipoProjeto, loadingNegocioEstado, !dataNegocio)) return <LoadingPage />;

	if (!hasPerfilNegocio && dataNegocio.length === 0) {
		setTimeout(() => {
			navigate("/negocios/criar");
		}, 0);
	}

	function Load() {
		var filteredData = filterDataByAllColumns(dataNegocio, filtersearchTerm);
		filteredData = filterByComboBox(filteredData, filterTipoProjeto, "negocio_tipoprojeto");
		filteredData = filterByComboBox(filteredData, filterArea, "negocio_area");
		filteredData = filterByComboBox(filteredData, filterEstado, "negocio_estado");
		filteredData = filterByDate(filteredData, "negocio_dataencerrado", filterDataRangeFirst, filterDataRangeSecond);
		const sortedData = sortByDate(filteredData, "negocio_datacriacao");
		const cardElements = sortedData.map((data, index) => {
			return (
				<div className="col-md-4 mt-3">
					<NegocioDetalhePopup
						trigger={
							<Card
								titulo={data.negocio_titulo}
								descricao={data.negocio_descricao}
								utilizador={data.neg_util}
								date={getStringDateDiff(data.negocio_datacriacao)}
							/>
						}
						data={data}
					/>
				</div>
			);
		});
		return cardElements;
	}

	function handleFilterClear() {
		setfiltersearchTerm("");
		setfilterTipoProjeto(-1);
		setfilterArea(-1);
		setfilterEstado(-1);
		setfilterDataRangeFirst("");
		setfilterDataRangeSecond("");
		setfilterValor("");
	}
	return (
		<div>
			<PaginationList
				cardsProps={Load()}
				pageTitulo={"Negócios"}
				pageChildrenIcons={
					<div className="icon-bar">
						<Pode se={UserTemPerfis([perfisId.GNegocios], utilizadorAtual.perfil)}>
							<Link to={`board`}>
								<FontAwesomeIcon icon={["fas", "table-columns"]} className="FontAwesomeIcons" />
							</Link>
						</Pode>
						<Link to={`criar`}>
							<FontAwesomeIcon icon={["fas", "plus"]} className="FontAwesomeIcons" />
						</Link>
					</div>
				}
				pageChildrenFilter={
					<div className="gap-3 d-flex justify-content-end">
						<SearchBox
							handleChange={(e) => setfiltersearchTerm(e.target.value)}
							label={"Pesquisar"}
							value={filtersearchTerm}
						/>
						<Pode se={hasPerfilNegocio}>
							<Row>
								<ComboBox
									options={[
										...comboBoxManual(-1, "Todas"),
										...comboBoxOptions(dataNegocioArea, "negocioarea_id", "negocioarea_nome"),
									]}
									label="Area"
									defaultValue={filterArea}
									handleChange={(e) => setfilterArea(e.target.value)}
									value={filterArea}
								/>
								<DatePicker
									label={"Inicio"}
									handleChange={(e) => setfilterDataRangeFirst(e.target.value)}
									value={filterDataRangeFirst}
								/>
								<DatePicker
									label={"Fim"}
									handleChange={(e) => setfilterDataRangeSecond(e.target.value)}
									value={filterDataRangeSecond}
								/>
								<ComboBox
									options={[
										...comboBoxManual(-1, "Todas"),
										...comboBoxOptions(
											dataNegocioTipoProjeto,
											"negociotipoprojeto_id",
											"negociotipoprojeto_nome"
										),
									]}
									label="Tipo Projeto"
									defaultValue={filterTipoProjeto}
									handleChange={(e) => setfilterTipoProjeto(e.target.value)}
									value={filterTipoProjeto}
								/>
								<ComboBox
									options={[
										...comboBoxManual(-1, "Todas"),
										...comboBoxOptions(dataNegocioEstado, "negocioestado_id", "negocioestado_nome"),
									]}
									label="Estado"
									defaultValue={filterEstado}
									handleChange={(e) => setfilterEstado(e.target.value)}
									value={filterEstado}
								/>
							</Row>
						</Pode>
						<div className="d-flex justify-content-end mt-auto">
							<Button label={"Limpar"} handleClick={handleFilterClear} />
						</div>
					</div>
				}
			/>
		</div>
	);
}
