import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { updateData, useData } from "src/api/dataComponents";
import { Button, ComboBox, TextArea, TextBox } from "src/components/Form";
import { LoadWhile } from "src/components/LoadingPage/loadWhile";
import { useAuth } from "src/hooks/useAuth";
import { useCarregando } from "src/hooks/useCarregando";
import { comboBoxOptions, navigateBack } from "src/utils/functionUtils";
import { checkCamposInvalidos, isUserLogged } from "src/utils/dataControl";
import { statusResponse } from "src/utils/statusUtils";
import { useEffect } from "react";
import BasicHeader from "src/components/BasicHeader/basicHeader";
import LoadingPage from "src/components/LoadingPage/loadingPage";

export default function VagaEditar() {
	const { id } = useParams();
	const [dataVaga, loadingVaga] = useData(`/vaga/get/${id}`);
	const [dataModalidade, loadingModalidade] = useData("/vaga/modalidadecontratacao/list");
	const [dataTipo, loadingTipo] = useData("/vaga/tipo/list");
	const utilizadorAtual = useAuth();
	const navigate = useNavigate();
	const { startLoading, stopLoading } = useCarregando();

	const [titulo, settitulo] = useState("");
	const [localizacao, setlocalizacao] = useState("");
	const [descricao, setdescricao] = useState("");
	const [oferecemos, setoferecemos] = useState("");
	const [numerocandidatos, setnumerocandidatos] = useState("");
	const [modalidadecontratacao, setmodalidadecontratacao] = useState("");
	const [tipo, settipo] = useState("");

	useEffect(() => {
		if (dataVaga) {
			settitulo(dataVaga.vaga_titulo);
			setlocalizacao(dataVaga.vaga_localizacao);
			setdescricao(dataVaga.vaga_descricao);
			setoferecemos(dataVaga.vaga_oferecemos);
			setnumerocandidatos(dataVaga.vaga_numerocandidatos);
			setmodalidadecontratacao(dataVaga.vaga_modalidadecontratacao);
			settipo(dataVaga.vaga_tipo);
		}
	}, [dataVaga]);

	if (LoadWhile(loadingTipo, loadingModalidade, loadingVaga)) return <LoadingPage />;

	async function handleUpdate() {
		if (!isUserLogged(utilizadorAtual)) return false;
		if (checkCamposInvalidos(titulo, localizacao, descricao, oferecemos, numerocandidatos, modalidadecontratacao, tipo))
			return false;
		startLoading();
		const data = {
			vaga_titulo: titulo,
			vaga_localizacao: localizacao,
			vaga_descricao: descricao,
			vaga_oferecemos: oferecemos,
			vaga_numerocandidatos: numerocandidatos,
			vaga_modalidadecontratacao: modalidadecontratacao,
			vaga_tipo: tipo,
		};
		await statusResponse({
			asyncFunction: () => updateData(`/vaga/update/${id}`, data),
			successMessage: "Vaga editada com sucesso!",
			handleSucess: () => navigateBack(),
		});
		stopLoading();
	}

	return (
		<div className="container">
			<BasicHeader pageTitulo={"Vaga - Editar"} />
			<TextBox label={"Título"} handleChange={(e) => settitulo(e.target.value)} value={titulo} />
			<TextBox label={"Localização"} handleChange={(e) => setlocalizacao(e.target.value)} value={localizacao} />
			<TextArea label={"Oferecemos"} handleChange={(e) => setoferecemos(e.target.value)} value={oferecemos} />
			<TextArea label={"Descrição"} handleChange={(e) => setdescricao(e.target.value)} value={descricao} />
			<TextBox
				label={"Número candidatos"}
				inputType="number"
				handleChange={(e) => setnumerocandidatos(e.target.value)}
				value={numerocandidatos}
			/>
			<ComboBox
				label="Modalidade de contratação"
				handleChange={(e) => setmodalidadecontratacao(e.target.value)}
				defaultValue={modalidadecontratacao}
				options={comboBoxOptions(dataModalidade, "modalidadecontratacao_id", "modalidadecontratacao_nome")}
			/>
			<ComboBox
				label="Tipo"
				handleChange={(e) => settipo(e.target.value)}
				defaultValue={tipo}
				options={comboBoxOptions(dataTipo, "vagatipo_id", "vagatipo_nome")}
			/>
			<Button label={"Confirmar"} handleClick={handleUpdate} marginTop={5} />
		</div>
	);
}
