import { Link } from "react-router-dom";
import React, { useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

/** CSS */
import "./vaga.css";

/** Components */
import Card from "src/components/Cards/card";
import { useData } from "src/api/dataComponents";
import LoadingPage from "src/components/LoadingPage/loadingPage";
import { PaginationList } from "src/components/Pagination/paginationList";
import { Button, SearchBox, ComboBox } from "src/components/Form";
import { UserTemPerfis, comboBoxOptions, getStringDateDiff } from "src/utils/functionUtils.js";
import VagaDetalhePopup from "./components/vagaDetalhePopup";
import RecomendacaoCriarPopup from "../recomendacao/components/recomendacaoCriarPopup";
import { filterByComboBox, filterDataByAllColumns, sortByDate } from "src/utils/dataManipulation";
import { useEffect } from "react";
import { Pode } from "src/components/Permissoes/Pode";
import { perfisId } from "src/data/constants";
import { useAuth } from "src/hooks/useAuth";
import { LoadWhile } from "src/components/LoadingPage/loadWhile";

export default function VagaLista() {
	const [dataVaga, loading] = useData("/vaga/list");
	const [dataTipo, loadingTipo] = useData("/vaga/tipo/list");
	const [dataModalidade, loadingModalidade] = useData("/vaga/modalidadecontratacao/list");

	const [searchTerm, setSearchTerm] = useState("");
	const [getTipo, setTipo] = useState(-1);
	const [getModalidade, setModalidade] = useState(-1);
	const utilizadorAtual = useAuth();

	const perfilSuperior = [perfisId.RH];

	useEffect(() => {
		LoadVagas();
	}, []);

	if (LoadWhile(loading, loadingTipo, loadingModalidade)) return <LoadingPage />;

	function LoadVagas() {
		var filteredData = filterDataByAllColumns(dataVaga, searchTerm);
		filteredData = filterByComboBox(filteredData, getTipo, "vaga_tipo");
		filteredData = filterByComboBox(filteredData, getModalidade, "vaga_modalidadecontratacao");
		if (UserTemPerfis([perfisId.RH], utilizadorAtual.perfil)) {
		} else if (UserTemPerfis([perfisId.Colaborador, perfisId.GNegocios, perfisId.GIdeias], utilizadorAtual.perfil)) {
			filteredData = filteredData.filter(function (item) {
				return item.vaga_tipo !== 2;
			});
		} else {
			filteredData = filteredData.filter(function (item) {
				return item.vaga_tipo !== 1;
			});
		}
		const sortedData = sortByDate(filteredData, "vaga_datacriacao");
		return sortedData.map((data) => {
			return (
				<div className="col-md-4 mt-3">
					<VagaDetalhePopup
						trigger={
							<Card
								titulo={data.vaga_titulo}
								descricao={data.vaga_descricao}
								utilizador={data.vaga_util}
								date={getStringDateDiff(data.vaga_datacriacao)}
							/>
						}
						data={data}
					/>
				</div>
			);
		});
	}

	function handleFilterClear() {
		setSearchTerm("");
		setTipo(-1);
		setModalidade(-1);
	}

	return (
		<div>
			<PaginationList
				cardsProps={LoadVagas()}
				pageTitulo={"Vagas"}
				pageChildrenFilter={
					<div className="gap-3 d-flex justify-content-end">
						<SearchBox handleChange={(e) => setSearchTerm(e.target.value)} />
						<ComboBox
							options={comboBoxOptions(dataModalidade, "modalidadecontratacao_id", "modalidadecontratacao_nome")}
							placeHolder="Modalidade de Contratação"
							defaultOption={"Todas"}
							handleChange={(e) => setModalidade(e.target.value)}
							value={getModalidade}
						/>
						<Pode se={UserTemPerfis(perfilSuperior, utilizadorAtual.perfil)}>
							<ComboBox
								options={comboBoxOptions(dataTipo, "vagatipo_id", "vagatipo_nome")}
								placeHolder="Tipo da Vaga"
								defaultOption={"Todas"}
								handleChange={(e) => setTipo(e.target.value)}
								value={getTipo}
							/>
						</Pode>

						<div className="d-flex justify-content-end mt-auto">
							<Button label={"Limpar"} handleClick={handleFilterClear} />
						</div>
					</div>
				}
				pageChildrenIcons={
					<div className="d-flex gap-2">
						<Pode se={UserTemPerfis(perfilSuperior, utilizadorAtual.perfil)}>
							<Link to={`/reporting/contratacoes`}>
								<FontAwesomeIcon icon={["fas", "chart-line"]} title="Adicionar" className="FontAwesomeIcons" />
							</Link>
							<Link to={`/vagas/criar`}>
								<FontAwesomeIcon icon={["fas", "plus"]} title="Adicionar" className="FontAwesomeIcons" />
							</Link>
						</Pode>
						<RecomendacaoCriarPopup
							trigger={
								<FontAwesomeIcon icon={["fas", "face-smile"]} title="Recomendar" className="FontAwesomeIcons" />
							}
						/>
					</div>
				}
			/>
		</div>
	);
}
