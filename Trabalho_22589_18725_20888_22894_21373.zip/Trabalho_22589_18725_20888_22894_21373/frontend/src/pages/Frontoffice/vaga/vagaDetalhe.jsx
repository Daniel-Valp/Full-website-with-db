import { Link, useParams } from "react-router-dom";
import { useData } from "src/api/dataComponents";
import LoadingPage from "src/components/LoadingPage/loadingPage";
import { dropdownSectionOptions, formatDateTime, getStringDateDiff, parseDate } from "src/utils/functionUtils";
import DropdownSection from "src/components/Section/dropdownSection";
import img from "src/assets/images/arvores.jpg";
import { Button } from "src/components/Form";
import UserInfo from "src/components/OverlayTooltip/userInfo";
import RowFill from "src/layouts/Alignment/rowFill";
import { LoadWhile } from "src/components/LoadingPage/loadWhile";

export default function VagaDetalhe() {
	const { id } = useParams();
	const [dataVaga, loadingVaga] = useData(`/vaga/get/${id}`);

	if (LoadWhile(loadingVaga)) return <LoadingPage />;

	var reunioes = [];
	var recomendacoes = [];
	var candidaturas = [];

	try {
		dataVaga?.reunvaga_vaga.map((reuniaoItem) => {
			reunioes = dropdownSectionOptions(
				reunioes,
				reuniaoItem.reun_vaga.reuniao_id,
				reuniaoItem.reun_vaga.reun_util.utilizador_tag,
				"agendou",
				"reunião",
				null,
				`Começa em: ${getStringDateDiff(reuniaoItem.reun_vaga.reuniao_inicio)} | Criada há: ${getStringDateDiff(
					reuniaoItem.reun_vaga.reuniao_datacriacao
				)}`,
				<div>
					<p>{"Data Início: " + formatDateTime(parseDate(reuniaoItem.reun_vaga.reuniao_datacriacao))}</p>
					<p>{"Local: " + reuniaoItem.reun_vaga.reuniao_local}</p>
					<h3>{reuniaoItem.reun_vaga.reuniao_titulo}</h3>
					<p>{reuniaoItem.reun_vaga.reuniao_assunto}</p>
				</div>,
				img
			);
		});
	} catch (error) {
		reunioes = null;
	}

	try {
		dataVaga?.recom_vaga.map((recomendacaoItem) => {
			recomendacoes = dropdownSectionOptions(
				recomendacoes,
				recomendacaoItem.recomendacao_id,
				recomendacaoItem.recom_util.utilizador_tag,
				"recomendou",
				null,
				recomendacaoItem.recomendacao_utilizadorrecomendado,
				`Criada há: ${getStringDateDiff(recomendacaoItem.recomendacao_datacriacao)}`,
				<div>
					<p>{"Motivo: " + recomendacaoItem.recomendacao_motivo}</p>
					<p>{"Curriculum: " + recomendacaoItem.recomendacao_curriculum}</p>
				</div>,
				img
			);
		});
	} catch (error) {
		reunioes = null;
	}

	try {
		dataVaga?.cand_vaga.map((candItem) => {
			candidaturas = dropdownSectionOptions(
				candidaturas,
				candItem.candidatura_id,
				candItem?.cand_util?.utilizador_tag,
				"candidatou-se",
				null,
				null,
				`Criada há: ${getStringDateDiff(candItem?.candidatura_datacriacao)}`,
				<div>
					<p>
						{"Descrição: " +
							candItem.candidatura_descricao +
							" (" +
							candItem?.cand_estado?.candidaturaestado_nome +
							")"}
					</p>
					<p>{"Curriculum: " + candItem.candidatura_curriculum}</p>
					<Button
						label={"Agendar Reunião"}
						marginTop={3}
						directTo={`/reunioes/criar?area=${"Candidatura"}&area-item=${candItem.candidatura_id}&titulo=${
							dataVaga.vaga_titulo
						} | ${dataVaga.vaga_util.utilizador_tag}`}
					/>
				</div>,
				img
			);
		});
	} catch (error) {
		reunioes = null;
	}

	return (
		<div>
			<div className="container">
				<h1>{dataVaga.vaga_titulo}</h1>
				<div className="d-flex">
					<UserInfo utilizador={dataVaga.vaga_util} children={<p>{dataVaga.vaga_util.utilizador_tag}</p>} />
					<p>&nbsp;{"· " + getStringDateDiff(dataVaga.vaga_datacriacao)}</p>
				</div>
				<div className="row" style={{ marginTop: "20px" }}>
					<div className="col-md-6">
						<div className="box-info">
							<h2>Tipo</h2>
							<p>{dataVaga.vaga_tipos.vagatipo_nome}</p>
						</div>
					</div>
					<div className="col-md-6">
						<div className="box-info">
							<h2>Modalidade da contratação</h2>
							<p>{dataVaga.vaga_modal.modalidadecontratacao_nome}</p>
						</div>
					</div>
				</div>
				<div className="row" style={{ marginTop: "20px" }}>
					<div className="col-md-6">
						<div className="box-info">
							<h2>Localização</h2>
							<p>{dataVaga.vaga_localizacao}</p>
						</div>
					</div>
					<div className="col-md-6">
						<div className="box-info">
							<h2>Número de candidatos</h2>
							<p>
								{dataVaga.vaga_numerocandidatos === null ? "Não foi definido" : dataVaga.vaga_numerocandidatos}
							</p>
						</div>
					</div>
				</div>
				<div className="row" style={{ marginTop: "20px" }}>
					<div className="col-md-12">
						<div className="box-info">
							<h2>Oferecemos</h2>
							<p>{dataVaga.vaga_oferecemos}</p>
						</div>
					</div>
				</div>
				<div className="row" style={{ marginTop: "20px" }}>
					<div className="col-md-12">
						<div className="box-info">
							<h2>Descrição</h2>
							<p>{dataVaga.vaga_descricao}</p>
						</div>
					</div>
				</div>
				<div className="butoes-row mt-4 d-flex gap-3">
					<Button label={"Editar"} type="outline-primary" />
					<Button label={"Encerrar"} type="danger" />
				</div>
				<div className="mt-5">
					<RowFill>
						{/* <DropdownSection title={"Reuniões"} items={reunioes} /> */}
						<DropdownSection title={"Recomendações"} items={recomendacoes} />
						<DropdownSection title={"Candidaturas"} items={candidaturas} />
					</RowFill>
				</div>
			</div>
		</div>
	);
}
