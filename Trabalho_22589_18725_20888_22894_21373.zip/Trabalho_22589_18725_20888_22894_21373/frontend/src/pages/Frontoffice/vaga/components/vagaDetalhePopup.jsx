import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Button } from "src/components/Form";
import { Link } from "react-router-dom";
import { UserTemPerfis, getStringDateDiff } from "src/utils/functionUtils";
import UserInfo from "src/components/OverlayTooltip/userInfo";
import Popup from "src/components/Pop-up/popup";
import { perfisId } from "src/data/constants";
import { Pode } from "src/components/Permissoes/Pode";
import { useAuth } from "src/hooks/useAuth";
import BoxData from "src/layouts/Alignment/boxData";
import RecomendacaoCriarPopup from "../../recomendacao/components/recomendacaoCriarPopup";

export default function VagaDetalhePopup({ trigger, data }) {
	const perfilSuperior = [perfisId.RH];
	const utilizadorAtual = useAuth();
	return (
		<Popup
			popupKey={data.vaga_id}
			titulo={<div>{data.vaga_titulo}</div>}
			subtitulo={
				<div className="d-flex">
					<UserInfo utilizador={data.vaga_util} children={<p>{data.vaga_util.utilizador_tag}</p>} />
					<p>&nbsp;{"· " + getStringDateDiff(data.vaga_datacriacao)}</p>
					<Pode se={UserTemPerfis(perfilSuperior, utilizadorAtual.perfil)}>
						<p>&nbsp;{"· " + data.cand_vaga.length + " candidaturas"}</p>
					</Pode>
				</div>
			}
			trigger={trigger}
			childrenHeaderIcons={
				<Pode se={UserTemPerfis(perfilSuperior, utilizadorAtual.perfil)}>
					<Link Link to={`/vagas/${data.vaga_id}`}>
						<FontAwesomeIcon
							icon={["fas", "expand"]}
							className="FontAwesomeIcons align-self-center"
							aria-label="Close"
							data-bs-dismiss="modal"
							title="Expandir"
						/>
					</Link>
				</Pode>
			}
			childrenBody={
				<div div>
					<div className="row">
						<Pode se={UserTemPerfis(perfilSuperior, utilizadorAtual.perfil)}>
							<div className="col-md-6">
								<BoxData>
									<h2>Tipo</h2>
									<p>{data.vaga_tipos.vagatipo_nome}</p>
								</BoxData>
							</div>
						</Pode>
						<div className="col-md-6">
							<BoxData>
								<h2>Modalidade da contratação</h2>
								<p>{data.vaga_modal.modalidadecontratacao_nome}</p>
							</BoxData>
						</div>
					</div>
					<div className="row" style={{ marginTop: "20px" }}>
						<div className="col-md-6">
							<BoxData>
								<h2>Localização</h2>
								<p>{data.vaga_localizacao}</p>
							</BoxData>
						</div>
						<Pode se={UserTemPerfis(perfilSuperior, utilizadorAtual.perfil)}>
							<div className="col-md-6">
								<BoxData>
									<h2>Número de contratações</h2>
									<p>
										{data.vaga_numerocandidatos === null ? "Não foi definido" : data.vaga_numerocandidatos}
									</p>
								</BoxData>
							</div>
						</Pode>
					</div>
					<div className="row" style={{ marginTop: "20px" }}>
						<div className="col-md-12">
							<BoxData>
								<h2>Oferecemos</h2>
								<p>{data.vaga_oferecemos}</p>
							</BoxData>
						</div>
					</div>
					<div className="row" style={{ marginTop: "20px" }}>
						<div className="col-md-12">
							<BoxData>
								<h2>Descrição</h2>
								<p>{data.vaga_descricao}</p>
							</BoxData>
						</div>
					</div>
				</div>
			}
			childrenFooter={
				<div div className="d-flex gap-3">
					<Pode se={UserTemPerfis(perfilSuperior, utilizadorAtual.perfil)}>
						<Button
							label={"Candidaturas"}
							type="outline-secondary"
							directTo={`/candidaturas?vaga=${data.vaga_id}`}
						/>

						<Button
							label={"Recomendações"}
							type="outline-secondary"
							directTo={`/recomendacoes?vaga=${data.vaga_id}`}
						/>
						<Button label={"Editar"} type="secondary" directTo={`/vagas/editar/${data.vaga_id}`} />
					</Pode>
					<RecomendacaoCriarPopup trigger={<Button label={"Recomendar"} />} preselectedValue={data.vaga_id} />
					<Button label={"Candidatar-me"} type="primary" directTo={`/vagas/candidatar-me/${data.vaga_id}`} />
				</div>
			}
		/>
	);
}
