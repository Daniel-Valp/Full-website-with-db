import { useState } from "react";
import BasicHeader from "src/components/BasicHeader/basicHeader";
import { Button, ComboBox, TextArea, TextBox } from "src/components/Form";
import { useData, createData } from "src/api/dataComponents";
import LoadingPage from "src/components/LoadingPage/loadingPage";
import { comboBoxOptions, navigateBack } from "src/utils/functionUtils";
import Row from "src/layouts/Alignment/row";
import { useCarregando } from "src/hooks/useCarregando";
import { PopupStatus } from "src/components/Pop-up/popupStatus";
import { useAuth } from "src/hooks/useAuth";
import { useNavigate } from "react-router-dom";
import { checkCamposInvalidos, isUserLogged } from "src/utils/dataControl";

export default function VagaCriar() {
	const navigate = useNavigate();
	const [dataVagaTipo, loadingVagaTipo] = useData("/vaga/tipo/list");
	const [dataVagaModalidade, loadingVagaModalidade] = useData("/vaga/modalidadecontratacao/list");
	const { startLoading, stopLoading } = useCarregando();
	const utilizadorAtual = useAuth();

	// Vagas
	const [getVagaTitulo, setVagaTitulo] = useState("");
	const [getVagaTipo, setVagaTipo] = useState("");
	const [getVagaModalidade, setVagaModalidade] = useState("");
	const [getVagaLocalizacao, setVagaLocalizacao] = useState("");
	const [getVagaNumeroCandidatos, setVagaNumeroCandidatos] = useState("");
	const [getVagaOferecemos, setVagaOferecemos] = useState("");
	const [getVagaDescricao, setVagaDescricao] = useState("");

	if (loadingVagaTipo || loadingVagaModalidade) return <LoadingPage />;

	async function handleVagaSubmit() {
		if (
			!isUserLogged(utilizadorAtual, () => {
				setTimeout(() => {
					navigate("/iniciar-sessao");
				}, 0);
			})
		)
			return false;
		if (
			checkCamposInvalidos(
				getVagaTitulo,
				getVagaTipo,
				getVagaModalidade,
				getVagaLocalizacao,
				getVagaNumeroCandidatos,
				getVagaOferecemos,
				getVagaDescricao
			)
		) {
			return false;
		}
		startLoading();
		const dataPost = {
			vaga_titulo: getVagaTitulo,
			vaga_tipo: getVagaTipo,
			vaga_modalidadecontratacao: getVagaModalidade,
			vaga_localizacao: getVagaLocalizacao,
			vaga_numerocandidatos: getVagaNumeroCandidatos,
			vaga_oferecemos: getVagaOferecemos,
			vaga_descricao: getVagaDescricao,
			vaga_utilizadorcriou: utilizadorAtual.id,
		};
		await createData("/vaga/create", dataPost)
			.then((response) => {
				if (response) {
					PopupStatus("Vaga criada com sucesso!", "success");
					navigateBack();
				} else {
					PopupStatus("Ocorreu algum erro!", "error");
				}
				stopLoading();
			})
			.catch((error) => {
				stopLoading();
				PopupStatus("Ocorreu algum erro!", "error");
			});
	}

	return (
		<div>
			<div className="container">
				<BasicHeader pageTitulo={"Criar vaga"} />
				<div>
					<TextBox
						label="Título"
						marginTop={3}
						handleChange={(e) => setVagaTitulo(e.target.value)}
						value={getVagaTitulo}
					/>
					<Row>
						<ComboBox
							label="Tipo"
							marginTop={3}
							options={comboBoxOptions(dataVagaTipo, "vagatipo_id", "vagatipo_nome")}
							handleChange={(e) => setVagaTipo(e.target.value)}
							value={getVagaTipo}
						/>
						<ComboBox
							label="Modalidade"
							marginTop={3}
							options={comboBoxOptions(
								dataVagaModalidade,
								"modalidadecontratacao_id",
								"modalidadecontratacao_nome"
							)}
							handleChange={(e) => setVagaModalidade(e.target.value)}
							value={getVagaModalidade}
						/>
					</Row>
					<Row>
						<TextBox
							label="Localização"
							marginTop={3}
							handleChange={(e) => setVagaLocalizacao(e.target.value)}
							value={getVagaLocalizacao}
						/>
						<TextBox
							label="Número Candidatos"
							inputType="number"
							marginTop={3}
							addon="#"
							handleChange={(e) => setVagaNumeroCandidatos(e.target.value)}
							value={getVagaNumeroCandidatos}
						/>
					</Row>
					<TextArea
						label="Oferecemos"
						marginTop={3}
						handleChange={(e) => setVagaOferecemos(e.target.value)}
						value={getVagaOferecemos}
					/>
					<TextArea
						label="Descrição"
						marginTop={3}
						handleChange={(e) => setVagaDescricao(e.target.value)}
						value={getVagaDescricao}
					/>
				</div>
				<Button label={"Criar"} marginTop={5} handleClick={handleVagaSubmit} />
			</div>
		</div>
	);
}
