import { useState } from "react";
import { useNavigate } from "react-router-dom";
import BasicHeader from "src/components/BasicHeader/basicHeader";
import { Button, TextArea, TextBox } from "src/components/Form";

export default function Contacto() {
	const [assunto, setassunto] = useState();
	const [mensagem, setmensagem] = useState();

	return (
		<div className="container">
			<BasicHeader pageTitulo={"Contacto"} marginTop={3} />
			<TextBox label="Assunto" marginTop={3} handleChange={(e) => setassunto(e.target.value)} />
			<TextArea label="Mensagem" marginTop={3} handleChange={(e) => setmensagem(e.target.value)} />
			<a href={`mailto:geral@pt.softinsa.com?subject=${assunto}&body=${mensagem}`}>
				<Button label="Enviar" marginTop={5} />
			</a>
		</div>
	);
}
