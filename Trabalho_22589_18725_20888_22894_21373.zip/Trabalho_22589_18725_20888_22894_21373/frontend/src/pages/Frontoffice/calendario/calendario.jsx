import React from "react";
import FullCalendar from "@fullcalendar/react";
import dayGridPlugin from "@fullcalendar/daygrid";
import timeGridPlugin from "@fullcalendar/timegrid";
import interactionPlugin from "@fullcalendar/interaction";
import { UserTemPerfis, formatComplete, getStringDateDiff, parseDate } from "src/utils/functionUtils";
import { useData } from "src/api/dataComponents";
import Swal from "sweetalert2/dist/sweetalert2.js";

import "./calendario.css";
import { useState } from "react";
import LoadingPage from "src/components/LoadingPage/loadingPage";
import BasicHeader from "src/components/BasicHeader/basicHeader";
import { usePopup } from "src/hooks/usePopup";
import { Link, useNavigate } from "react-router-dom";
import UserInfo from "src/components/OverlayTooltip/userInfo";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { useUserBasedFetch } from "src/hooks/useUserBasedFetch";
import { perfisId } from "src/data/constants";
import { useAuth } from "src/hooks/useAuth";
import { useEffect } from "react";
import { myAxios } from "src/lib/axios";

export default function Calendar() {
	const navigate = useNavigate();
	const [firstDay, setfirstDay] = useState(1);
	const { puOpen, puClose, puClear, setpuTitulo, setpuSubtitulo, setpuIcons, setpuBody, setpuFooter, puCreate } = usePopup();
	const [dataReunioes, setDataReunioes] = useState("");
	const [hasPerfilReunioes, sethasPerfilReunioes] = useState("");

	const perfilSuperior = [perfisId.RH, perfisId.GNegocios, perfisId.GIdeias];

	const utilizadorAtual = useAuth();

	useEffect(() => {
		const fetchData = async () => {
			if (!utilizadorAtual) return false;

			const hasPerfis = await UserTemPerfis(perfilSuperior, utilizadorAtual.perfil);
			sethasPerfilReunioes(hasPerfis);

			let options = {};
			if (!hasPerfis) {
				options = {
					data: { id: utilizadorAtual.id },
					method: "post",
				};
			} else {
				options = {
					method: "post",
				};
			}

			console.log(options);

			const response = await myAxios({ url: "/reuniao/listUtilizador", ...options });
			setDataReunioes(response.data.data);
		};

		fetchData();
	}, []);

	const events =
		dataReunioes &&
		dataReunioes?.map((reuniao) => {
			if (reuniao === null) return null;
			const dataInicio = parseDate(reuniao.reuniao_datainicio);
			const dataFim = reuniao.reuniao_datafim ? parseDate(reuniao.reuniao_datafim) : dataInicio;
			return {
				title: reuniao.reuniao_titulo,
				start: new Date(dataInicio.year, dataInicio.month, dataInicio.day, dataInicio.hour, dataInicio.minute),
				end: new Date(dataFim.year, dataFim.month, dataFim.day, dataFim.hour, dataFim.minute),
				key: reuniao.reuniao_id,
				data: reuniao,
			};
		});

	const setEventData = (data) => {
		setpuTitulo(data.reuniao_titulo);
		setpuIcons(
			<Link to={`/reunioes/${data.reuniao_id}`}>
				<FontAwesomeIcon icon={["fas", "expand"]} className="FontAwesomeIcons align-self-center" />
			</Link>
		);
		setpuSubtitulo(
			<div className="d-flex">
				<UserInfo utilizador={data.reun_util} children={<p>{data.reun_util.utilizador_tag}</p>} />
				<p>&nbsp;{"· " + getStringDateDiff(data.reuniao_datacriacao)}</p>
			</div>
		);
		setpuBody(
			<div>
				<div className="gap-4">
					<p> Hóra início: {formatComplete(parseDate(data.reuniao_datainicio))}</p>
					<p> Hora fim (expectado): {formatComplete(parseDate(data.reuniao_datafim))} </p>
					<p> Duração (expectada): {getStringDateDiff(data.reuniao_datainicio, data.reuniao_datafim)}</p>
				</div>
				<div>
					<p>Local: {data.reuniao_local}</p>
					<p>Descrição: {data.reuniao_assunto}</p>
				</div>
				<div className="mt-3">
					<h4>Contactos</h4>
					<div className="d-flex">
						{data.reunutil_reun.map((user, index) => {
							if (user.reunutil.utilizador_id === data.reun_util.utilizador_id) return null;
							return (
								<UserInfo
									utilizador={user.reunutil}
									children={
										<p>
											{user.reunutil.utilizador_tag}
											{index !== data.reunutil_reun.length - 1 && ","}&nbsp;
										</p>
									}
								/>
							);
						})}
					</div>
				</div>
			</div>
		);
	};

	function handleEventDoubleClick(info) {
		const data = info.event.extendedProps.data;
		setEventData(data);
		puOpen();
	}

	function handleDateDoubleClick(info) {
		Swal.fire({
			title: "Criar reunião?",
			text: "Você será redirecionado!",
			type: "warning",
			showCancelButton: true,
			confirmButtonText: "Confirmar",
			cancelButtonText: "Cancelar",
		}).then((result) => {
			if (result.value) {
				setTimeout(() => {
					navigate(`/reunioes/criar?data-inicio=${info.dateStr}T09:00&data-fim=${info.dateStr}T10:00`);
				}, 0);
			}
		});
	}

	function formatParsedDate(parsedDate) {
		return `${parsedDate.year}-${parsedDate.month}-${parsedDate.day}T${parsedDate.hour}:${parsedDate.minute}`;
	}

	const handleDateSelect = (arg) => {
		const { start, end } = arg;
		const parsedDateStart = parseDate(start);
		const parsedDateEnd = parseDate(end);

		const formatedParsedDateStart = formatParsedDate(parsedDateStart);
		const formatedParsedDateEnd = formatParsedDate(parsedDateEnd);

		Swal.fire({
			title: "Criar reunião?",
			text: "Você será redirecionado!",
			type: "warning",
			showCancelButton: true,
			confirmButtonText: "Confirmar",
			cancelButtonText: "Cancelar",
		}).then((result) => {
			if (result.value) {
				setTimeout(() => {
					navigate(`/reunioes/criar?data-inicio=${formatedParsedDateStart}&data-fim=${formatedParsedDateEnd}`);
				}, 0);
			}
		});
	};

	return (
		<div className="fullcalendar-calendario">
			<BasicHeader pageTitulo={"Calendário"} />
			{puCreate()}
			<div className="calendario-contentor">
				<FullCalendar
					plugins={[dayGridPlugin, timeGridPlugin, interactionPlugin]}
					headerToolbar={{
						left: "prev,next today",
						center: "title",
						right: "dayGridMonth,timeGridWeek,timeGridDay",
					}}
					selectable={true}
					select={hasPerfilReunioes ? handleDateSelect : null}
					dateClick={hasPerfilReunioes ? handleDateDoubleClick : null}
					eventClick={hasPerfilReunioes ? handleEventDoubleClick : null}
					events={events}
					aspectRatio={3}
					locale={"pt"}
					firstDay={firstDay}
				/>
			</div>
		</div>
	);
}
