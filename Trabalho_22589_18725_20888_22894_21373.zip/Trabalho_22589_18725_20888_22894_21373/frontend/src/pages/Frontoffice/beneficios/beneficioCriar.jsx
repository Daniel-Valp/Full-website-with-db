import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import React from "react";

/** Components */
import { useData } from "src/hooks/useData";

/** Outros */
import { PaginationList } from 'src/components/Pagination/paginationList';
import LoadingPage from "src/components/LoadingPage/loadingPage";

export default function BeneficioCriar() {
	const [dataBeneficio, loading] = useData('/beneficio/list');
	if (loading)
		return <LoadingPage/>;
	function Load() {
		const sortedData = dataBeneficio.sort((a, b) => Number(a.reuniao_id) - Number(b.reuniao_id));
		const cardElements = sortedData.map((data, index) => {
			return 
			
		});
		return cardElements;
	}

	return (
		<div>
			<PaginationList
				cardsProps={Load()}
				pageTitulo={"Adicionar Benefícios"}
				pageChildrenIcons={
					<div>
						<FontAwesomeIcon icon={['fas', 'plus']} className='FontAwesomeIcons' />
						<FontAwesomeIcon icon={['fas', 'filter']} className='FontAwesomeIcons' />
						<FontAwesomeIcon icon={['fas', 'trash']} className='FontAwesomeIcons' />
					</div>
				}
			/>
		</div>
	);
}