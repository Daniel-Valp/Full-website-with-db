import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React, { useState } from "react";

/** Components */
import Card from "src/components/Cards/card";
import Popup from "src/components/Pop-up/popup";
import { useData, createData } from "src/api/dataComponents";

/** Outros */
import UserInfo from "src/components/OverlayTooltip/userInfo";
import LoadingPage from "src/components/LoadingPage/loadingPage";
import { FileBox, ComboBox, TextArea, Button, TextBox } from "src/components/Form";
import { UserTemPerfis, comboBoxManual, comboBoxOptions } from "src/utils/functionUtils";
import { filterByComboBox, sortByDate } from "src/utils/dataManipulation";
import { statusResponse } from "src/utils/statusUtils";
import { createFile } from "src/api/fileComponents";
import { useAuth } from "src/hooks/useAuth";
import { checkCamposInvalidos, isUserLogged } from "src/utils/dataControl";
import { makeImageUrl } from "src/components/Imagens/utilizadorImagem";
import { perfisId } from "src/data/constants";
import { Pode } from "src/components/Permissoes/Pode";
import { LoadWhile } from "src/components/LoadingPage/loadWhile";
import { useCarregando } from "src/hooks/useCarregando";
import { PaginationList } from "src/components/Pagination/paginationList";

export default function BeneficioLista() {
	const [dataBeneficio, loading] = useData("/beneficio/list");
	const [dataCategorias, loadingCategorias] = useData("/beneficio/categoria/list");

	const utilizadorAtual = useAuth();
	const perfilSuperior = [perfisId.RH];

	const [getComboCategoria, setComboCategoria] = useState(-1);
	const { startLoading, stopLoading } = useCarregando();

	/** Dados create */
	const [benTitulo, setbenTitulo] = useState("");
	const [benCategoria, setbenCategoria] = useState("");
	const [benDescricao, setbenDescricao] = useState("");
	const [benImagem, setbenImagem] = useState("");

	if (LoadWhile(loading, loadingCategorias)) return <LoadingPage />;

	function Load() {
		var filteredData = filterByComboBox(dataBeneficio, getComboCategoria, "beneficio_categoria");
		const sortedData = sortByDate(filteredData, "beneficio_datacriacao");
		const cardElements = sortedData.map((data) => {
			return (
				<div className="col-md-3 mt-3">
					<Popup
						popupKey={data.beneficio_id}
						trigger={
							<Card
								titulo={data.beneficio_titulo}
								img={{ src: makeImageUrl(data.beneficio_imagem, "placeholder"), alt: "" }}
							/>
						}
						titulo={data.beneficio_titulo}
						childrenBody={
							<div className="row">
								<div className="d-flex align-items-center">
									<FontAwesomeIcon icon={["fas", "user"]} className="FontAwesomeIconsStatic" />
									<UserInfo utilizador={data.benef_util} children={<p>{data.benef_util.utilizador_tag}</p>} />
								</div>
								<div className="d-flex align-items-center">
									<FontAwesomeIcon icon={["fas", "thumbtack"]} className="FontAwesomeIconsStatic" />
									<p>{data.beneficio_cat.beneficiocategoria_nome}</p>
								</div>
								<div className="border-bottom border-dark mt-3" />
								<div className="box-info mt-3">
									<h3>Assunto</h3>
									<p>{data.beneficio_descricao}</p>
								</div>
							</div>
						}
						childrenFooter={
							<Pode se={UserTemPerfis([perfisId.RH], utilizadorAtual.perfil)}>
								<Button
									label={"Editar"}
									type="secondary"
									directTo={`/beneficios/editar/${data.beneficio_id}`}
								/>
							</Pode>
						}
					/>
				</div>
			);
		});
		return cardElements;
	}
	async function handleSubmit() {
		if (!isUserLogged(utilizadorAtual)) return false;
		if (checkCamposInvalidos(benTitulo, benCategoria, benDescricao)) return false;
		startLoading();
		const fileResponse = await createFile(benImagem);
		const dataPost = {
			beneficio_titulo: benTitulo,
			beneficio_categoria: benCategoria,
			beneficio_descricao: benDescricao,
			beneficio_utilizadorcriou: utilizadorAtual.id,
			beneficio_imagem: fileResponse.data.data.id,
		};
		const response = await statusResponse({
			asyncFunction: () => createData("/beneficio/create", dataPost),
			successMessage: "Benefício foi criado com sucesso",
		});
		stopLoading();
	}

	function handleFilterClear() {
		setComboCategoria(-1);
	}

	return (
		<div>
			<PaginationList
				cardsProps={Load()}
				pageTitulo={"Benefícios"}
				pageChildrenFilter={
					<div className="gap-3 d-flex justify-content-end">
						<ComboBox
							options={[
								...comboBoxManual(-1, "Todas"),
								...comboBoxOptions(dataCategorias, "beneficiocategoria_id", "beneficiocategoria_nome"),
							]}
							label="Categoria"
							defaultValue={getComboCategoria}
							handleChange={(e) => setComboCategoria(e.target.value)}
							value={getComboCategoria}
						/>
						<div className="d-flex justify-content-end mt-auto">
							<Button label={"Limpar"} handleClick={handleFilterClear} />
						</div>
					</div>
				}
				pageChildrenIcons={
					<div className="d-flex">
						<Pode se={UserTemPerfis(perfilSuperior, utilizadorAtual?.perfil)}>
							<Popup
								trigger={<FontAwesomeIcon icon={["fas", "plus"]} className="FontAwesomeIcons" />}
								titulo={"Criar benefício"}
								childrenBody={
									<div>
										<TextBox
											label={"Título"}
											marginTop={3}
											handleChange={(e) => setbenTitulo(e.target.value)}
											value={benTitulo}
										/>
										<ComboBox
											label="Categoria"
											options={dataCategorias.map((categoria) => ({
												id: categoria.beneficiocategoria_id,
												nome: categoria.beneficiocategoria_nome,
											}))}
											marginTop={3}
											handleChange={(e) => setbenCategoria(e.target.value)}
											value={benCategoria}
										/>
										<TextArea
											label={"Descrição"}
											marginTop={3}
											handleChange={(e) => setbenDescricao(e.target.value)}
											value={benDescricao}
										/>
										<FileBox
											label={"Adicione uma imagem"}
											marginTop={3}
											acceptedTypes={"image/*"}
											handleChange={(e) => setbenImagem(e.target.files[0])}
										/>
									</div>
								}
								childrenFooter={
									<div>
										<Button label={"Criar"} handleClick={handleSubmit} />
									</div>
								}
							/>
						</Pode>
					</div>
				}
			/>
		</div>
	);
}
