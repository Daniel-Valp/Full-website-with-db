import { Button, ComboBox, DateTimePicker, TextArea, TextBox } from "src/components/Form";
import Popup from "src/components/Pop-up/popup";

export default function ReuniaoAgendarPopup({ trigger }) {
	function handleAssociarEscolha() {
		const associarEscolha = document.querySelector('.associar-escolha');
		if (associarEscolha.style.display === 'none')
			associarEscolha.style.display = 'flex';
		else
			associarEscolha.style.display = 'none';
	}

	return (
		<Popup
			trigger={trigger}
			titulo={"Agendar reunião"}
			childrenBody={
				<div>
					<div className="mt-3">
						<TextBox label={"Título"} />
					</div>
					<div className="mt-3 d-flex flex-column">
						<div className="d-flex align-items-start">
							<div className="flex-grow-1">
								<TextBox label={"Contatos"} />
							</div>
							<div className="align-self-end" style={{ marginLeft: '20px' }} onClick={handleAssociarEscolha}>
								<Button label={"Associar"} type="outline-primary" />
							</div>
						</div>
					</div>
					<div className="mt-3 flex-column associar-escolha">
						<div className="d-flex align-items-start">
							<div className="align-self-end" style={{ marginRight: '20px' }}>
								<ComboBox placeHolder={"Associar"} />
							</div>
							<div className="flex-grow-1">
								<TextBox label={"Escolha"} />
							</div>
						</div>
					</div>

					<div className="mt-3">
						<DateTimePicker label={"Data"} />
					</div>
					<div className="mt-2">
						<DateTimePicker />
					</div>
					<div className="mt-3">
						<TextBox label={"Local"} />
					</div>
					<div className="mt-3">
						<TextArea label={"Descrição"} />
					</div>
				</div>
			}
			childrenFotter={
				<Button label={"Agendar"} />
			}
			popupKey={1}
		/>
	)
}