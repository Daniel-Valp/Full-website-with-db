import { Link } from "react-router-dom";
import { useData } from "src/api/dataComponents";
import Popup from "src/components/Pop-up/popup";
import { formatComplete, getStringDateDiff } from "src/utils/functionUtils";
import { parseDate } from "src/utils/functionUtils";
import UserInfo from "src/components/OverlayTooltip/userInfo";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

export default function ReuniaoDetalhePopup({ button, key, data }) {
	const [dataReuniao, loadingReuniao] = useData(`/reuniao/get/${data.reuniao_id}`)
	if (loadingReuniao)
		return null;
	return (
		<Popup
			trigger={button}
			titulo={data.reuniao_titulo}
			childrenHeaderIcons={
				<Link to={`/reunioes/${dataReuniao.reuniao_id}`}>
					<FontAwesomeIcon icon={["fas", "expand"]} className="FontAwesomeIcons align-self-center" aria-label="Close" data-bs-dismiss="modal" />
				</Link>
			}
			childrenBody={
				<div>
					<div className="gap-4 d-flex">
						<UserInfo
							utilizador={dataReuniao.reun_util}
							children={
								<p>{dataReuniao.reun_util.utilizador_tag}</p>
							}
						/>
						<p>{formatComplete(parseDate(dataReuniao.reuniao_datainicio))} - {formatComplete(parseDate(dataReuniao.reuniao_datafim))} | {getStringDateDiff(dataReuniao.reuniao_datainicio, dataReuniao.reuniao_datafim)}</p>

					</div>
					<div>
						<p>Local: {dataReuniao.reuniao_local}</p>
						<p>Descrição: {dataReuniao.reuniao_assunto}</p>
					</div>
					<div className="mt-3">
						<h4>Contactos</h4>
						<div className="d-flex">
							{dataReuniao.reunutil_reun.map((user, index) => {
								if (user.reunutil.utilizador_id === dataReuniao.reun_util.utilizador_id) {
									return null; // Skip rendering this user
								}

								return (
									<UserInfo
										utilizador={user.reunutil}
										children={
											<p>
												{user.reunutil.utilizador_tag}
												{index !== dataReuniao.reunutil_reun.length - 1 && ','}&nbsp;
											</p>
										}
									/>
								);
							})}
						</div>
					</div>
				</div>
			}
			popupKey={key}
		/>
	)
}