import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import React from "react";

/** Components */
import Card from "src/components/Cards/card";
import Popup from 'src/components/Pop-up/popup';
import { Button } from 'src/components/Form';
import { useData } from "src/api/dataComponents";

/** Outros */
import { formatComplete, parseDate } from 'src/utils/functionUtils'
import UserInfo from 'src/components/OverlayTooltip/userInfo';
import { PaginationList } from 'src/components/Pagination/paginationListinationList';
import LoadingPage from "src/components/LoadingPage/loadingPage";


export default function ReuniaoLista() {
	const [dataReuniao, loading] = useData('/reuniao/list');
	if (loading)
		return <LoadingPage/>;
	function Load() {
		const sortedData = dataReuniao.sort((a, b) => Number(a.reuniao_id) - Number(b.reuniao_id));
		const cardElements = sortedData.map((data, index) => {
			return (
				<div className="col-md-4 mt-3">
					<Popup
						popupKey={data.reuniao_id}
						trigger={
							<Card
								titulo={data.reuniao_titulo}
								descricao={data.reuniao_assunto}
								utilizador={data.reun_util}
							/>
						}
						titulo={data.reuniao_titulo}
						childrenBody={
							<div className="row">
								<div className="d-flex align-items-center">
									<FontAwesomeIcon icon={["fas", "user"]} className="FontAwesomeIconsStatic" />
									<UserInfo
										utilizador={data.reun_util}
										children={
											<p>{data.reun_util.utilizador_tag}</p>
										}
									/>
								</div>
								<div className="d-flex align-items-center">
									<FontAwesomeIcon icon={["fas", "users"]} className="FontAwesomeIconsStatic" />
									{data.reuniaoutilizadores &&
										data.reuniaoutilizadores.map((item, index) => {
											if (item.reun_util.utilizador_id === data.reun_util.utilizador_id) {
												return null;
											}
											return (
												<div className="d-flex" key={item.reun_util.utilizador_id}>
													<UserInfo
														utilizador={item.reun_util}
														children={<p>{item.reun_util.utilizador_tag}</p>}
													/>
													{index < data.reuniaoutilizadores.length - 1 && <span>,&nbsp;</span>}
												</div>
											);
										})}
								</div>
								<div className="d-flex align-items-center">
									<FontAwesomeIcon icon={["fas", "clock"]} className="FontAwesomeIconsStatic" />
									{data.reuniao_datafim ? (
										<p>{formatComplete(parseDate(data.reuniao_datainicio))} - {formatComplete(parseDate(data.reuniao_datafim))}</p>
									) : (
										<p>{formatComplete(parseDate(data.reuniao_datainicio))}</p>
									)}
								</div>

								<div className="d-flex align-items-center">
									<FontAwesomeIcon icon={["fas", "location-dot"]} className="FontAwesomeIconsStatic" />
									<p>{data.reuniao_local}</p>
								</div>
								<div className="box-info" style={{ paddingTop: '20px' }}>
									<h3>Assunto</h3>
									<p>{data.reuniao_assunto}</p>
								</div>
								<div className="border-bottom border-dark mt-3" />
								<div className='d-flex flex-wrap justify-content-between'>
									{data.reuniaonegocios && data.reuniaonegocios.length > 0 && (
										<div className='mt-3'>
											<h5>Negocios</h5>
											{data.reuniaonegocios.map((item, index) => (
												<Card
													key={index}
													titulo={item.negocio.negocio_titulo}
													descricao={item.negocio.negocio_descricao}
												/>
											))}
										</div>
									)}
									{data.reuniaoideias && data.reuniaoideias.length > 0 && (
										<div className='mt-3'>
											<h5>Ideias</h5>
											{data.reuniaoideias.map((item, index) => (
												<Card
													key={index}
													titulo={item.ideia.ideia_titulo}
													descricao={item.ideia.ideia_descricao}
												/>
											))}
										</div>
									)}
									{data.reuniaovagas && data.reuniaovagas.length > 0 && (
										<div className='mt-3'>
											<h5>Vagas</h5>
											{data.reuniaovagas.map((item, index) => (
												<Card
													key={index}
													titulo={item.vaga.vaga_titulo}
													descricao={item.vaga.vaga_descricao}
												/>
											))}
										</div>
									)}
									{data.notas && data.notas.length > 0 && (
										<div className='mt-3'>
											<h5>Notas</h5>
											{data.notas.map((item, index) => (
												<Card
													key={index}
													titulo={item.nota_titulo}
													descricao={item.nota_descricao}
												/>
											))}
										</div>
									)}
								</div>
							</div>
						}
						childrenFotter={
							<div className="d-flex justify-content-between">
								<div className="d-flex">
									<Button
										label={"Adicionar notas"}
										type='outline-secondary'
									/>
									<Button
										label={"Minhas notas"}
										type='outline-secondary'
									/>
								</div>
								<div className="d-flex">
									<Button
										label={"Encerrar"}
										type='danger'
									/>
									<Button
										label={"Editar"}
										type='outline-secondary'
									/>
									<Button
										label={"Participar"}
										type='primary'
									/>
								</div>
							</div>
						}
					/>
				</div>
			);
		});
		return cardElements;
	}

	return (
		<div>
			<PaginationList
				cardsProps={Load()}
				pageTitulo={"Reuniões"}
				pageChildrenIcons={
					<div>
						<FontAwesomeIcon icon={['fas', 'plus']} className='FontAwesomeIcons' />
						<FontAwesomeIcon icon={['fas', 'filter']} className='FontAwesomeIcons' />
						<FontAwesomeIcon icon={['fas', 'trash']} className='FontAwesomeIcons' />
					</div>
				}
			/>
		</div>
	);
}