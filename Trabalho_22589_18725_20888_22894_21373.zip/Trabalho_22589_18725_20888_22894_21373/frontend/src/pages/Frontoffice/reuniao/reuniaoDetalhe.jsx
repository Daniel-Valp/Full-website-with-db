import { useParams } from "react-router-dom";
import { createData, useData } from "src/api/dataComponents";
import LoadingPage from "src/components/LoadingPage/loadingPage";
import UserInfo from "src/components/OverlayTooltip/userInfo";
import { formatTime, getStringDateDiff, parseDate, parsedFormatComplete } from "src/utils/functionUtils";
import { Button } from "src/components/Form";
import NotasDetalhePopup from "../nota/notasDetalhePopup";
import { LoadWhile } from "src/components/LoadingPage/loadWhile";
import { useAuth } from "src/hooks/useAuth";
import { statusResponse } from "src/utils/statusUtils";
import { useEffect, useState } from "react";
import { useCarregando } from "src/hooks/useCarregando";

export default function ReuniaoDetalhe() {
	const { id } = useParams();
	const [dataReuniao, loadingReuniao] = useData(`/reuniao/get/${id}`);
	const utilizadorAtual = useAuth();
	const { startLoading, stopLoading } = useCarregando();

	const [temNota, settemNota] = useState(false);
	const [isEntrevista, setisEntrevista] = useState(false);

	useEffect(() => {
		if (Array.isArray(dataReuniao.reun_candidatura) && dataReuniao.reun_candidatura.length > 0) {
			setisEntrevista(true);
		}

		if (dataReuniao) {
			dataReuniao?.nota_reun?.some((item) => {
				if (item.nota_utilizador === utilizadorAtual.id) {
					settemNota(item.nota_id);
				}
			});
		}
	}, [dataReuniao, utilizadorAtual]);

	if (LoadWhile(loadingReuniao)) return <LoadingPage />;

	async function handlecriarNota() {
		startLoading();
		const data = {
			nota_titulo: null,
			nota_descricao: null,
			nota_reuniao: id,
			nota_utilizador: utilizadorAtual.id,
		};
		await statusResponse({
			asyncFunction: () => createData("/nota/create", data),
			successMessage: "Nota criada com sucesso!",
		});
		settemNota(true);
		stopLoading();
	}

	return (
		<div className="container">
			<div>
				<h1>{dataReuniao.reuniao_titulo}</h1>
				<div className="d-flex">
					<UserInfo utilizador={dataReuniao.reun_util} children={<p>{dataReuniao.reun_util.utilizador_tag}</p>} />
					<p>&nbsp;{"· " + getStringDateDiff(dataReuniao.reuniao_datacriacao)}</p>
				</div>
				<div className="row" style={{ marginTop: "20px" }}>
					<div className="col-md-12">
						<div className="box-info">
							<h2>Assunto</h2>
							<p>{dataReuniao.reuniao_assunto}</p>
						</div>
					</div>
				</div>
				<div className="row" style={{ marginTop: "20px" }}>
					<div className="col-md-6">
						<div className="box-info">
							<h2>Local</h2>
							<p>{dataReuniao.reuniao_local}</p>
						</div>
					</div>
					<div className="col-md-6 mb-5">
						<div className="box-info">
							<h2>Horário</h2>
							<p>
								{parsedFormatComplete(dataReuniao.reuniao_datainicio)}
								{dataReuniao.reuniao_datafim && ` até ${formatTime(parseDate(dataReuniao?.reuniao_datafim))}`}
							</p>
						</div>
					</div>
				</div>
			</div>
			<div className="d-flex gap-3 mb-5">
				<Button label={"Editar"} type="secondary" directTo={`/reunioes/editar/${id}`} />
				<div>
					{temNota ? (
						<NotasDetalhePopup
							psTrigger={<Button label={"Abrir nota"} type="primary" />}
							notaId={temNota}
							reuniaoId={id}
							entrevista={isEntrevista}
							startLoad={startLoading}
							stopLoad={stopLoading}
						/>
					) : (
						<Button label={"Criar nota"} type="outline-primary" handleClick={handlecriarNota} />
					)}
				</div>
			</div>
		</div>
	);
}
