import { useEffect } from "react";
import { useState } from "react";
import { createData, useData } from "src/api/dataComponents";
import BasicHeader from "src/components/BasicHeader/basicHeader";
import { Button, ComboBox, DateTimePicker, TextArea, TextBox } from "src/components/Form";
import { LoadWhile } from "src/components/LoadingPage/loadWhile";
import LoadingPage from "src/components/LoadingPage/loadingPage";
import { Pode } from "src/components/Permissoes/Pode";
import { PopupStatus } from "src/components/Pop-up/popupStatus";
import { useAuth } from "src/hooks/useAuth";
import { useCarregando } from "src/hooks/useCarregando";
import Row from "src/layouts/Alignment/row";
import { checkCamposInvalidos, isUserLogged } from "src/utils/dataControl";
import { comboBoxManual, comboBoxOptions, navigateBack } from "src/utils/functionUtils";

export default function ReuniaoAgendar() {
	const queryParams = new URLSearchParams(window.location.search);
	const paramDataInicio = queryParams.get("data-inicio");
	const paramDataFim = queryParams.get("data-fim");
	const paramTitulo = queryParams.get("titulo");
	const paramAreaReuniao = queryParams.get("area");
	const paramAreaReuniaoItem = queryParams.get("area-item");

	const utilizadorAtual = useAuth();
	const { startLoading, stopLoading } = useCarregando();

	const [dataNegocios, loadingNegocios] = useData("/negocio/list");
	const [dataCandaidatura, loadingCandidatura] = useData("/candidatura/list");

	const [areaReuniao, setareaReuniao] = useState("");
	const [areaReuniaoItem, setareaReuniaoItem] = useState("");

	const [titulo, settitulo] = useState("");
	const [dataInicio, setdataInicio] = useState("");
	const [dataFim, setdataFim] = useState("");
	const [local, setlocal] = useState("");
	const [assunto, setassunto] = useState("");

	useEffect(() => {
		setdataInicio(paramDataInicio);
		setdataFim(paramDataFim);
		settitulo(paramTitulo);
		setareaReuniao(paramAreaReuniao);
		setareaReuniaoItem(paramAreaReuniaoItem);
	}, [paramDataInicio, paramDataFim, paramTitulo, paramAreaReuniao, paramAreaReuniaoItem]);

	if (LoadWhile(loadingNegocios, loadingCandidatura)) return <LoadingPage />;

	async function handleReuniaoAgendar() {
		if (!isUserLogged(utilizadorAtual)) return false;
		if (checkCamposInvalidos(titulo, areaReuniao, areaReuniaoItem, dataInicio, local, assunto)) return false;
		startLoading();
		const data = {
			reuniao_titulo: titulo,
			reuniao_assunto: assunto,
			reuniao_datainicio: new Date(dataInicio),
			reuniao_datafim: dataFim ? new Date(dataFim) : null,
			reuniao_local: local,
			reuniao_utilizadoragendou: utilizadorAtual.id,
			reuniao_candidatura: areaReuniao === "Candidatura" ? areaReuniaoItem : null,
			reuniao_negocio: areaReuniao === "Negócio" ? areaReuniaoItem : null,
		};
		await createData("/reuniao/create", data)
			.then(async (response) => {
				if (response) {
					PopupStatus("Reunião agendada com sucesso!", "success");
					navigateBack();
				} else {
					PopupStatus("Ocorreu algum erro!", "error");
				}
			})
			.catch((error) => {
				PopupStatus("Ocorreu algum erro!", "error");
			});
		stopLoading();
	}
	
	return (
		<div className="container">
			<BasicHeader pageTitulo={"Reunião - Criar"} />
			<div>
				<div className="mt-3">
					<TextBox label={"Título"} handleChange={(e) => settitulo(e.target.value)} value={titulo} />
				</div>
				<Row>
					<ComboBox
						label={"Área"}
						options={[...comboBoxManual("Negócio", "Negócio"), ...comboBoxManual("Candidatura", "Candidatura")]}
						defaultValue={areaReuniao}
						handleChange={(e) => setareaReuniao(e.target.value)}
						marginTop={3}
					/>
					{areaReuniao === "Negócio" ? (
						<ComboBox
							label={`Escolha um item`}
							options={comboBoxOptions(dataNegocios, "negocio_id", "negocio_titulo", "neg_util.utilizador_tag")}
							defaultValue={parseInt(areaReuniaoItem)}
							handleChange={(e) => setareaReuniaoItem(e.target.value)}
							marginTop={3}
							key={1}
						/>
					) : areaReuniao === "Candidatura" ? (
						<ComboBox
							label={`Escolha um item`}
							options={comboBoxOptions(
								dataCandaidatura,
								"candidatura_id",
								"cand_vaga.vaga_titulo",
								"cand_util.utilizador_tag"
							)}
							defaultValue={parseInt(areaReuniaoItem)}
							handleChange={(e) => setareaReuniaoItem(e.target.value)}
							marginTop={3}
							key={2}
						/>
					) : (
						<ComboBox label={`Escolha um item`} marginTop={3} />
					)}
				</Row>
				<Row>
					<DateTimePicker
						label={"Data Inicio"}
						marginTop={3}
						defaultValue={dataInicio}
						handleChange={(e) => setdataInicio(e.target.value)}
						value={dataInicio}
					/>
					<DateTimePicker
						label={"Data Fim"}
						marginTop={3}
						defaultValue={dataFim}
						handleChange={(e) => setdataFim(e.target.value)}
						value={dataFim}
					/>
				</Row>
				<TextBox label={"Local"} marginTop={3} handleChange={(e) => setlocal(e.target.value)} value={local} />
				<TextArea label={"Assunto"} marginTop={3} handleChange={(e) => setassunto(e.target.value)} value={assunto} />
			</div>
			<Button label={"Agendar"} marginTop={5} handleClick={handleReuniaoAgendar} />
		</div>
	);
}
