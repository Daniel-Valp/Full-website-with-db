import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { updateData, useData } from "src/api/dataComponents";
import BasicHeader from "src/components/BasicHeader/basicHeader";
import { Button, DateTimePicker, TextArea, TextBox } from "src/components/Form";
import { LoadWhile } from "src/components/LoadingPage/loadWhile";
import LoadingPage from "src/components/LoadingPage/loadingPage";
import { useAuth } from "src/hooks/useAuth";
import { useCarregando } from "src/hooks/useCarregando";
import { checkCamposInvalidos, isUserLogged } from "src/utils/dataControl";
import { navigateBack, removeDateMS } from "src/utils/functionUtils";
import { statusResponse } from "src/utils/statusUtils";

export default function ReuniaoEditar() {
	const { id } = useParams();
	const [dataReuniao, loadingReuniao] = useData(`/reuniao/get/${id}`);
	const utilizadorAtual = useAuth();
	const navigate = useNavigate();
	const { startLoading, stopLoading } = useCarregando();

	const [titulo, settitulo] = useState("");
	const [local, setlocal] = useState("");
	const [assunto, setassunto] = useState("");
	const [dataInicio, setdataInicio] = useState("");
	const [dataFim, setdataFim] = useState("");

	useEffect(() => {
		if (dataReuniao) {
			settitulo(dataReuniao.reuniao_titulo);
			setlocal(dataReuniao.reuniao_local);
			setassunto(dataReuniao.reuniao_assunto);
			setdataInicio(removeDateMS(dataReuniao.reuniao_datainicio));
			setdataFim(removeDateMS(dataReuniao.reuniao_datafim));
		}
	}, [dataReuniao]);

	if (LoadWhile(loadingReuniao)) return <LoadingPage />;

	async function handleUpdate() {
		if (!isUserLogged(utilizadorAtual)) return false;
		if (checkCamposInvalidos(titulo, local, assunto, dataFim, dataInicio)) return false;
		startLoading();
		const data = {
			reuniao_titulo: titulo,
			reuniao_local: local,
			reuniao_assunto: assunto,
			reuniao_datafim: dataFim,
			reuniao_datainicio: dataInicio,
		};
		await statusResponse({
			asyncFunction: () => updateData(`/reuniao/update/${id}`, data),
			successMessage: "Reunião editada com sucesso!",
			handleSucess: () => navigateBack(),
		});
		stopLoading();
	}

	return (
		<div className="container">
			<BasicHeader pageTitulo={"Reunião - Editar"} />
			<TextBox label={"Título"} handleChange={(e) => settitulo(e.target.value)} value={titulo} />
			<TextBox label={"Local"} handleChange={(e) => setlocal(e.target.value)} value={local} />
			<TextArea label={"Assunto"} handleChange={(e) => setassunto(e.target.value)} value={assunto} />
			<DateTimePicker
				label={"Data iniciar"}
				handleChange={(e) => setdataInicio(e.target.value)}
				defaultValue={dataInicio}
			/>
			<DateTimePicker label={"Data fim"} handleChange={(e) => setdataFim(e.target.value)} defaultValue={dataFim} />
			<Button label={"Confirmar"} handleClick={handleUpdate} marginTop={5} />
		</div>
	);
}
