import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { useState } from "react";

/** Outros */
import { UserTemPerfis, formatTime, parseDate, parsedFormatComplete } from "src/utils/functionUtils";
import UserInfo from "src/components/OverlayTooltip/userInfo";
import LoadingPage from "src/components/LoadingPage/loadingPage";
import BasicHeader from "src/components/BasicHeader/basicHeader";
import { filterByDate, isURL, sortByDate } from "src/utils/dataManipulation";
import { Link, useNavigate } from "react-router-dom";
import { useUserBasedFetch } from "src/hooks/useUserBasedFetch";
import { PopupStatus } from "src/components/Pop-up/popupStatus";
import { LoadWhile } from "src/components/LoadingPage/loadWhile";
import { perfisId } from "src/data/constants";
import { DateTimePicker } from "src/components/Form";
import Row from "src/layouts/Alignment/row";
import { Pode } from "src/components/Permissoes/Pode";
import { useAuth } from "src/hooks/useAuth";
import { useEffect } from "react";
import { myAxios } from "src/lib/axios";

export default function ReuniaoLista() {
	const [filterDataRangeFirst, setfilterDataRangeFirst] = useState("");
	const [filterDataRangeSecond, setfilterDataRangeSecond] = useState("");
	const [dataReuniao, setDataReuniao] = useState("");

	const perfilSuperior = [perfisId.RH, perfisId.GNegocios, perfisId.GIdeias];
	const utilizadorAtual = useAuth();

	useEffect(() => {
		const fetchData = async () => {
			if (!utilizadorAtual) return false;

			const hasPerfis = await UserTemPerfis(perfilSuperior, utilizadorAtual.perfil);

			let options = {};
			if (!hasPerfis) {
				options = {
					data: { id: utilizadorAtual.id },
					method: "post",
				};
			} else {
				options = {
					method: "post"
				};
			}

			console.log(options);

			const response = await myAxios({ url: "/reuniao/listUtilizador", ...options });
			setDataReuniao(response.data.data);
		};

		fetchData();
	}, []);
	

	if (LoadWhile(!dataReuniao)) return <LoadingPage />;

	console.log(dataReuniao);

	function Load() {
		var reunioes = dataReuniao;
		reunioes = filterByDate(reunioes, "reunutil_reun.reuniao_datainicio", filterDataRangeFirst, filterDataRangeSecond);
		reunioes = sortByDate(reunioes, "reunutil_reun.reuniao_datainicio", true);
		const cardElements = reunioes.map((data, index) => {
			return (
				<tr>
					<td>
						<p>
							{parsedFormatComplete(data.reuniao_datainicio)}
							{data.reuniao_datafim && ` até ${formatTime(parseDate(data.reuniao_datafim))}`}
						</p>
					</td>
					<td>
						<p>{data.reuniao_titulo}</p>
					</td>
					<td>
						<p>
							<UserInfo utilizador={data.reun_util}>{data.reun_util.utilizador_tag}</UserInfo>
						</p>
					</td>
					<td>
						{data.reunutil_reun.length === 0 ? (
							<p>Não existem participantes</p>
						) : (
							<div className="d-flex">
								{data.reunutil_reun.map((item, index) => (
									<p>
										<UserInfo utilizador={item.reunutil}>{item.reunutil.utilizador_tag}</UserInfo>
										{index !== data.reunutil_reun.length - 1 && ","}&nbsp;
									</p>
								))}
							</div>
						)}
					</td>
					<td>
						{isURL(data.reuniao_local) ? (
							<div>
								<p>
									<a href={data.reuniao_local} className="d-flex gap-2 align-items-center">
										{data.reuniao_local}
										<FontAwesomeIcon icon={["fas", "fa-chevron-right"]} />
									</a>
								</p>
							</div>
						) : (
							<p>{data.reuniao_local}</p>
						)}
					</td>
					<Pode se={UserTemPerfis(perfilSuperior, utilizadorAtual.perfil)}>
						<td>
							<Link to={`/reunioes/${data.reuniao_id}`}>
								<FontAwesomeIcon icon={["fas", "fa-chevron-right"]} />
							</Link>
						</td>
					</Pode>
				</tr>
			);
		});
		return cardElements;
	}

	return (
		<div>
			<div className="container">
				<BasicHeader
					pageTitulo={"Reuniões"}
					pageChildrenIcons={
						<div className="d-flex">
							<Link to={"/reunioes/criar"}>
								<FontAwesomeIcon icon={["fas", "plus"]} title="Adicionar" className="FontAwesomeIcons" />
							</Link>
							<Link to={"/calendario"}>
								<FontAwesomeIcon
									icon={["fas", "calendar-alt"]}
									title="Vista calendário"
									className="FontAwesomeIcons"
								/>
							</Link>
						</div>
					}
					pageChildrenFilter={
						<Row className="mb-5">
							<DateTimePicker
								label={"Inicio"}
								handleChange={(e) => setfilterDataRangeFirst(e.target.value)}
								value={filterDataRangeFirst}
							/>
							<DateTimePicker
								label={"Fim"}
								handleChange={(e) => setfilterDataRangeSecond(e.target.value)}
								value={filterDataRangeSecond}
							/>
						</Row>
					}
				/>
			</div>
			<div className="overflow-auto table-container">
				<table className="table table-hover table-striped">
					<thead className="thead-dark">
						<tr>
							<th>
								<h4> Hórario </h4>
							</th>
							<th>
								<h4> Assunto </h4>
							</th>
							<th>
								<h4> Avaliador </h4>
							</th>
							<th>
								<h4> Participantes </h4>
							</th>
							<th>
								<h4> Local </h4>
							</th>
						</tr>
					</thead>
					<tbody>{Load()}</tbody>
				</table>
			</div>
		</div>
	);
}
