import "./inicial.css";
import ImagemVaga from "src/assets/images/vagas.jpg";
import ImagemBeneficio from "src/assets/images/beneficios.jpg";
import ImagemContacto from "src/assets/images/contactos.jpg";
import BackgroundImg from "src/assets/images/bg-image.jpg";
import React, { useRef } from "react";
import Card from "src/components/Cards/card";

function PaginaInicial() {
	return (
		<div>
			<div className="PaginaInicial">
				<div
					className="subheader-image position-relative"
					style={{
						backgroundImage: `url(${BackgroundImg})`,
						backgroundSize: "cover",
						height: "50vh",
					}}
				>
					<h1
						className="mb-4 bannertitle position-absolute"
						style={{
							bottom: "0",
							left: "0",
							margin: "0",
							padding: "16px",
						}}
					>
						Faça parte do futuro do sucesso profissional connosco.
					</h1>{" "}
				</div>
				<div className="container-fluid mt-4">
					<h2>Áreas</h2>
					<div className="d-flex">
						<div className="col-md-4 mt-3">
							<Card
								titulo="Vagas"
								descricao="Candidate-se às nossas diferentes vagas de trabalho diretamente por aqui."
								directTo="/vagas"
								arrow={false}
								img={{ src: ImagemVaga, alt: "Vagas" }}
							/>
						</div>
						<div className="col-md-4 mt-3">
							<Card
								titulo="Benefícios"
								descricao="Veja os benefícios de trabalhar connosco."
								directTo="/beneficios"
								img={{ src: ImagemBeneficio, alt: "Benefícios" }}
							/>
						</div>
						<div className="col-md-4 mt-3">
							<Card
								titulo="Contacto"
								descricao="Se têm alguma dúvida ou questão estaja a vontade de nos comunicar por aqui."
								directTo="/contactos"
								arrow={false}
								img={{ src: ImagemContacto, alt: "Contacto" }}
							/>
						</div>
					</div>
				</div>
			</div>
		</div>
	);
}

export default PaginaInicial;
