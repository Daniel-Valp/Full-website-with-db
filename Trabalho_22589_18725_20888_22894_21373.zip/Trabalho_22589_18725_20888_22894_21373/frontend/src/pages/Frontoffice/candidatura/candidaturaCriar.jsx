import { useNavigate, useParams } from "react-router-dom";
import { Button, ComboBox, FileBox, TextArea, TextBox } from "src/components/Form";
import { createData, useData } from "src/api/dataComponents";
import LoadingPage from "src/components/LoadingPage/loadingPage";
import { comboBoxOptions, navigateBack } from "src/utils/functionUtils";
import { useState } from "react";
import { PopupStatus } from "src/components/Pop-up/popupStatus";
import { useAuth } from "src/hooks/useAuth";
import { checkCamposInvalidos } from "src/utils/dataControl";
import { createFile, updateFile } from "src/api/fileComponents";
import { isFile } from "src/utils/dataManipulation";
import { useCarregando } from "src/hooks/useCarregando";

export default function CandidatarCriar() {
	const { id } = useParams();
	const navigate = useNavigate();
	const utilizadorAtual = useAuth();
	const { startLoading, stopLoading } = useCarregando();

	const [dataVaga, loadingVaga] = useData(`/vaga/get/${id}`);
	const [dataCandAreaFormacao, loadingCandAreaFormacao] = useData(`/candidatura/areaformacao/list`);
	const [dataCandGrauAcademico, loadingCandGrauAcademico] = useData(`/candidatura/grauacademico/list`);

	const [getDescricao, setDescricao] = useState("");
	const [getAreaFormacao, setAreaFormacao] = useState("");
	const [getGrauAcademico, setGrauAcademico] = useState("");
	const [getCurriculum, setCurriculum] = useState("path");

	if (loadingVaga && loadingCandAreaFormacao && loadingCandGrauAcademico) return <LoadingPage />;

	async function handleCandidaturaSubmit() {
		if (!utilizadorAtual) {
			PopupStatus("Você não está logado", "warn");
			setTimeout(() => {
				navigate("/iniciar-sessao");
			}, 0);
			return false;
		}
		if (checkCamposInvalidos(getDescricao, getAreaFormacao, getGrauAcademico, isFile(getCurriculum))) return false;
		startLoading();
		await createFile(getCurriculum)
			.then(async (response) => {
				if (response) {
					const data = {
						candidatura_descricao: getDescricao,
						candidatura_vaga: id,
						candidatura_utilizador: utilizadorAtual.id,
						candidatura_areaformacao: getAreaFormacao,
						candidatura_grauacademico: getGrauAcademico,
						candidatura_curriculum: response.data.data.id,
					};
					await createData("/candidatura/create", data)
						.then(async (response) => {
							if (response) {
								PopupStatus("Candidatou-se com sucesso!", "success");
							} else {
								PopupStatus("Ocorreu algum erro!", "error");
							}
							stopLoading();
							navigateBack();
						})
						.catch((error) => {
							stopLoading();
							PopupStatus("Ocorreu algum erro!", "error");
							navigateBack();
						});
				} else {
					PopupStatus("Ocorreu algum erro!", "error");
				}
				stopLoading();
			})
			.catch((error) => {
				stopLoading();
				PopupStatus("Ocorreu algum erro!", "error");
			});
	}

	return (
		<div>
			<div className="NegocioCriar">
				<div className="container">
					<div className="row justify-content-center mt-5">
						<div className="col-md-6">
							<h1 className="text-center mb-4">Candidatar-me</h1>
							<br />
							<form>
								<div className="form-row">
									<TextBox label={"Cargo"} marginTop={3} value={dataVaga.vaga_titulo} disable={true} />
									<div className="row">
										<div className="col">
											<ComboBox
												label="Grau Academico"
												marginTop={3}
												options={comboBoxOptions(
													dataCandGrauAcademico,
													"grauacademico_id",
													"grauacademico_nome"
												)}
												handleChange={(e) => setGrauAcademico(e.target.value)}
												value={getGrauAcademico}
											/>
										</div>
										<div className="col">
											<ComboBox
												label="Area Formação"
												marginTop={3}
												options={comboBoxOptions(
													dataCandAreaFormacao,
													"areaformacao_id",
													"areaformacao_nome"
												)}
												handleChange={(e) => setAreaFormacao(e.target.value)}
												value={getAreaFormacao}
											/>
										</div>
									</div>
									<TextArea
										label={"Descrição"}
										marginTop={3}
										handleChange={(e) => setDescricao(e.target.value)}
										value={getDescricao}
									/>
									<FileBox
										label={"Curriculum"}
										acceptedTypes={".pdf"}
										marginTop={3}
										handleChange={(e) => setCurriculum(e.target.files[0])}
									/>
								</div>
								<div className="d-flex gap-3">
									<Button label={"Criar"} marginTop={5} handleClick={handleCandidaturaSubmit} />
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	);
}
