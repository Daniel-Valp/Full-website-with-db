import { Link, useNavigate, useParams } from "react-router-dom";
import { useData } from "src/api/dataComponents";
import LoadingPage from "src/components/LoadingPage/loadingPage";
import { UserTemPerfis, dropdownSectionOptions, formatDateTime, getStringDateDiff, parseDate } from "src/utils/functionUtils";
import DropdownSection from "src/components/Section/dropdownSection";
import img from "src/assets/images/arvores.jpg";
import { Button } from "src/components/Form";
import UserInfo from "src/components/OverlayTooltip/userInfo";
import RowFill from "src/layouts/Alignment/rowFill";
import { LoadWhile } from "src/components/LoadingPage/loadWhile";
import { makeImageUrl } from "src/components/Imagens/utilizadorImagem";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { FileIcon } from "src/components/FileIconPlaceholder/fileIconPlaceholder";
import { Pode } from "src/components/Permissoes/Pode";
import { perfisId } from "src/data/constants";
import { useAuth } from "src/hooks/useAuth";
import Swal from "sweetalert2/dist/sweetalert2.js";

export default function CandidaturaDetalhe() {
	const { id } = useParams();
	const [dataCandidatura, loadingCandidatura] = useData(`/candidatura/get/${id}`);

	const perfilSuperior = [perfisId.RH];
	const utilizadorAtual = useAuth();
	const navigate = useNavigate();

	if (LoadWhile(loadingCandidatura)) return <LoadingPage />;

	var reunioes = [];

	try {
		dataCandidatura?.reun_cand.map((reuniaoItem) => {
			reunioes = dropdownSectionOptions(
				reunioes,
				reuniaoItem.reuniao_id,
				reuniaoItem.reun_util.utilizador_tag,
				"agendou",
				"reunião",
				null,
				`Começa em: ${getStringDateDiff(reuniaoItem.reuniao_inicio)} | Criada há: ${getStringDateDiff(
					reuniaoItem.reuniao_datacriacao
				)}`,
				<div>
					<p>{"Data Início: " + formatDateTime(parseDate(reuniaoItem.reuniao_datacriacao))}</p>
					<p>{"Local: " + reuniaoItem.reuniao_local}</p>
					<h3>{reuniaoItem.reuniao_titulo}</h3>
					<p>{reuniaoItem.reuniao_assunto}</p>
				</div>,
				img
			);
		});
	} catch (error) {
		reunioes = null;
	}

	function handleReuniaoAgendamento() {
		Swal.fire({
			title: "Criar reunião?",
			text: "Você será redirecionado!",
			type: "warning",
			showCancelButton: true,
			confirmButtonText: "Confirmar",
			cancelButtonText: "Cancelar",
		}).then((result) => {
			if (result.value) {
				setTimeout(() => {
					navigate(
						`/reunioes/criar?titulo=${dataCandidatura.cand_vaga.vaga_titulo} | ${
							dataCandidatura.cand_util.utilizador_tag
						}&area=${"Candidatura"}&area-item=${id}`
					);
				}, 0);
			}
		});
	}

	return (
		<div>
			<div className="container">
				<h1>
					{dataCandidatura.cand_vaga.vaga_titulo} | {dataCandidatura.cand_util.utilizador_tag}
				</h1>
				<div className="d-flex">
					<UserInfo
						utilizador={dataCandidatura.cand_util}
						children={<p>{dataCandidatura.cand_util.utilizador_tag}</p>}
					/>
					<p>
						&nbsp;{"· " + getStringDateDiff(dataCandidatura.candidatura_datacriacao)} ·{" "}
						{dataCandidatura.cand_estado.candidaturaestado_nome}
					</p>
				</div>
				<div className="row" style={{ marginTop: "20px" }}>
					<div className="col-md-12">
						<div className="box-info">
							<h2>Motivo</h2>
							<p>{dataCandidatura.candidatura_descricao}</p>
						</div>
					</div>
				</div>
				<div className="row" style={{ marginTop: "20px" }}>
					<div className="col-md-12">
						<div className="box-info">
							<h2>Curriculum</h2>
							<FileIcon directTo={makeImageUrl(dataCandidatura.candidatura_curriculum)} />
						</div>
					</div>
				</div>
				<div className="butoes-row mt-4 d-flex gap-3">
					{/* <Pode se={UserTemPerfis(perfilSuperior, utilizadorAtual.perfil)}>
						<Button label={"Encerrar"} type="danger" />
					</Pode> */}
				</div>
				<div className="mt-5">
					<DropdownSection
						title={"Reuniões"}
						items={reunioes}
						icons={
							<Pode se={UserTemPerfis(perfilSuperior, utilizadorAtual.perfil)}>
								<div>
									<FontAwesomeIcon
										icon={["fas", "plus"]}
										className="FontAwesomeIcons"
										onClick={handleReuniaoAgendamento}
									/>
								</div>
							</Pode>
						}
					/>
				</div>
			</div>
		</div>
	);
}
