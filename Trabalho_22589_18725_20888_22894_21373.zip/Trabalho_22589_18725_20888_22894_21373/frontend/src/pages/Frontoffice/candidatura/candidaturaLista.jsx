import { Link, useNavigate } from "react-router-dom";
import React from "react";

/** CSS */
import "./candidatura.css";

/** Components */
import Card from "src/components/Cards/card";
import { useData } from "src/api/dataComponents";
import LoadingPage from "src/components/LoadingPage/loadingPage";
import { Button, ComboBox, SearchBox } from "src/components/Form";
import Popup from "src/components/Pop-up/popup";
import { UserTemPerfis, comboBoxManual, comboBoxOptions, getStringDateDiff } from "src/utils/functionUtils";
import { useState } from "react";
import { filterByComboBox, filterDataByAllColumns, sortByDate } from "src/utils/dataManipulation";
import { useAuth } from "src/hooks/useAuth";
import { LoadWhile } from "src/components/LoadingPage/loadWhile";
import { perfisId } from "src/data/constants";
import { useUserBasedFetch } from "src/hooks/useUserBasedFetch";
import { PopupStatus } from "src/components/Pop-up/popupStatus";
import { Pode } from "src/components/Permissoes/Pode";
import UserInfo from "src/components/OverlayTooltip/userInfo";
import { PaginationList } from "src/components/Pagination/paginationList";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

export default function Candidatura() {
	const queryParams = new URLSearchParams(window.location.search);
	const filterEstado = queryParams.get("estado");
	const filterSearch = queryParams.get("search");
	const filterVaga = queryParams.get("vaga");

	const utilizadorAtual = useAuth();
	const perfilSuperior = [perfisId.RH];
	const navigate = useNavigate();

	const [dataEstados, loadingEstados] = useData("/candidatura/estado/list");
	const [dataVagas, loadingVagas] = useData("/vaga/list");

	const [getEstado, setEstado] = useState(filterEstado ? Number(filterEstado) : -1);
	const [getVaga, setVaga] = useState(filterVaga ? Number(filterVaga) : -1);
	const [getSearchTerm, setSearchTerm] = useState(filterSearch ? filterSearch : "");

	const [dataCandidaturas, setdataCandidaturas, hasPerfilCandidaturas] = useUserBasedFetch({
		perfisPermitidos: perfilSuperior,
		generalBaseUrl: "/candidatura/list",
		userIdentifier: "candidatura_utilizador",
	});

	if (LoadWhile(loadingEstados, loadingVagas, !dataCandidaturas)) return <LoadingPage />;

	if (!hasPerfilCandidaturas && dataCandidaturas.length === 0) {
		PopupStatus("Candidate-se a uma vaga primeiro", "warn");
		setTimeout(() => {
			navigate("/vagas");
		}, 0);
	}

	function LoadCandidaturas() {
		var filteredData = filterDataByAllColumns(dataCandidaturas, getSearchTerm);
		filteredData = filterByComboBox(filteredData, getEstado, "candidatura_estado");
		filteredData = filterByComboBox(filteredData, getVaga, "candidatura_vaga");
		const sortedData = sortByDate(filteredData, "candidatura_datacriacao");
		return sortedData.map((data) => {
			return (
				<div className="col-md-4 mt-3">
					<Popup
						titulo={data.cand_vaga.vaga_titulo}
						childrenHeaderIcons={
							<Link to={`/candidaturas/${data.candidatura_id}`}> 
								<FontAwesomeIcon icon={["fas", "expand"]} className="FontAwesomeIcons" />
							</Link>
						}
						subtitulo={
							<div className="d-flex">
								<UserInfo utilizador={data.cand_util} children={<p>{data.cand_util.utilizador_tag}</p>} />
								<p>&nbsp;{"· " + getStringDateDiff(data.candidatura_datacriacao)} · {data.cand_estado.candidaturaestado_nome}</p>
							</div>
						}
						popupKey={data.candidatura_id}
						trigger={
							<Card
								titulo={<Link to={`/vagas/${data.cand_vaga.vaga_id}`}>{data.cand_vaga.vaga_titulo}</Link>}
								descricao={data.candidatura_descricao}
								utilizador={data.cand_util}
							/>
						}
						childrenBody={
							<div>
								<h3>Motivo:</h3>
								<p>{data.candidatura_descricao}</p>
							</div>
						}
					/>
				</div>
			);
		});
	}

	function handleFilterClear() {
		setEstado(-1);
		setVaga(-1);
		setSearchTerm("");
	}

	return (
		<div>
			<PaginationList
				cardsProps={LoadCandidaturas()}
				pageTitulo={"Candidaturas"}
				pageChildrenFilter={
					<div className="gap-3 d-flex justify-content-end">
						<div>
							<SearchBox
								handleChange={(e) => setSearchTerm(e.target.value)}
								label={"Pesquisar"}
								value={getSearchTerm}
							/>
						</div>
						<Pode se={UserTemPerfis(perfilSuperior, utilizadorAtual.perfil)}>
							<ComboBox
								options={[
									...comboBoxManual(-1, "Todas"),
									...comboBoxOptions(dataEstados, "candidaturaestado_id", "candidaturaestado_nome"),
								]}
								label="Estado"
								defaultValue={getEstado}
								handleChange={(e) => setEstado(e.target.value)}
								value={getEstado}
							/>
							<ComboBox
								options={[
									...comboBoxManual(-1, "Todas"),
									...comboBoxOptions(dataVagas, "vaga_id", "vaga_titulo", "vaga_localizacao"),
								]}
								label="Vaga"
								defaultValue={getVaga}
								handleChange={(e) => setVaga(e.target.value)}
								value={getVaga}
							/>
						</Pode>
						<div className="d-flex justify-content-end mt-auto">
							<Button label={"Limpar"} handleClick={handleFilterClear} />
						</div>
					</div>
				}
			/>
		</div>
	);
}
