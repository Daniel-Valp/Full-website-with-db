import React, { useState, useEffect } from "react";

import { TextBox, ComboBox, TextArea, FileBox, Button } from "src/components/Form";

import { updateData, useData } from "src/api/dataComponents";
import LoadingPage from "src/components/LoadingPage/loadingPage";
import { useNavigate, useParams } from "react-router-dom";
import { comboBoxOptions } from "src/utils/functionUtils";
import Row from "src/layouts/Alignment/row";
import BasicHeader from "src/components/BasicHeader/basicHeader";
import RowFill from "src/layouts/Alignment/rowFill";
import { makeImageUrl } from "src/components/Imagens/utilizadorImagem";
import { createFile, updateFile } from "src/api/fileComponents";
import { useCarregando } from "src/hooks/useCarregando";
import { PopupStatus } from "src/components/Pop-up/popupStatus";
import authService from "src/api/auth.service";
import { useAuth } from "src/hooks/useAuth";
import { LoadWhile } from "src/components/LoadingPage/loadWhile";
import { perfisId } from "src/data/constants";
import { checkCamposInvalidos } from "src/utils/dataControl";

export default function ContaEditar() {
	const { tag } = useParams();
	const utilizadorAtual = useAuth();
	const utilizadorCerto = (utilizadorAtual && utilizadorAtual.tag === tag) || utilizadorAtual.perfil === perfisId.Admin;
	if (!utilizadorAtual || !utilizadorCerto) {
		setTimeout(() => {
			navigate("/");
		}, 0);
	}
	const [dataUtilizador, loadingUtilizador] = useData(utilizadorCerto ? `/utilizador/gettag/${tag}` : null);
	const [dataPaises, loadingPaises] = useData("/utilizador/pais/list");
	const { startLoading, stopLoading } = useCarregando();
	const navigate = useNavigate();

	const [getImagem, setImagem] = useState("");
	const [getNome, setNome] = useState("");
	const [getApelido, setApelido] = useState("");
	const [getEmail, setEmail] = useState("");
	const [getDescricao, setDescricao] = useState("");
	const [getFormacaoAcademica, setFormacaoAcademica] = useState("");
	const [getPais, setPais] = useState("");
	const [getCidade, setCidade] = useState("");
	const [getEscola, setEscola] = useState("");

	useEffect(() => {
		if (!loadingUtilizador && dataUtilizador) {
			setNome(dataUtilizador?.utilizador_nome);
			setApelido(dataUtilizador?.utilizador_apelido);
			setEmail(dataUtilizador?.utilizador_email);
			setDescricao(dataUtilizador?.utilizador_descricao);
			setFormacaoAcademica(dataUtilizador?.utilizador_formacaoacademica);
			setPais(dataUtilizador?.util_cidade?.cidade_pais);
			setCidade(dataUtilizador?.utilizador_cidade);
			setEscola(dataUtilizador?.utilizador_escola);
		}
	}, [loadingUtilizador, dataUtilizador]);

	if (LoadWhile(loadingPaises, loadingUtilizador)) return <LoadingPage />;

	async function uploadImagem() {
		if (!getImagem) return null;
		if (!dataUtilizador?.utilizador_imagem) var imagem = await createFile(getImagem);
		else imagem = await updateFile(dataUtilizador.utilizador_imagem, getImagem);
		return imagem.data.data.id;
	}

	async function handleUtilizadorUpdate() {
		if (checkCamposInvalidos(getNome, getApelido)) return false;
		startLoading();
		var resImagem = await uploadImagem();
		await updateUtilizador(resImagem);
		stopLoading();
		await authService.refreshAuth();
	}

	async function updateUtilizador(imageId) {
		const data = {
			utilizador_nome: getNome,
			utilizador_apelido: getApelido,
			utilizador_email: getEmail,
			utilizador_descricao: getDescricao,
			utilizador_imagem: imageId,
			utilizador_formacaoacademica: getFormacaoAcademica,
			utilizador_pais: getPais,
			utilizador_cidade: getCidade,
			utilizador_escola: getEscola,
		};
		if (imageId) data.utilizador_imagem = imageId;
		await updateData(`/utilizador/update/${dataUtilizador.utilizador_id}`, data)
			.then((response) => {
				if (response) {
					navigate(`/conta/${tag}`);
					PopupStatus("Conta atualizada com sucesso!", "success");
				} else {
					PopupStatus("Ocurreu algum erro!", "error");
				}
			})
			.catch((error) => {
				PopupStatus("Ocurreu algum erro!", "error");
			});
	}

	var paises = [];
	dataPaises &&
		dataPaises.map((item) => {
			var cidades = item.cid_pais.map((cidadeItem) => ({
				id: cidadeItem.cidade_id,
				nome: cidadeItem.cidade_nome,
			}));

			paises.push({
				id: item.pais_id,
				nome: item.pais_nome,
				cidade: cidades,
			});
		});

	const getCidadesForSelectedPais = () => {
		if (getPais - 1 >= 0 && paises[getPais - 1]) return paises[getPais - 1].cidade;
		return [];
	};

	return (
		<div>
			<div className="container">
				<div className="row justify-content-center mt-5">
					<div className="col-md-8">
						<BasicHeader pageTitulo={"Conta - Editar"} />
						<form>
							<br />
							<RowFill>
								<img
									src={makeImageUrl(dataUtilizador.utilizador_imagem)}
									alt="Imagem de perfil"
									className="conta-imagem rounded-circle"
								/>
								<FileBox
									label={"Seleciona a sua imagem"}
									acceptedTypes={"image/*"}
									handleChange={(e) => setImagem(e.target.files[0])}
								/>
							</RowFill>
							<br />
							<div>
								<Row>
									<TextBox
										label={"Nome"}
										handleChange={(e) => setNome(e.target.value)}
										value={getNome}
										marginTop={3}
									/>
									<TextBox
										label={"Apelido"}
										handleChange={(e) => setApelido(e.target.value)}
										value={getApelido}
										marginTop={3}
									/>
								</Row>
								<TextBox
									label={"Escola"}
									handleChange={(e) => setEscola(e.target.value)}
									value={getEscola}
									marginTop={3}
								/>
								<TextBox
									label={"Formação académica"}
									handleChange={(e) => setFormacaoAcademica(e.target.value)}
									value={getFormacaoAcademica}
									marginTop={3}
								/>
								<ComboBox
									label={"Pais"}
									options={paises}
									handleChange={(e) => setPais(e.target.value)}
									value={getPais}
									defaultValue={getPais}
									marginTop={3}
								/>
								<ComboBox
									label={"Cidade"}
									options={getCidadesForSelectedPais()}
									handleChange={(e) => setCidade(e.target.value)}
									value={getCidade}
									defaultValue={getCidade}
									marginTop={3}
								/>
								<div className="mt-3">
									<TextArea
										label={"Descrição"}
										handleChange={(e) => setDescricao(e.target.value)}
										value={getDescricao}
										marginTop={3}
									/>
								</div>
								<div className="d-flex mt-4 gap-3">
									<Button label={"Guardar"} handleClick={handleUtilizadorUpdate} />
									<Button label={"Cancelar"} type="outline-secondary" />
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	);
}
