export default function Definicoes() {
	return (
		<p>a</p>
	);
}