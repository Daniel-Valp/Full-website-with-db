import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { useParams } from "react-router-dom";
import React, { useEffect, useState } from "react";

/** CSS */
import "./conta.css";

/** Components */
import { ComboBox, TextArea, DateTimePicker, Button } from "src/components/Form";
import { useData } from "src/api/dataComponents";

/** Funções */
import { parseDate, comboBoxOptions, UserTemPerfis, formatComplete } from "src/utils/functionUtils";
import Popup from "src/components/Pop-up/popup";
import LoadingPage from "src/components/LoadingPage/loadingPage";
import { createData, updateData } from "src/api/dataComponents";
import CardSection from "src/components/Cards/cardSection";
import AuthService from "src/api/auth.service";
import { PopupStatus } from "src/components/Pop-up/popupStatus";
import { useAuth } from "src/hooks/useAuth";
import { makeImageUrl } from "src/components/Imagens/utilizadorImagem";
import { LoadWhile } from "src/components/LoadingPage/loadWhile";
import { statusResponse } from "src/utils/statusUtils";
import { Pode } from "src/components/Permissoes/Pode";
import { perfisId } from "src/data/constants";

export default function ContaDetalhe() {
	const { tag } = useParams();
	const [dataConta, loadingConta] = useData(`/utilizador/gettag/${tag}`);
	const [dataPerfis, loadingPerfis] = useData("/utilizador/perfil/list");
	const utilizadorAtual = useAuth();

	const [imagemUrl, setimagemUrl] = useState("");

	/** Perfil Update */
	const [getPerfil, setPerfil] = useState();

	/** Inativo Create */
	const [getInativoMotivo, setInativoMotivo] = useState("");
	const [getInativoDataEncerramento, setInativoDataEncerramento] = useState("");

	/** Outros */
	const [showdataCriacao, setshowdataCriacao] = useState("");
	const [showInativoItems, setshowInativoItems] = useState("");
	const [showCidade, setshowCidade] = useState("");
	const [showPais, setshowPais] = useState("");

	useEffect(() => {
		AuthService.refreshAuth();
		if (dataConta) {
			setimagemUrl(dataConta.utilizador_imagem);
			setshowdataCriacao(
				`Ingressou em ${parseDate(dataConta.utilizador_datacriacao).monthName} de ${
					parseDate(dataConta.utilizador_datacriacao).year
				}`
			);

			const filteredItems = [];
			dataConta?.util_inativo?.forEach((item) => {
				if (item.utilizadorinativo_estado && new Date(item.utilizadorinativo_dataencerramento) > new Date()) {
					filteredItems.push(item);
				}
			});
			setshowInativoItems(filteredItems);
			setshowCidade(dataConta?.util_cidade?.cidade_nome);
			setshowPais(dataConta?.util_cidade?.cid_pais?.pais_nome);
			setPerfil(dataConta.utilizador_perfil);
		}
	}, [dataConta]);

	if (LoadWhile(loadingConta, loadingPerfis)) return <LoadingPage />;

	async function handlePerfilUpdate(event) {
		if (UserTemPerfis([perfisId.Admin], utilizadorAtual.perfil)) setPerfil(event);
		const perfilUpdate = {
			utilizador_perfil: event,
		};

		try {
			await updateData(`/utilizador/update/${dataConta.utilizador_id}`, perfilUpdate);
			await AuthService.refreshAuth();
		} catch (error) {
			PopupStatus("Ocorreu um erro", "error");
		}
	}

	async function handleInativarCreate() {
		const inativarCreate = {
			utilizadorinativo_utilizador: dataConta.utilizador_id,
			utilizadorinativo_motivo: getInativoMotivo,
			utilizadorinativo_dataencerramento: getInativoDataEncerramento,
		};
		await statusResponse({
			asyncFunction: () => {
				return createData("/utilizador/inativo/create", inativarCreate);
			},
			successMessage: "Utilizador foi inativado",
			successMessageIcon: "success",
		});
	}

	async function handleAtivarUser() {
		dataConta.util_inativo.map(async (item) => {
			const data = {
				utilizadorinativo_estado: false,
			};
			await updateData(`/utilizador/inativo/update/${item.utilizadorinativo_id}`, data);
			return null;
		});
		PopupStatus("Utilizador foi ativado", "success");
		setshowInativoItems([]);
	}

	return (
		<div>
			<div className="container my-4">
				<div className="card p-4">
					{showInativoItems &&
						showInativoItems.length !== 0 &&
						showInativoItems.map((item) => (
							<span key={item.utilizadorinativo_id} className="badge bg-danger">
								Conta está inativa até {formatComplete(parseDate(item.utilizadorinativo_dataencerramento))}
							</span>
						))}
					<br />
					<div className="d-flex justify-content-between">
						<div className="d-flex align-items-end">
							<img src={makeImageUrl(imagemUrl)} alt="Imagem de perfil" className="conta-imagem rounded-circle" />
						</div>
					</div>
					<div className="d-flex mt-2 justify-content-between">
						<div>
							<h2>{dataConta.utilizador_nome + " " + dataConta.utilizador_apelido}</h2>
							<h5>{dataConta.utilizador_tag}</h5>
						</div>
						<div className="d-flex gap-3" style={{ marginRight: "20px" }}>
							<Pode se={UserTemPerfis([perfisId.Admin], utilizadorAtual?.perfil)}>
								<ComboBox
									defaultValue={getPerfil}
									options={comboBoxOptions(dataPerfis, "utilizadorperfil_id", "utilizadorperfil_nome")}
									handleChange={(e) => {
										handlePerfilUpdate(e.target.value);
									}}
									value={getPerfil}
								/>
								{showInativoItems && showInativoItems.length !== 0 ? (
									<Button label={"Ativar"} type="success" handleClick={handleAtivarUser} />
								) : (
									<Popup
										trigger={<Button label={"Inativar"} type="danger" />}
										titulo={`Inativar ${dataConta.utilizador_tag}`}
										childrenBody={
											<div>
												<DateTimePicker
													label={"Inativar até"}
													handleChange={(e) => setInativoDataEncerramento(e.target.value)}
													value={getInativoDataEncerramento}
												/>
												<div className="mt-3">
													<TextArea
														label={"Motivo"}
														handleChange={(e) => setInativoMotivo(e.target.value)}
														value={getInativoMotivo}
													/>
												</div>
											</div>
										}
										childrenFooter={
											<div className="d-flex gap-3">
												<Button label={"Inativar"} type="danger" handleClick={handleInativarCreate} />
											</div>
										}
										popupKey={"popup-inativar"}
									/>
								)}
							</Pode>
							<Pode se={utilizadorAtual?.tag === tag}>
								<Button directTo={"editar"} label={"Editar"} type="outline-secondary" />
							</Pode>
						</div>
					</div>
					<div>
						<h4>{dataConta.utilizador_descricao}</h4>
					</div>
					<div className="d-flex">
						{dataConta?.utilizador_escola && (
							<div className="d-flex align-items-center desc-item">
								<FontAwesomeIcon icon={["fas", "school"]} className="FontAwesomeIconsSmaller" />
								<p>{dataConta.utilizador_escola}</p>
							</div>
						)}
						{dataConta?.utilizador_formacaoacademica && (
							<div className="d-flex align-items-center desc-item">
								<FontAwesomeIcon icon={["fas", "graduation-cap"]} className="FontAwesomeIconsSmaller" />
								<p>{dataConta.utilizador_formacaoacademica}</p>
							</div>
						)}
					</div>
					<div className="d-flex">
						{showCidade && showPais && (
							<div className="d-flex align-items-center desc-item">
								<FontAwesomeIcon icon={["fas", "location-dot"]} className="FontAwesomeIconsSmaller" />
								<p>
									{showCidade}, {showPais}
								</p>
							</div>
						)}
						{showCidade && !showPais && (
							<div className="d-flex align-items-center desc-item">
								<FontAwesomeIcon icon={["fas", "location-dot"]} className="FontAwesomeIconsSmaller" />
								<p>{showCidade}</p>
							</div>
						)}
						{!showCidade && showPais && (
							<div className="d-flex align-items-center desc-item">
								<FontAwesomeIcon icon={["fas", "location-dot"]} className="FontAwesomeIconsSmaller" />
								<p>{showPais}</p>
							</div>
						)}
						{showdataCriacao && (
							<div className="d-flex align-items-center desc-item">
								<FontAwesomeIcon icon={["fas", "calendar-week"]} className="FontAwesomeIconsSmaller" />
								<p>{showdataCriacao}</p>
							</div>
						)}
					</div>
				</div>
			</div>
			<div className="container my-4 d-flex">
				<CardSection titulo={"Meus Negócios"} content={<p>Total: {dataConta.neg_util.length}</p>} />
				<CardSection titulo={"Minhas Candidaturas"} content={<p>Total: {dataConta.cand_util.length}</p>} />
				<CardSection titulo={"Minhas Ideias"} content={<p>Total: {dataConta.ideia_util.length}</p>} />
			</div>
		</div>
	);
}
