import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { createData, updateData } from "src/api/dataComponents";
import BasicHeader from "src/components/BasicHeader/basicHeader";
import LoadingPage from "src/components/LoadingPage/loadingPage";

import "./notificacao.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Button, ComboBox, TextArea, TextBox } from "src/components/Form";
import { sortByDate } from "src/utils/dataManipulation";
import { useAuth } from "src/hooks/useAuth";
import { PopupStatus } from "src/components/Pop-up/popupStatus";
import { useCarregando } from "src/hooks/useCarregando";
import { usePopupStatic } from "src/hooks/usePopupStatic";
import { checkCamposInvalidos } from "src/utils/dataControl";
import { LoadWhile } from "src/components/LoadingPage/loadWhile";
import { myAxios } from "src/lib/axios";
import { UserTemPerfis, comboBoxManualLoop, getStringDateDiff } from "src/utils/functionUtils";
import { iconsString, perfisId } from "src/data/constants";
import { Pode } from "src/components/Permissoes/Pode";

export default function NotificacaoLista() {
	const utilizadorAtual = useAuth();
	const [dataNotificacoes, setNotificacoes] = useState("");

	const { startLoading, stopLoading } = useCarregando();
	const { psOpen, psClose, psCreate } = usePopupStatic();

	const [titulo, settitulo] = useState("");
	const [descricao, setdescricao] = useState("");
	const [nivelUrgencia, setnivelUrgencia] = useState("");

	useEffect(() => {
		fetchData();
	}, []);

	if (LoadWhile(!dataNotificacoes)) return <LoadingPage />;

	async function fetchData() {
		if (!utilizadorAtual) return false;
		const options = {
			data: { notificacaoutilizador_utilizador: utilizadorAtual.id },
			method: "post",
		};
		const response = await myAxios({ url: "/notificacao/utilizador/list", ...options });
		setNotificacoes(response.data.data);
	}

	async function handleNotificacaoSubmit() {
		if (checkCamposInvalidos(descricao, titulo, nivelUrgencia)) {
			PopupStatus("Campos Inválidos", "warn");
			return false;
		}

		startLoading();
		const data = {
			notificacao_descricao: descricao,
			notificacao_titulo: titulo,
			notificacao_nivelurgencia: nivelUrgencia,
			notificacao_automatica: false,
			notificacao_utilizador: utilizadorAtual.id,
		};
		await createData("/notificacao/create", data)
			.then((response) => {
				psClose();
				if (response) {
					PopupStatus("Notificação enviada com sucesso!", "success");
				} else {
					PopupStatus("Ocorreu algum erro!", "error");
				}
			})
			.catch((error) => {
				psClose();
				PopupStatus("Ocorreu algum erro!", "error");
			});
		stopLoading();
	}

	function getNotificacaoURL(notificacaoItem) {
		if (!notificacaoItem) return null;
		if (notificacaoItem.notificacao_vaga) return `/vagas?popupId=${notificacaoItem.notificacao_vaga}`;
		else if (notificacaoItem.notificacao_ideia) return `/ideias/${notificacaoItem.notificacao_ideia}`;
		else if (notificacaoItem.notificacao_negocio) return `/negocios/${notificacaoItem.notificacao_negocio}`;
		else if (notificacaoItem.notificacao_beneficio) return `/beneficios/?popupId=${notificacaoItem.notificacao_beneficio}`;
		else if (notificacaoItem.notificacao_reuniao) return `/reunioes/${notificacaoItem.notificacao_reuniao}`;
		else if (notificacaoItem.notificacao_candidatura) return `/candidaturas/${notificacaoItem.notificacao_candidatura}`;
		else return null;
	}

	function getNotificacaoIcon(notificacaoItem) {
		if (!notificacaoItem) return null;
		else if (notificacaoItem.notificacao_vaga) return iconsString.vagas;
		else if (notificacaoItem.notificacao_negocio) return iconsString.negocios;
		else if (notificacaoItem.notificacao_beneficio) return iconsString.beneficios;
		else if (notificacaoItem.notificacao_ideia) return iconsString.ideias;
		else if (notificacaoItem.notificacao_reuniao) return iconsString.reunioes;
		else if (notificacaoItem.notificacao_candidatura) return iconsString.candidaturas;
		else return null;
	}

	function handleNotificacaoVista(event) {
		const notificacaoId = event.target.value;
		if (!notificacaoId) return false;
		updateData(`/notificacao/utilizador/update/${notificacaoId}`, { notificacaoutilizador_vista: true });
	}

	function handleSetVista(id) {
		if (!id) return false;
		updateData(`/notificacao/utilizador/update/${id}`, { notificacaoutilizador_vista: true });
	}

	function LoadNotificacao() {
		const sortedNotificacoes = sortByDate(dataNotificacoes, "utilnotif.notificacao_datacriacao");
		return (
			<ul className="list-unstyled" onClick={handleNotificacaoVista}>
				{sortedNotificacoes?.map((item) => {
					let notificacaoItem = item.utilnotif;
					const url = getNotificacaoURL(notificacaoItem);
					const icon = getNotificacaoIcon(notificacaoItem);
					return (
						<li
							value={item.notificacaoutilizador_vista ? "0" : item.notificacaoutilizador_id}
							className={`mb-1 d-flex align-items-center list-group-item br-regular hover-regular ${
								!item.notificacaoutilizador_vista ? "bg-destaque" : ""
							}`}
						>
							<Link to={url}>
								<div className="d-flex align-items-center gap-4">
									<Pode se={icon}>
										<div>
											<FontAwesomeIcon icon={["fas", icon]} />
										</div>
									</Pode>
									<div>
										<h4>{`${notificacaoItem.notificacao_titulo} · ${getStringDateDiff(
											notificacaoItem.notificacao_datacriacao
										)}`}</h4>
										<h5>{notificacaoItem.notificacao_descricao}</h5>
									</div>
								</div>
							</Link>
							<Pode se={!item.notificacaoutilizador_vista}>
								<div className="d-flex justify-content-end">
									<FontAwesomeIcon
										icon={["fas", "bookmark"]}
										className="FontAwesomeIcons"
										onClick={() => handleSetVista(item?.notificacaoutilizador_id)}
									/>
								</div>
							</Pode>
						</li>
					);
				})}
			</ul>
		);
	}

	function handlePsOpen() {
		psOpen();
	}

	return (
		<div className="container">
			{psCreate({
				psTitulo: "Mandar notificação",
				psBody: (
					<div>
						<TextBox label={"Título"} marginTop={3} handleChange={(e) => settitulo(e.target.value)} />
						<TextArea label={"Descrição"} marginTop={3} handleChange={(e) => setdescricao(e.target.value)} />
						<TextBox
							label={"Nível de Urgência"}
							marginTop={3}
							inputType="number"
							handleChange={(e) => setnivelUrgencia(e.target.value)}
						/>
					</div>
				),
				psFooter: <Button label={"Mandar"} handleClick={handleNotificacaoSubmit} />,
			})}
			<BasicHeader
				pageTitulo={"Notificações"}
				pageChildrenIcons={
					<Pode se={UserTemPerfis(perfisId.SUPERIORES, utilizadorAtual.perfil)}> 
						<Button
							label={"Adicionar"}
							icon={<FontAwesomeIcon icon={["fas", "plus"]} />}
							handleClick={handlePsOpen}
						/>
					</Pode>
				}
			/>

			<ul className="list-group overflow-y">{LoadNotificacao()}</ul>
		</div>
	);
}
