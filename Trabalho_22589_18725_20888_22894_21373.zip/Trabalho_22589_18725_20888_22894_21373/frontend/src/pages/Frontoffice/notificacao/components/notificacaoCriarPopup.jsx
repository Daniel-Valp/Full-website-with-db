import Layout from "src/layouts/PageLayout/layout";

export default function NotificacaoCriarPopup() {
	return (
		<div>
			
		</div>
	);
}