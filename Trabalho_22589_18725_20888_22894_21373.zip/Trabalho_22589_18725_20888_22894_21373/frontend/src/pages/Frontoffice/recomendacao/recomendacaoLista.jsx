import { Link, useNavigate } from "react-router-dom";
import React, { useState } from "react";

/** Components */
import Card from "src/components/Cards/card";
import { useData } from "src/api/dataComponents";
import LoadingPage from "src/components/LoadingPage/loadingPage";
import Popup from "src/components/Pop-up/popup";
import { UserTemPerfis, comboBoxManual, comboBoxOptions, getStringDateDiff } from "src/utils/functionUtils";
import { Button, ComboBox, SearchBox } from "src/components/Form";
import { filterByComboBox, filterDataByAllColumns, sortByDate } from "src/utils/dataManipulation";
import UserInfo from "src/components/OverlayTooltip/userInfo";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { useUserBasedFetch } from "src/hooks/useUserBasedFetch";
import { perfisId } from "src/data/constants";
import { PopupStatus } from "src/components/Pop-up/popupStatus";
import { Pode } from "src/components/Permissoes/Pode";
import { useAuth } from "src/hooks/useAuth";
import { PaginationList } from "src/components/Pagination/paginationList";

export default function RecomendacaoLista() {
	const queryParams = new URLSearchParams(window.location.search);
	const filterSearch = queryParams.get("search");
	const filterVaga = queryParams.get("vaga");
	const [dataVagas, loadingVagas] = useData("/vaga/list");

	const [getVaga, setVaga] = useState(filterVaga ? Number(filterVaga) : -1);
	const [getSearchTerm, setSearchTerm] = useState(filterSearch ? filterSearch : "");

	const perfilSuperior = [perfisId.RH];

	const utilizadorAtual = useAuth();
	const navigate = useNavigate();

	const [dataRecomendacao, setdataRecomendacao, hasPerfilRecomendacao] = useUserBasedFetch({
		perfisPermitidos: [perfisId.RH],
		generalBaseUrl: "/recomendacao/list",
		userIdentifier: "recomendacao_utilizador",
	});

	if (!dataRecomendacao && loadingVagas) return <LoadingPage />;

	if (!hasPerfilRecomendacao && dataRecomendacao.length === 0) {
		PopupStatus("Recomende alguem primeiro", "warn");
		setTimeout(() => {
			navigate("/vagas");
		}, 0);
	}

	function LoadRecomendar() {
		var filteredData = filterDataByAllColumns(dataRecomendacao, getSearchTerm);
		filteredData = filterByComboBox(filteredData, getVaga, "recomendacao_vaga");
		const sortedData = sortByDate(filteredData, "recomendacao_datacriacao");
		return sortedData.map((data, index) => {
			return (
				<div className="col-md-4 mt-3">
					<Popup
						popupKey={data.recomendacao_id}
						titulo={<Link to={`/vagas/${data.recom_vaga.vaga_id}`}>{data.recom_vaga.vaga_titulo}</Link>}
						subtitulo={
							<div className="d-flex">
								<UserInfo utilizador={data.recom_util} children={<p>{data.recom_util.utilizador_tag}</p>} />
								<p>&nbsp;{"· " + getStringDateDiff(data.recomendacao_datacriacao)}</p>
							</div>
						}
						trigger={
							<Card
								titulo={<Link to={`/vagas/${data.recom_vaga.vaga_id}`}>{data.recom_vaga.vaga_titulo}</Link>}
								descricao={data.recomendacao_motivo}
								utilizador={data.recom_util}
								date={getStringDateDiff(data.recomendacao_datacriacao)}
								infoAddon={data.recomendacao_utilizadorrecomendado}
							/>
						}
						childrenBody={
							<div>
								<h4 className="gap-2 d-flex align-items-center">
									<FontAwesomeIcon icon={["fas", "paper-plane"]} />
									{data.recomendacao_utilizadorrecomendado}
								</h4>
								<h4>
									<b>Motivo:</b> {data.recomendacao_motivo}
								</h4>
							</div>
						}
					/>
				</div>
			);
		});
	}

	function handleFilterClear() {
		setVaga(-1);
		setSearchTerm("");
	}

	return (
		<div>
			<PaginationList
				cardsProps={LoadRecomendar()}
				pageTitulo={"Recomendações"}
				pageChildrenFilter={
					<div className="gap-3 d-flex justify-content-end">
						<div>
							<SearchBox
								handleChange={(e) => setSearchTerm(e.target.value)}
								label={"Pesquisar"}
								value={getSearchTerm}
							/>
						</div>
						<Pode se={UserTemPerfis(perfilSuperior, utilizadorAtual.perfil)}>
							<ComboBox
								options={[
									...comboBoxManual(-1, "Todas"),
									...comboBoxOptions(dataVagas, "vaga_id", "vaga_titulo", "vaga_localizacao"),
								]}
								label="Vaga"
								defaultValue={getVaga}
								handleChange={(e) => setVaga(e.target.value)}
								value={getVaga}
							/>
						</Pode>
						<div className="d-flex justify-content-end mt-auto">
							<Button label={"Limpar"} handleClick={handleFilterClear} />
						</div>
					</div>
				}
			/>
		</div>
	);
}
