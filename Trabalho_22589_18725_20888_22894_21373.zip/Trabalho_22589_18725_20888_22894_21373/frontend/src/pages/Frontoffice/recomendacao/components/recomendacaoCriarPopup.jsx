import { useEffect, useState } from "react";
import { createData, useData } from "src/api/dataComponents";
import Popup from "src/components/Pop-up/popup";
import { Button, ComboBox, FileBox, TextArea, TextBox } from "src/components/Form";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { comboBoxOptions } from "src/utils/functionUtils";
import { useAuth } from "src/hooks/useAuth";
import { checkCamposInvalidos, isUserLogged } from "src/utils/dataControl";
import { createFile } from "src/api/fileComponents";
import Row from "src/layouts/Alignment/row";
import { useCarregando } from "src/hooks/useCarregando";
import { statusResponse } from "src/utils/statusUtils";

export default function RecomendacaoCriarPopup({ trigger, preselectedValue = null }) {
	const [getRecVaga, setRecVaga] = useState("");
	const [getRecUtilizador, setRecUtilizador] = useState("");
	const [getRecMotivo, setRecMotivo] = useState("");
	const [getRecCurriculum, setRecCurriculum] = useState("");

	const [dataVaga, loadingVaga] = useData("/vaga/list");

	const { startLoading, stopLoading } = useCarregando();
	const utilizadorAtual = useAuth();

	useEffect(() => {
		if (dataVaga) {
			setRecVaga(preselectedValue);
		}
	}, [preselectedValue, dataVaga])

	async function handleRecomendacaoSubmit() {
		console.log(getRecMotivo, getRecVaga, getRecUtilizador, getRecCurriculum)
		if (!isUserLogged(utilizadorAtual)) return false;
		if (checkCamposInvalidos(getRecMotivo, getRecVaga, getRecUtilizador, getRecCurriculum)) return false;

		startLoading();
		const fileResponse = await createFile(getRecCurriculum);

		const dataPost = {
			recomendacao_motivo: getRecMotivo,
			recomendacao_vaga: getRecVaga,
			recomendacao_utilizadorrecomendado: getRecUtilizador,
			recomendacao_utilizador: utilizadorAtual.id,
			recomendacao_curriculum: fileResponse.data.data.id,
		};
		await statusResponse({
			asyncFunction: () => {
				return createData("/recomendacao/create", dataPost);
			},
			successMessage: "Utilizador foi recomendado com sucesso",
		});
		stopLoading();
	}

	return (
		<Popup
			popupKey={"recomendar"}
			trigger={trigger}
			titulo={"Recomendar"}
			childrenBody={
				<div>
					<Row className="row">
						<TextBox
							label={"Contacto"}
							addon={<FontAwesomeIcon icon={["fas", "paper-plane"]} className="FontAwesomeIconsSmaller" />}
							handleChange={(e) => setRecUtilizador(e.target.value)}
							value={getRecUtilizador}
						/>
						<ComboBox
							label={"Vaga"}
							options={comboBoxOptions(dataVaga, "vaga_id", "vaga_titulo", "vaga_localizacao")}
							handleChange={(e) => setRecVaga(e.target.value)}
							value={getRecVaga}
							defaultValue={getRecVaga}
						/>
					</Row>
					<TextArea
						label={"Motivo"}
						handleChange={(e) => setRecMotivo(e.target.value)}
						value={getRecMotivo}
						marginTop={3}
					/>
					<FileBox
						label={"Curriculum"}
						acceptedTypes={".pdf"}
						marginTop={3}
						handleChange={(e) => setRecCurriculum(e.target.files[0])}
					/>
				</div>
			}
			childrenFooter={<Button label={"Recomendar"} handleClick={handleRecomendacaoSubmit} />}
		/>
	);
}
