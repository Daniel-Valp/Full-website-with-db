import './recomendar.css'
import React from 'react';

import TextBox from "src/components/Form/textBox";
import TextArea from "src/components/Form/textArea";
import FileBox from "src/components/Form/fileBox";
import Popup from "src/components/Pop-up/popup";
import Button from "src/components/Form/button";
import ComboBox from "src/components/Form/comboBox";


export default function RecomendacaoCriar({ vagasOptions }) {
	return (
		<div className="Recomendacao">
			<Popup
				trigger={
					<Button
						label={"recomendar"}
					/>
				}
				titulo={"Recomendar | Experiência em rotinas administrativas"}
				childrenBody={
					<div>
						<div className="form-group col-md-6">
							<ComboBox
								label="Vaga"
								placeHolder="Escolha um opção"
								options={vagasOptions}
							/>
						</div>
						<br/>
						<div className="d-flex">
							<div className="form-group col-md-6" style={{ paddingRight: 10 + 'px' }}>
								<TextBox
									label="Utilizador"
								/>
							</div>
							<div className="form-group col-md-6" style={{ marginLeft: "auto", paddingLeft: 10 + 'px' }}>
								<TextBox
									label="Email"
								/>
							</div>
						</div>
						<br />
						<div className="form-group col-md-12">
							<TextArea
								label="Mensagem de Recomendação"
							/>
						</div>
						<br />
						<div className="form-group">
							<FileBox
								label="Curriculum"
								acceptedTypes=".pdf"
							/>
						</div>
					</div>
				}
				childrenFotter={
					<div className="form-row btn-forms d-flex">
						<div style={{ paddingRight: 10 + 'px' }}>
							<Button
								label={"Limpar"}
								type='secondary'
							/>
						</div>
						<div style={{ paddingRight: 10 + 'px' }}>
							<Button
								label={"Submeter"}
								type='primary'
							/>
						</div>
					</div>
				}
			/>
		</div >
	);
}