import PopupLoadable from "src/components/Pop-up/popupLoadable";
import { useState } from "react";

export const usePopupStatic = () => {
	const [psIsOpen, setpsIsOpen] = useState(false);
	let psTitulo = "";
	let psSubtitulo = "";
	let psIcons = "";
	let psBody = "";
	let psFooter = "";

	const psOpen = () => {
		setpsIsOpen(true);
	};

	const psClose = () => {
		setpsIsOpen(false);
	};

	const psClear = () => {
		psTitulo = "";
		psSubtitulo = "";
		psIcons = "";
		psBody = "";
		psFooter = "";
	};

	const psCloseClear = () => {
		psClose();
		psClear();
	};

	const psCreate = ({ psTitulo, psSubtitulo, psIcons, psBody, psFooter }) => (
		<div>
			{psIsOpen && (
				<PopupLoadable
					titulo={psTitulo}
					subtitulo={psSubtitulo}
					childrenHeaderIcons={psIcons}
					childrenBody={psBody}
					childrenFooter={psFooter}
					onClose={psClose}
				/>
			)}
		</div>
	);

	return {
		psIsOpen,
		psTitulo,
		psSubtitulo,
		psIcons,
		psBody,
		psFooter,
		psCreate,
		psOpen,
		psClose,
		psClear,
		psCloseClear,
	};
};
