import { useState, useMemo } from "react";
import LoadingOperation from "src/components/LoadingPage/loadingOperation";

export const useLoading = () => {
	const [isLoading, setisLoading] = useState(false);

	const startLoading = () => {
		setisLoading(true);
	};

	const stopLoading = () => {
		setisLoading(false);
	};

	const createLoading = useMemo(() => {
		return <div>{isLoading && <LoadingOperation />}</div>;
	}, [isLoading]);

	return { isLoading, setisLoading, startLoading, stopLoading, createLoading };
};
