import { useContext } from 'react';
import { LoadingContext } from 'src/context/loadingContext';

export const useCarregando = () => {
	return useContext(LoadingContext);
};