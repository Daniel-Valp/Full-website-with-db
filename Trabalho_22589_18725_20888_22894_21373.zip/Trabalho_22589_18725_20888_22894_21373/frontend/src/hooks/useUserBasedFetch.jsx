import { useEffect, useState } from "react";
import { useAuth } from "./useAuth";
import { readData } from "src/api/dataComponents";
import { UserTemPerfis } from "src/utils/functionUtils";
import { myAxios } from "src/lib/axios";

export const useUserBasedFetch = ({ perfisPermitidos, generalBaseUrl, userIdentifier }) => {
	const utilizadorAtual = useAuth();
	const [dataList, setDataList] = useState("");
	const [hasPerfilPermitido, setHasPerfilPermitido] = useState(false);

	useEffect(() => {
		const fetchData = async () => {
			if (!utilizadorAtual) return false;

			const hasPerfis = await UserTemPerfis(perfisPermitidos, utilizadorAtual.perfil);

			let options = {};
			if (!hasPerfis) {
				options = {
					data: { [userIdentifier]: utilizadorAtual.id },
					method: "post",
				};
			}

			const response = await myAxios({ url: generalBaseUrl, ...options });
			setHasPerfilPermitido(hasPerfis);
			setDataList(response.data.data);
		};

		fetchData();
	}, [utilizadorAtual]);

	return [dataList, setDataList, hasPerfilPermitido];
};
