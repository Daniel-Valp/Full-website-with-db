import { useContext } from 'react';
import { AuthContext } from 'src/context/authContext';

export const useAuth = () => {
	return useContext(AuthContext);
};