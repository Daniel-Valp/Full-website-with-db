import { userImage } from "src/data/constants";
import { placeholderImage } from "src/data/constants"

export const makeImageUrl = (id, placeholder = "user", def = true) => {
	if (id) {
		const DRIVE_BASE_URL = "https://drive.google.com/uc?export=view&id=";
		return DRIVE_BASE_URL + id;
	} else if (placeholder === "user") {
		return userImage;
	} else if (placeholder === "placeholder") {
		return placeholderImage;
	}
};
