import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import React, { useState } from 'react';

import './pagination.css';

function Pagination({ currentPage = 1, setCurrentPage, totalPages = 1 }) {
	const handlePageChange = (page) => {
		if (page >= 1 && page <= totalPages) {
			setCurrentPage(page);
		}
	};

	return (
		<div className="Pagination" style={{ marginTop: '100px' }}>
			<div className="pagination">
				<ul className="pagination">
					<li className="page-item">
						<button
							className="page-link"
							onClick={() => handlePageChange(currentPage - 1)}
							disabled={currentPage === 1}
						>
							<FontAwesomeIcon icon={['fas', 'chevron-left']} />
						</button>
					</li>
					<li className="page-item disabled">
						<span className="page-link">
							{currentPage} de {totalPages}
						</span>
					</li>
					<li className="page-item">
						<button
							className="page-link"
							onClick={() => handlePageChange(currentPage + 1)}
							disabled={currentPage === totalPages}
						>
							<FontAwesomeIcon icon={['fas', 'chevron-right']} />
						</button>
					</li>
				</ul>
			</div>
		</div>
	);
}

export default Pagination;
