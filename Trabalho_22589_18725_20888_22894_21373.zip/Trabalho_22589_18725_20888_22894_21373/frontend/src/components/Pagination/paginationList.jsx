import React, { useState, useEffect } from "react";

/** Components */
import Pagination from "./pagination";

/** Outros */
import { paginationNumberCards } from 'src/data/constants';
import BasicHeader from '../BasicHeader/basicHeader';


export function PaginationList({ cardsProps, pageTitulo, pageChildrenSubHeader, pageChildrenIcons, pageChildrenFilter }) {
	const [currentPage, setCurrentPage] = useState(1);
	const [totalPages, setTotalPages] = useState(1);

	useEffect(() => {
		const cardElements = cardsProps;
		const newTotalPages = Math.ceil(cardElements.length / paginationNumberCards);
		setTotalPages(newTotalPages);
	}, [cardsProps]);

	function LoadPage() {
		const cardElements = cardsProps;
		const lastCard = (currentPage * paginationNumberCards) - 1;
		const firstCard = ((lastCard - paginationNumberCards) + 1);
		const show = [];
		for (let i = firstCard; i <= lastCard; i++)
			show.push(cardElements[i])
		return show
	}

	return (
		<div className="container">
			<BasicHeader 
				pageTitulo={pageTitulo}
				pageChildrenSubHeader={pageChildrenSubHeader}
				pageChildrenIcons={pageChildrenIcons}
				pageChildrenFilter={pageChildrenFilter}
			/>
			<div className="row">
				{LoadPage()}
			</div>
			<Pagination
				totalPages={totalPages}
				currentPage={currentPage}
				setCurrentPage={setCurrentPage}
			/>
		</div>
	);
}