export function TextArea({ label, linhas = 5, marginTop = 0, handleChange = null, value = null }) {
	return (
		<div className={`TextArea mt-${marginTop}`}>
			<div className="form-group">
				<label htmlFor="input">{label}</label>
				<textarea className="form-control" rows={linhas} onChange={handleChange} title={label} value={value}></textarea>
			</div>
		</div>
	);
}