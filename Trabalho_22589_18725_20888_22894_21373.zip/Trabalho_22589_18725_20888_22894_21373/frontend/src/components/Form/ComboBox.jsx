export function ComboBox({
	label = "",
	labelAddon = "",
	placeHolder = "Escolha uma opção...",
	defaultValue,
	options,
	handleChange = null,
	marginTop = 0,
	defaultOption = null,
	disable = true,
}) {
	return (
		<div className={`form-group mt-${marginTop}`}>
			<div className=" justify-content-between d-flex">
				{label && (
					<div>
						<label htmlFor="inputState">{label}</label>
					</div>
				)}
				{labelAddon && (
					<div>
						<label htmlFor="inputState">{labelAddon}</label>
					</div>
				)}
			</div>
			<select id="inputState" className="form-select" onChange={handleChange}>
				{!defaultValue && (
					<option key={-1} value={-1} disabled={disable} selected>
						{placeHolder}
					</option>
				)}
				{defaultOption && (
					<option key={-1} value={-1}>
						{defaultOption}
					</option>
				)}
				{options &&
					options.map((item) => (
						<option key={item.id} value={item.id} selected={item.id === defaultValue}>
							{item.nome}
						</option>
					))}
			</select>
		</div>
	);
}
