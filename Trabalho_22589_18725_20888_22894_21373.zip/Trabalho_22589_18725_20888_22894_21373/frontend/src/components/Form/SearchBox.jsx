export function SearchBox({ placeHolder = "Pesquisar", handleChange, label = null, value = null }) {
	return (
		<div class="form-group">
			{label && <label htmlFor="input-group">{label}</label>}
			<input
				value={value}
				type="search"
				className="form-control"
				placeholder={placeHolder}
				aria-label="Search"
				aria-describedby="search-addon"
				onChange={handleChange}
				title={placeHolder}
			/>
		</div>
	);
}