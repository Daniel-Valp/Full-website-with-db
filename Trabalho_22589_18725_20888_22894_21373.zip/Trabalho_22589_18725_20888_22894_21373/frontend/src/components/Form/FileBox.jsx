export function FileBox({ label, acceptedTypes, marginTop = 0, handleChange = null }) {
	return (
		<div className={`FileBox mt-${marginTop}`}>
			<label for="formFileMultiple" class="form-label">
				{label}
			</label>
			<input className="form-control" type="file" accept={acceptedTypes} onChange={handleChange} multiple />{" "}
		</div>
	);
}
