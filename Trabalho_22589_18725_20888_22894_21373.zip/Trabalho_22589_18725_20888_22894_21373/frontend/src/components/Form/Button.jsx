import { Link } from "react-router-dom";

import './form.css'

export function Button({
	label,
	type = "primary",
	directTo = null,
	wrapLine = false,
	handleClick = null,
	marginTop = 0,
	icon = null,
}) {
	return (
		<Link to={directTo}>
			<div className={`mt-${marginTop}`} style={{ whiteSpace: wrapLine ? "normal" : "nowrap" }}>
				<button type="button" className={"Button btn btn-block btn-" + type} onClick={handleClick} title={label}>
					<div className="d-flex gap-2">
						{icon && <div>{icon}</div>}
						{label}
					</div>
				</button>
			</div>
		</Link>
	);
}
