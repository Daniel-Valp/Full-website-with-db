import { useEffect } from "react";
import { generateRandomValue } from "src/utils/functionUtils";
import "./form.css";


export function OTPVerification({ codeLength, handleChange, setStateValue }) {
	useEffect(() => {
		function OTPInput() {
			const inputs = document.querySelectorAll("#otp > *[id]");
			for (let i = 0; i < inputs.length; i++) {
				inputs[i].addEventListener("keydown", function (event) {
					if (event.key === "Backspace") {
						inputs[i].value = "";
						if (i !== 0) inputs[i - 1].focus();
					} else {
						if (i === inputs.length - 1 && inputs[i].value !== "") {
							return true;
						} else if (event.keyCode > 47 && event.keyCode < 58) {
							inputs[i].value = event.key;
							if (i !== inputs.length - 1) inputs[i + 1].focus();
							event.preventDefault();
						} else if (event.keyCode > 64 && event.keyCode < 91) {
							inputs[i].value = String.fromCharCode(event.keyCode);
							if (i !== inputs.length - 1) inputs[i + 1].focus();
							event.preventDefault();
						}
					}
					const otpValues = Array.from(inputs).map((input) => input.value);
					setStateValue(otpValues.join(""));
				});
			}
		}
		OTPInput();
	}, []);

	function inputBoxes() {
		const inputBoxes = [];
		for (let i = 0; i < codeLength; i++) {
			inputBoxes.push(
				<input
					maxLength="1"
					type="text"
					className="m-2 text-center form-control rounded"
					id={generateRandomValue(10000).toString()}
					onChange={handleChange}
					style={{ width: '40px', height: '40px' }}
				/>
			);
		}
		return inputBoxes;
	}

	return (
		<div className="p-2 text-center">
			<div id="otp" className="otp-inputs d-flex flex-row justify-content-center mt-2">
				{inputBoxes()}
			</div>
		</div>
	);
}
