export function DatePicker({ label, value, handleChange }) {
	return (
		<div>
			{label && <label htmlFor="datepicker">{label}</label>}
			<input type="date" id="datepicker" className="form-control" value={value} onChange={handleChange} />
		</div>
	);
}
