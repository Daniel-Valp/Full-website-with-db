import { useState } from "react";

export function MultiSelectComboBox() {
	const [selectedOptions, setSelectedOptions] = useState([]);

	const handleSelectChange = (event) => {
		const selectedValues = Array.from(event.target.selectedOptions, (option) => option.value);
		setSelectedOptions(selectedValues);
	};

	return (
		<div className="form-group">
			<label htmlFor="inputState" className="form-label">
				Select Options
			</label>
			<select id="inputState" className="form-select" multiple value={selectedOptions} onChange={handleSelectChange}>
				<option value="1">One</option>
				<option value="2">Two</option>
				<option value="3">Three</option>
				<option value="4">Four</option>
				<option value="5">Five</option>
				<option value="6">Six</option>
				<option value="7">Seven</option>
				<option value="8">Eight</option>
				<option value="9">Nine</option>
				<option value="10">Ten</option>
			</select>
		</div>
	);
}