export function Radio({ label }) {
	return (
		<div>
			<div class="form-check">
				<input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1" />
				<label class="form-check-label" for="flexRadioDefault1">
					{label}
				</label>
			</div>
		</div>
	);
}