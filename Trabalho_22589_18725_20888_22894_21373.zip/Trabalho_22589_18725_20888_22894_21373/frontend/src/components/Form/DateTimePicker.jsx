export function DateTimePicker({ label, handleChange, marginTop = 0, defaultValue = null }) {
	return (
		<div className={`mt-${marginTop}`}>
			{label && <label htmlFor="inputNome">{label}</label>}
			<input
				type="datetime-local"
				id="start-date"
				className="form-control"
				onChange={handleChange}
				value={defaultValue}
			/>
		</div>
	);
}
