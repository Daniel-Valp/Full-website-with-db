export function ImageBox({ image, alt = "Erro", acceptedTypes, marginTop = 0, handleChange = null }) {
	return (
		<div class="container mt-5">
			<div class="row">
				<div class="col-md-6 offset-md-3">
					<div class="card">
						<div class="card-header">
							<h5 class="card-title">Select Image</h5>
						</div>
						<div class="card-body">
							<div class="form-group">
								<input type="file" src={image} class="form-control-file" id="image-input" />
							</div>
							<div class="text-center">
								<img src={image} className="img-fluid" alt="" />
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	);
}
