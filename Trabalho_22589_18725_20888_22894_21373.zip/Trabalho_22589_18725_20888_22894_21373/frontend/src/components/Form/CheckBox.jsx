import { Form } from "react-router-dom";

export function CheckBox({ label, marginTop = 0 }) {
	return (
		<div className={`mt-${marginTop}`}>
			<Form.Check type="checkbox" label={label} />
		</div>
	);
}
