function BasicHeader({ pageTitulo, pageChildrenSubHeader = "", pageChildrenIcons = "", pageChildrenFilter = "" }) {
	return (
		<div>
			<div>
				<h1 className="titulo-pag">{pageTitulo}</h1>
			</div>
			<div className="d-flex">
				{pageChildrenSubHeader &&
					<div>
						{pageChildrenSubHeader}
					</div>
				}
				<div className="icon-header">
					{pageChildrenIcons}
				</div>
			</div>
			<div className="filter-header mt-3">
				{pageChildrenFilter}
			</div>
		</div>
	);
}

export default BasicHeader;