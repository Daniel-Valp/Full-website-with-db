import React from 'react';

export default function ErrorPage({ error, descricao }) {
	return (
		<div>
			<div className="d-flex justify-content-center align-items-center vh-100">
				<div className='text-center'>
					<h1>{error}</h1>
					<p>{descricao}</p>
				</div>
			</div>
		</div>
	);
};