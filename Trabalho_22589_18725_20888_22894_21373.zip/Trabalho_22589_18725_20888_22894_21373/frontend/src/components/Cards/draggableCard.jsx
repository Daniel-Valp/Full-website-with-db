import { Draggable } from "react-beautiful-dnd";
import Card from "./card";

export function DraggableCard({ id, index, titulo, descricao, directTo, utilizador = "", date = "", arrow = false, button: { text } = {}, img: { src, alt = "Era suposta estar aqui um cartão" } = {}, infoAddon = null }) {
	return (
		<Draggable draggableId={id} index={index}>
			{(provided, snapshot) => (
				<div
					ref={provided.innerRef}
					{...provided.draggableProps}
					{...provided.dragHandleProps}
				>
					<Card
						titulo={titulo}
						descricao={descricao}
						directTo={directTo}
						utilizador={utilizador}
						date={date}
						arrow={arrow}
						button={{ text }}
						img={{ src, alt }}
						infoAddon={infoAddon}
					/>
				</div>
			)}
		</Draggable>
	);
}