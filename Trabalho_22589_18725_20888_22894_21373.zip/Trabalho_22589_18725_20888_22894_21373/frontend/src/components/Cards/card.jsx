import { Link } from "react-router-dom";
import './card.css'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import UserInfo from "../OverlayTooltip/userInfo";
import { makeImageUrl } from "../Imagens/utilizadorImagem";


function Card({ titulo, descricao, directTo, utilizador = "", date = "", arrow = false, button: { text } = {}, img: { src, alt = "Era suposta estar aqui um cartão" } = {}, infoAddon = null }) {
	return (
		<div className="Card">
			<Link style={{ textDecoration: 'none', color: 'black' }} to={directTo}>
				<div className="card active shadow-sm">
					{src &&
						<img className="card-img-top" src={src} alt={alt} />
					}
					<div className="cartao-corpo card-body d-flex justify-content-between">
						<div>
							{utilizador === "" ? null : (
								<div className="d-flex">
									<div className="d-flex gap-1">
										<img src={makeImageUrl(utilizador.utilizador_imagem)} alt="" className="conta-imagem-pequena" />
										{typeof utilizador === 'object' ? (
											<UserInfo utilizador={utilizador} children={<h5>{utilizador.utilizador_tag}</h5>} />
										) : (
											<h5>{utilizador}</h5>
										)}
									</div>
									{date &&
										<h5 className="texto-secundario">&nbsp;· {date}</h5>
									}
								</div>
							)}
							{infoAddon &&
								<div className="d-flex">
									<FontAwesomeIcon icon={["fas", "paper-plane"]} className='FontAwesomeIconsSmaller' />
									<h5>{infoAddon}</h5>
								</div>
							}
							{titulo &&
								<div className="cartao-corpo-titulo" title={titulo}>
									<h4 className="card-title-header">{titulo}</h4>
								</div>
							}
							{descricao &&
								<div className="cartao-corpo-descricao" title={descricao}>
									<p className="card-body-descricao">{descricao}</p>
								</div>
							}
						</div>
						{arrow === false ? null : (
							<div className="align-self-center">
								<FontAwesomeIcon icon={["fas", "fa-chevron-right"]} className='FontAwesomeIcons' />
							</div>
						)}
					</div>
				</div>
			</Link>
		</div >
	);
}


export default Card;