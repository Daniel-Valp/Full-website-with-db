export default function CardSection({ titulo, content }) {
	return (
		<div className="container my-4">
			<div className="card p-4">
				<h3>{titulo}</h3>
				<p>{content}</p>
			</div>
		</div>
	);
}