import { useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import './card.css'

function DropdownCard({ id, user, action, interaction, more = '', dateAdded, content, imgSrc, imgAlt }) {
	const [isCollapsed, setIsCollapsed] = useState(false);

	const toggleCollapse = () => {
		setIsCollapsed(!isCollapsed);
	};

	const collapseId = `card-content-${id}`;

	return (
		<div className="DropdownCard card">
			<div
				className="card-header"
				onClick={toggleCollapse}
				aria-controls={collapseId}
				aria-expanded={!isCollapsed}
			>
				<div style={{ display: 'flex', alignItems: 'center' }}>
					<img src={imgSrc} alt={imgAlt} style={{ width: '50px', height: '50px', marginRight: '10px', borderRadius: '50%' }} />
					<div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', width: '100%' }}>
						<div>
							<strong>{user}</strong> {action} <strong>{interaction}</strong> {more}
							<div style={{ fontSize: '14px' }}>{dateAdded}</div>
						</div>
						<div>
							<FontAwesomeIcon
								icon={['fas', 'chevron-down']}
								className="FontAwesomeIconsStatic btn btn-link"
								aria-hidden="true"
								style={{ marginLeft: 'auto' }}
							/>
						</div>
					</div>
				</div>
			</div>
			<div className={`card-body collapse ${isCollapsed ? 'show' : ''}`} id={collapseId}>
				{content}
			</div>
		</div>
	);
}


export default DropdownCard;