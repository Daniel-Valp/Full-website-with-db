/** Componentes */
import DropdownCard from '../Cards/dropdownCard';

/** Funções */
import { toLowerFirstLetter } from 'src/utils/functionUtils'



function DropdownSection({ title, icons, items }) {
	return (
		<div>
			<div className="d-flex align-items-center justify-content-between border-bottom border-dark no-select">
				<h2>{title}</h2>
				{icons}
			</div>
			<br />
			{items && items.length > 0 && Array.isArray(items) ? items.map(item => (
					<div className="col-md-12" style={{ marginBottom: 10 + 'px' }}>
						<DropdownCard
							id={item.id}
							user={item.user}
							action={item.action}
							interaction={item.interaction}
							more={item.more}
							dateAdded={item.dateAdded}
							content={item.content}
							imgSrc={item.imgSrc}
							imgAlt={item.imgAlt}
						/>
					</div>
				)) : <p>Não existe {toLowerFirstLetter(title)}</p>
			}
		</div>
	);
};

export default DropdownSection;