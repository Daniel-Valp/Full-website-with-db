import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { useState } from "react";
import { Link } from "react-router-dom";
import BasicHeader from "src/components/BasicHeader/basicHeader";
import { Button, SearchBox } from "src/components/Form";
import { filterDataByAllColumns } from "src/utils/dataManipulation";
import TabelaApagar from "./tabelaApagar";
import { Pode } from "src/components/Permissoes/Pode";

export default function TabelaLista({
	table,
	tableName,
	tableDeleteRoute = null,
	children = null,
	removerAdicionar = false,
	removerEditar = false,
	removerApagar = false,
}) {
	// table ->  'nome_da_colunas_pretendida': nome_da_variavel & primeira coluna tem que ser a key
	const [searchTerm, setSearchTerm] = useState("");
	const colunas = Object.keys(table[0]);
	const linhas = table;
	const tableKey = Object.keys(table[0])[0];

	function LoadRows() {
		const filteredData = filterDataByAllColumns(linhas, searchTerm);
		const sortedData = filteredData.sort((a, b) => Number(a[tableKey]) - Number(b[tableKey]));
		return sortedData.map((linha) => {
			return (
				<tr key={linha[tableKey]}>
					{colunas.map((coluna) => (
						<td>
							<p>{linha[coluna]}</p>
						</td>
					))}
					<Pode se={!removerEditar}>
						<td>
							<Link to={`editar/${linha[tableKey]}`}>
								<FontAwesomeIcon
									icon={["fas", "pencil"]}
									title="Editar"
									className="FontAwesomeIcons link-colorido link-colorido-hover"
								/>
							</Link>
						</td>
					</Pode>
					<Pode se={!removerApagar}>
						{tableDeleteRoute && (
							<td>
								<FontAwesomeIcon
									icon={["fas", "trash"]}
									title="Apagar"
									onClick={() => TabelaApagar(linha[tableKey], tableDeleteRoute)}
									className="FontAwesomeIcons link-colorido-perigo link-colorido-hover"
								/>
							</td>
						)}
					</Pode>
				</tr>
			);
		});
	}

	function LoadColumns() {
		return (
			<tr>
				{colunas.map((coluna) => (
					<th>
						<h4 title={coluna}>
							<b>{coluna}</b>
						</h4>
					</th>
				))}
				<th colSpan="2"></th>
			</tr>
		);
	}

	return (
		<div>
			<BasicHeader
				pageTitulo={tableName}
				pageChildrenFilter={
					<div>
						<div className="mb-3 d-flex gap-3">
							<Pode se={!removerAdicionar}>
								<div className="d-flex gap-3 mt-2">
									<Button
										label={"Adicionar"}
										icon={<FontAwesomeIcon icon={["fas", "plus"]} />}
										directTo={"criar"}
									/>
								</div>
							</Pode>
							{children}
						</div>
						<SearchBox handleChange={(e) => setSearchTerm(e.target.value)} />
					</div>
				}
			/>
			<div className="overflow-auto table-container">
				<table className="table table-hover table-striped">
					<thead className="thead-dark">
						<LoadColumns />
					</thead>
					<tbody>
						<LoadRows />
					</tbody>
				</table>
			</div>
		</div>
	);
}
