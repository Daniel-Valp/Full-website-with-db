import { deleteData } from 'src/api/dataComponents';
import Swal from 'sweetalert2/dist/sweetalert2.js'


export default async function TabelaApagar(id, route) {
	Swal.fire({
		title: 'Apagar',
		text: 'Tem certeza que quer apagar este item?',
		type: 'warning',
		showCancelButton: true,
		confirmButtonText: 'Confirmar',
		cancelButtonText: 'Cancelar'
	}).then((result) => {
		if (result.value) {
			const response = deleteData(`/${route}/delete/${id}`);
			if (response)
				Swal.fire('Apagado!', 'O item foi apagado.', 'success');
			else
				Swal.fire({ icon: 'error', title: 'Error', text: 'Error 325' });
		}
		else {
			Swal.fire('Cancelado', 'O item não foi apagado.', 'error')
		}
	})
}