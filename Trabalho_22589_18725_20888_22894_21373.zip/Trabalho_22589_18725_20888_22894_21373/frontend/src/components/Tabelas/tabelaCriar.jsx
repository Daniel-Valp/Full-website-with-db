import BasicHeader from "src/components/BasicHeader/basicHeader";
import { Button, ComboBox, TextArea, TextBox } from "src/components/Form";
import { CarregaComponentes } from "./carregaComponentes";

export default function TabelaCriar({ form, handleSubmit, titulo }) {
	return (
		<div>
			<BasicHeader
				pageTitulo={titulo + ' - Criar'}
			/>
			<div className="container">
				<div>
					{CarregaComponentes(form)}
				</div>
				<Button label={'Criar'} marginTop={5} handleClick={handleSubmit} />
			</div>
		</div>
	);
}