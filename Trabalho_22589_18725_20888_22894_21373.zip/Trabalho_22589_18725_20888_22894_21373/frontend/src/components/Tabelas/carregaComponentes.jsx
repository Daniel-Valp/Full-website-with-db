import { ComboBox, TextArea, TextBox } from "src/components/Form";

export function CarregaComponentes(form) {
	return form.map((field, index) => (
		<div key={index}>
			{(field.comp === 'text' || field.comp === 'number' || field.comp === 'password') && (
				<TextBox
					label={field.label}
					handleChange={(e) => field.setter(e.target.value)}
					value={field.getter}
					inputType={field.comp}
					marginTop={3}
				/>
			)}
			{field.comp === 'list' && (
				<ComboBox
					label={field.label}
					handleChange={(e) => field.setter(e.target.value)}
					value={field.getter}
					options={field.options}
					marginTop={3}
					defaultValue={field.getter}
				/>
			)}
			{field.comp === 'area' && (
				<TextArea
					label={field.label}
					handleChange={(e) => field.setter(e.target.value)}
					value={field.getter}
					marginTop={3}
				/>
			)}
		</div>
	));
}