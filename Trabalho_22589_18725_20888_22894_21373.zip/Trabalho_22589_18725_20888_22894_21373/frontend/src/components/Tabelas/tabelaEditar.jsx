import BasicHeader from "src/components/BasicHeader/basicHeader";
import { Button, ComboBox, TextArea, TextBox } from "src/components/Form";
import { CarregaComponentes } from "./carregaComponentes";
import { useCarregando } from "src/hooks/useCarregando";
import { statusResponse } from "src/utils/statusUtils";

export default function TabelaEditar({ form, handleUpdate, titulo }) {
	const { startLoading, stopLoading } = useCarregando();

	async function handleUpdateFunction() {
		startLoading();
		await statusResponse({
			asyncFunction: () => handleUpdate(),
			successMessage: "Tabela editada com sucesso!"
		})
		stopLoading();
	}

	return (
		<div>
			<BasicHeader pageTitulo={titulo + " - Editar"} />
			<div className="container">
				<div>{CarregaComponentes(form)}</div>
				<Button label={"Editar"} marginTop={5} handleClick={handleUpdateFunction} />
			</div>
		</div>
	);
}
