import './loadingPage.css'; // Import the CSS file for styling


export default function LoadingCircle() {
	return (
		<div className="loading-circle"></div>
	);
}