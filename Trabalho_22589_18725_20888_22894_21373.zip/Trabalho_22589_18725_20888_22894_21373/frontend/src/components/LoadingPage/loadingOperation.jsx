import React from 'react';
import './loadingPage.css'; // Import the CSS file for styling
import LoadingCircle from './loadingCircle';

const LoadingOperation = () => {
	return (
		<div className="loading-operation">
			<LoadingCircle />
		</div>
	);
};

export default LoadingOperation;