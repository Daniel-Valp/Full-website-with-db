import './loadingPage.css'; // Import the CSS file for styling


export default function CarregandoDados() {
	return (
		<div className="carregando-dados"></div>
	);
}