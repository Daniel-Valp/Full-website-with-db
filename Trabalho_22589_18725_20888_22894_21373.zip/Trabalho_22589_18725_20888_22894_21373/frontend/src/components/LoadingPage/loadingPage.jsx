import React from 'react';
import './loadingPage.css'; // Import the CSS file for styling
import LoadingCircle from './loadingCircle';

const LoadingPage = () => {
	return (
		<div className="loading-page">
			<LoadingCircle />
		</div>
	);
};

export default LoadingPage;