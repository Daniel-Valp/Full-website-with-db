export function LoadWhile(...loading) {
	if (loading.some((value) => value)) return true;
}
