import React, { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import "./menuDropdown.css";

export default function MenuDropdown({ trigger, items }) {
	const menuDropdownRef = useRef(null);
	const [isOpen, setIsOpen] = useState(false);

	const toggleDropdown = () => {
		setIsOpen(!isOpen);
	};

	useEffect(() => {
		const handleOutsideClick = (event) => {
			if (menuDropdownRef.current && !menuDropdownRef.current.contains(event.target)) setIsOpen(false);
		};
		window.addEventListener("mouseup", handleOutsideClick);
		return () => {
			window.removeEventListener("mouseup", handleOutsideClick);
		};
	});

	return (
		<div className="dropdown no-select" onClick={toggleDropdown} ref={menuDropdownRef}>
			{trigger}
			{isOpen && (
				<div className="dropdown-content">
					{items &&
						items.map((item) => (
							<div>
								{item?.newGroup ? <hr className="remove-margin-padding custom-hr" /> : null}
								<Link to={item.rota} className="dropdown-item hover-regular gap-3 d-flex align-items-center">
									<FontAwesomeIcon icon={["fas", item?.icon ? item.icon : "placeholder"]} />
									{item.nome}
								</Link>
							</div>
						))}
				</div>
			)}
		</div>
	);
}
