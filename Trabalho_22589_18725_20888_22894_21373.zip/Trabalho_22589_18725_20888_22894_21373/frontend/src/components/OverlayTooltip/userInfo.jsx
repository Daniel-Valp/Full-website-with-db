import React from 'react';

/** Componentes */
import OverlayTooltip from './overlayTooltip'

import { makeImageUrl } from '../Imagens/utilizadorImagem';

const UserInfo = ({ utilizador, children }) => {
	return (
		<OverlayTooltip
			key={utilizador.utilizador_tag}
			childrenOverlay={
				<div>
					<img src={makeImageUrl(utilizador.utilizador_imagem)} alt='' className="conta-imagem rounded-circle" />
					<p className='texto-inverso'>{utilizador.utilizador_nome + " " + utilizador.utilizador_apelido}</p>
					<p className='texto-inverso'>{utilizador.utilizador_tag}</p>
					<p className='texto-inverso'>{utilizador.utilizador_email}</p>
				</div>
			}
			route={`/conta/${utilizador.utilizador_tag}`}
		>
			{children}
		</OverlayTooltip>
	);
};

export default UserInfo;
