import React from 'react';
import { Link } from "react-router-dom";
import { OverlayTrigger, Tooltip } from 'react-bootstrap';


const OverlayTooltip = ({ key, childrenOverlay, children, route }) => {
	/* NOTE: talvez alterar o placementpara "bottom" */
	return (
		<OverlayTrigger
			key={key}
			placement={"auto"}
			overlay={
				<Tooltip>
					<div>
						{childrenOverlay}
					</div>
				</Tooltip>
			}
		>
			{route ? (
				<Link className='cursor-ponteiro' to={route}>
					{children}
				</Link>
			) : (
				<div className='cursor-ponteiro'>
					{children}
				</div>
			)}
		</OverlayTrigger>
	);
};

export default OverlayTooltip;
