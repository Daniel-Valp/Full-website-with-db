import React from 'react';

/** Componentes */
import OverlayTooltip from './overlayTooltip'

const BasicInfo = ({ key, childrenOverlay, children, route }) => {
	return (
		<OverlayTooltip
			key={key}
			childrenOverlay={
				<div>{childrenOverlay}</div>
			}
			route={route}
		>
			<div>
				{children}
			</div>
		</OverlayTooltip>
	);
};

export default BasicInfo;
