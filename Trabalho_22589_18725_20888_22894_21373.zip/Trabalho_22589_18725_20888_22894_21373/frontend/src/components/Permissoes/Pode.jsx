export function Pode({ se, children }) {
	return <>{se ? children : null}</>;
}
