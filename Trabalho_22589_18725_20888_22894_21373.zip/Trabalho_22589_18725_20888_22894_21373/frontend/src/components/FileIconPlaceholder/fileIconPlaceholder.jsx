import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import "./fileIcon.css";
import { Link } from "react-router-dom";

export function FileIcon({ label, directTo }) {
	return (
		<Link to={directTo} target="_blank">
			<FontAwesomeIcon icon={["fas", "file-pdf"]} className="fileIconPlaceholder" />
			<p>{label}</p>
		</Link>
	);
}
