import React, { useState } from "react";
import "./popupStatus.css"; // Import your custom CSS for styling the notification popup
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import Swal from "sweetalert2/dist/sweetalert2.js";
import { ToastContainer, toast } from "react-toastify";


export function PopupStatus(text, tipo = "success") {
	if (tipo !== 'success' && tipo !== 'info' && tipo !== 'warn' && tipo !== 'error')
		console.error('PopupStatus tipo está mal configurado!');
	toast[tipo](text, {
		position: "top-right",
		autoClose: 2000,
		hideProgressBar: false,
		closeOnClick: true,
		pauseOnHover: false,
		draggable: true,
		progress: undefined,
		theme: "light",
	});
}
