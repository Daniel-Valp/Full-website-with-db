import React from 'react';

import './sidebar.css'
import { Link } from 'react-router-dom';
import Popup from './popup';
import ReuniaoDetalhesPopup from 'src/pages/Frontoffice/reuniao/components/reuniaoDetalhesPopup';

function Sidebar({ titulo, conteudo }) {
	return (
		<div className="container sidebar-container">
			<div className="sidebar">
				<div className="header">
					<h2>{titulo}</h2>
				</div>
				<div className="body">
					<ul>
						{conteudo.map((evento) => (
							<li key={evento.reuniao_id}>
								<ReuniaoDetalhesPopup
									key={evento.reuniao_id}
									button={
										<Link>{evento.reuniao_titulo}</Link>
									}
									data={evento}
								/>
							</li>
						))}
					</ul>
				</div>
			</div>
		</div>
	);
};

export default Sidebar;