import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import React, { useEffect, useState, useRef } from 'react';


function Popup({ trigger, titulo, subtitulo, childrenHeaderIcons, childrenBody, childrenFooter, popupKey, maxHeight = 90 }) {
	const [isOpen, setIsOpen] = useState(false);
	const popupId = `popup-${popupKey}`;
	const popupRef = useRef(null);

	useEffect(() => {
		const urlParams = new URLSearchParams(window.location.search);
		const idParam = urlParams.get('popupId');
		if (idParam === popupKey?.toString()) {
			setIsOpen(true);
			document.body.classList.add('modal-open');
		} else {
			setIsOpen(false);
			document.body.classList.remove('modal-open');
		}
	}, [popupKey]);

	/* useEffect(() => {
		const urlParams = new URLSearchParams(window.location.search);
		const idParam = urlParams.get('popupId');

		if (idParam === popupKey?.toString()) {
			openPopup();
		}
	}); */

	useEffect(() => {
		const handleKeyDown = (event) => {
			if (event.key === 'Escape') {
				closeModal();
			}
		};
		window.addEventListener('keyup', handleKeyDown);
		return () => {
			window.removeEventListener('keyup', handleKeyDown);
		};
	}, []);

	useEffect(() => {
		const handleOutsideClick = (event) => {
			if (popupRef.current && !popupRef.current.contains(event.target)) {
				setIsOpen(false);
				document.body.classList.remove('modal-open');
			}
		};
		if (isOpen) {
			window.addEventListener('mouseup', handleOutsideClick);
		}
		return () => {
			window.removeEventListener('mouseup', handleOutsideClick);
		};
	}, [isOpen]);

	useEffect(() => {
		const handleUrlChange = () => {
			const urlParams = new URLSearchParams(window.location.search);
			const idParam = urlParams.get('popupId');
			if (idParam !== popupKey?.toString() || !idParam || !urlParams) {
				closeModal();
			}
		};
		window.addEventListener('popstate', handleUrlChange);
		return () => {
			window.removeEventListener('popstate', handleUrlChange);
		};
	}, [popupKey]);

	const closeModal = () => {
		setIsOpen(false);
		const urlParams = new URLSearchParams(window.location.search);
		urlParams.delete('popupId');
		const newUrl = `${window.location.origin}${window.location.pathname}?${urlParams.toString()}`;
		window.history.replaceState(null, '', newUrl);
	};

	const openPopup = () => {
		setIsOpen(true);
		const urlParams = new URLSearchParams(window.location.search);
		urlParams.set('popupId', popupKey);
		const newUrl = `${window.location.origin}${window.location.pathname}?${urlParams.toString()}`;
		window.history.pushState(null, '', newUrl);
	};

	return (
		<div className="Popup">
			<span onClick={openPopup}>{trigger}</span>
			{isOpen && (
				<div>
					<div className="modal-backdrop bg-dark opacity-50"></div>
					<div className="modal fade show" id={popupId} aria-hidden="true" style={{ display: 'block' }}>
						<div className="modal-dialog modal-lg" style={{ maxHeight: maxHeight + 'vh', height: '100%' }}>
							<div className="modal-content" style={{ height: '100%' }} ref={popupRef}>
								{titulo && (
									<div className="modal-header">
										<div>
											<h2 className="modal-title" id="exampleModalLabel">{titulo}</h2>
											<div>
												{subtitulo}
											</div>
										</div>
										<div className="d-flex align-items-center">
											{childrenHeaderIcons}
											<FontAwesomeIcon icon={['fas', 'x']} className="FontAwesomeIcons" onClick={closeModal} title="Fechar" />
										</div>
									</div>
								)}
								{childrenBody && (
									<div className="modal-body" style={{ overflowY: 'auto' }}>
										{childrenBody}
									</div>
								)}
								{childrenFooter &&
									<div className="modal-footer">
										{React.cloneElement(childrenFooter, { closeModal })}
									</div>
								}
							</div>
						</div>
					</div>
				</div>
			)}
		</div>
	);
}

export default Popup;