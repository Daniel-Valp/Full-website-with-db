import './popup.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

function Popup({ trigger, titulo, childrenHeaderIcons, childrenBody, childrenFooter, popupKey }) {
  const popupId = `popup-${popupKey}`;

  return (
    <div className="Popup">
      <span data-bs-toggle="modal" data-bs-target={`#${popupId}`}>
        {trigger}
      </span>
      <div className="modal fade" id={`${popupId}`} aria-hidden="true">
        <div className="modal-dialog modal-lg" style={{ maxHeight: '90vh', height: '100%' }}>
          <div className="modal-content" style={{ height: '100%' }}>
            {titulo && (
              <div className="modal-header">
                <div>
                  <h2 className="modal-title" id="exampleModalLabel">{titulo}</h2>
                </div>
                <div className="d-flex align-items-center">
                  {childrenHeaderIcons}
                  <FontAwesomeIcon icon={['fas', 'times']} className="FontAwesomeIcons align-self-center" data-bs-dismiss="modal" aria-label="Close" />
                </div>
              </div>
            )}
            {childrenBody && (
              <div className="modal-body" style={{ overflowY: 'auto' }}>
                {childrenBody}
              </div>
            )}
            {childrenFooter && (
              <div className="modal-footer">
                {childrenFooter}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default Popup;