import React from 'react';
import ReactDOM from 'react-dom';

function PopupState({ onClose, data }) {
	if (!data) {
		return null; // Don't render anything if data is null or empty
	}

	return ReactDOM.createPortal(
		<div className="popup-overlay">
			<div className="popup-container">
				<button className="popup-close" onClick={onClose}>
					Close
				</button>
				<div className="popup-content">
					<p>a</p>
					{data.map((item, index) => (
						<div key={index}>{item.title}</div>
					))}
				</div>
			</div>
		</div>,
		document.getElementById('popup-root')
	);
}

export default PopupState;