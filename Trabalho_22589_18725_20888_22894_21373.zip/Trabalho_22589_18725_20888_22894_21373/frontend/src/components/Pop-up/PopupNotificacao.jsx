import React, { useState, useRef, useEffect } from 'react';
import './PopupNotificacao.css'; // Custom CSS file for styling the popup


const PopupNotificacao = ({ LoadNotificacao, trigger }) => {
	const [isOpen, setIsOpen] = useState(false);
	const popupRef = useRef(null);
	useEffect(() => {
		document.addEventListener('mousedown', handleClickOutside);
		return () => {
			document.removeEventListener('mousedown', handleClickOutside);
		};
	}, []);

	const handleToggle = () => {
		setIsOpen(!isOpen);
	};

	const handleClickOutside = (event) => {
		if (popupRef.current && !popupRef.current.contains(event.target)) {
			setIsOpen(false);
		}
	};

	return (
		<div className="popup-container">
			<div onClick={handleToggle}>{trigger}</div>
			{isOpen && (
				<div className="popup" ref={popupRef}>
					<div className="popup-header">
						<h3>Notificações</h3>
					</div>
					<div className="popup-body">
						{LoadNotificacao}
					</div>
				</div>
			)}
		</div>
	);
};


export default PopupNotificacao