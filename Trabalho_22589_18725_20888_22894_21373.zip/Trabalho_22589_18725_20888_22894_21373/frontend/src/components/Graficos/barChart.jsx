import React, { useEffect, useRef } from 'react';
import { Chart, registerables } from 'chart.js';

/** Funções */
import { generateRandomColor } from 'src/utils/functionUtils';


Chart.register(...registerables);

const BarChart = ({ labels, datasets }) => {
	const chartRef = useRef(null);

	useEffect(() => {
		const chartOptions = {
			// Chart configuration options
		};

		const chartData = {
			labels: labels,
			datasets: datasets.map((dataset) => ({
				...dataset,
				backgroundColor: generateRandomColor(dataset.data.length, 0.7),
			})),
		};


		const myChart = new Chart(chartRef.current, {
			type: 'bar',
			data: chartData,
			options: chartOptions,
		});

		return () => {
			myChart.destroy();
		};
	},);

	return <canvas ref={chartRef} />;
};

export default BarChart;