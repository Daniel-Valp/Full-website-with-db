import React, { useState, useEffect } from "react";
import { DragDropContext, Draggable, Droppable } from "react-beautiful-dnd";
import { updateData } from "src/api/dataComponents";
import Popup from "src/components/Pop-up/popup";
import { getCssColors } from "src/data/colors";


async function handleChangeUpdate(id, estado) {
	const data = {
		ideia_estado: estado,
	};
	await updateData(`/ideia/update/${id}`, data);
}

const onDragEnd = (result, columns, setColumns) => {
	if (!result.destination) return;
	const { source, destination } = result;

	if (source.droppableId !== destination.droppableId) {
		const sourceColumn = columns[source.droppableId];
		const destColumn = columns[destination.droppableId];
		const sourceItems = [...sourceColumn.items];
		const destItems = [...destColumn.items];
		const [removed] = sourceItems.splice(source.index, 1);
		destItems.splice(destination.index, 0, removed);
		setColumns({
			...columns,
			[source.droppableId]: {
				...sourceColumn,
				items: sourceItems
			},
			[destination.droppableId]: {
				...destColumn,
				items: destItems
			}
		});

		// Update the estado and id states based on the dropped card
		const droppedItem = removed;
		handleChangeUpdate(droppedItem.id, droppedItem.estado);
	} else {
		const column = columns[source.droppableId];
		const copiedItems = [...column.items];
		const [removed] = copiedItems.splice(source.index, 1);
		copiedItems.splice(destination.index, 0, removed);
		setColumns({
			...columns,
			[source.droppableId]: {
				...column,
				items: copiedItems
			}
		});
	}
};

export default function Board({ data }) {
	const [columns, setColumns] = useState(data);
	return (
		<div>
			<div className="overflow-x no-select d-flex justify-content-center" style={{ height: "100%" }}>
				<DragDropContext onDragEnd={result => onDragEnd(result, columns, setColumns)} >
					{Object.entries(columns).map(([columnId, column], index) => {
						return (
							<div className="d-flex align-items-center" style={{ flexDirection: "column" }} key={columnId}>
								<h2>{column.name}</h2>
								<div style={{ margin: 8 }}>
									<Droppable droppableId={columnId} key={columnId}>
										{(provided, snapshot) => {
											return (
												<div {...provided.droppableProps} ref={provided.innerRef}
													style={{
														background: snapshot.isDraggingOver ? getCssColors('light-primary-color') : getCssColors('divider-color'),
														padding: 4, width: 250, minHeight: '80vh',
														borderRadius: '10px'
													}}
												>
													{column.items.map((item, index) => {
														return (
															<Draggable key={item.id} draggableId={item.id} index={index} >
																{(provided, snapshot) => {
																	return (
																		<div
																			ref={provided.innerRef}
																			{...provided.draggableProps}
																			{...provided.dragHandleProps}
																			style={{
																				userSelect: "none",
																				margin: "0 0 8px 0",
																				minHeight: "50px",
																				/*backgroundColor: snapshot.isDragging ? "#263B4A" : "#456C86",*/
																				...provided.draggableProps.style
																			}}
																		>
																			<Popup
																				trigger={
																					<Card
																						titulo={item.titulo}
																						descricao={item.descricao}
																					/>
																				}
																				titulo={item.titulo}
																				popupKey={item.id}
																				childrenBody={<p>a</p>}
																			/>
																		</div>
																	);
																}}
															</Draggable>
														);
													})}
													{provided.placeholder}
												</div>
											);
										}}
									</Droppable>
								</div>
							</div>
						);
					})}
				</DragDropContext>
			</div>
		</div>
	);
}
