export const backendUrl = process.env.REACT_APP_BACKEND_URL;
export const paginationNumberCards = 9;
export const userAuthLocalStorageItem = 'userAuth'
export const perfisId = {
	Admin: 1,
	RH: 2,
	GIdeias: 3,
	GNegocios: 4,
	Colaborador: 5,
	Visitante: 6,
	SUPERIORES: [1, 2, 3, 4]
}
export const perfisNome = {
	1: "Administrador",
	2: "Recursos Humanos",
	3: "Gestor de Ideias",
	4: "Gestor de Negócios",
	5: "Colaborador",
	6: "Visitante",
}
export const userImage = require('src/assets/images/logo-default.png');
export const placeholderImage = require('src/assets/images/placeholder.png');

export const iconsString = {
	beneficios: "hand-holding-medical",
	negocios: "building",
	vagas: "briefcase",
	candidaturas: "paper-plane",
	recomendacoes: "face-smile",
	ideias: "lightbulb",
	reunioes: "video",
	notificacoes: "bell",
	conta: "user",
	calendario: "calendar",
	dashboard: "gauge",
	contactos: "phone",
	clientes: "user-tie",
}