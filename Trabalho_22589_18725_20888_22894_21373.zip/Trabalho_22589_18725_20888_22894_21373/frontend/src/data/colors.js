export function getCssColors(cssColor) {
	const rootStyles = getComputedStyle(document.documentElement);
	return rootStyles.getPropertyValue(`--${cssColor}`).trim();
}

/*const darkPrimaryColor = rootStyles.getPropertyValue('--dark-primary-color').trim();
const lightPrimaryColor = rootStyles.getPropertyValue('--light-primary-color').trim();
const primaryColor = rootStyles.getPropertyValue('--primary-color').trim();
const accentColor = rootStyles.getPropertyValue('--accent-color').trim();
const primaryBlackColor = rootStyles.getPropertyValue('--primary-black-color').trim();
const secondaryBlackColor = rootStyles.getPropertyValue('--secondary-black-color').trim();
const primaryWhiteColor = rootStyles.getPropertyValue('--primary-white-color').trim();
const primaryTextColor = rootStyles.getPropertyValue('--primary-text-color').trim();
const secondaryTextColor = rootStyles.getPropertyValue('--secondary-text-color').trim();
const inverseTextColor = rootStyles.getPropertyValue('--inverse-text-color').trim();
const dividerColor = rootStyles.getPropertyValue('--divider-color').trim();
const whiteBackgroundColor = rootStyles.getPropertyValue('--white-background-color').trim();
const dangerColor = rootStyles.getPropertyValue('--danger-color').trim();
const successColor = rootStyles.getPropertyValue('--success-color').trim();
const infoColor = rootStyles.getPropertyValue('--info-color').trim();
const lightPrimaryColorTransparent = rootStyles.getPropertyValue('--light-primary-color-transparent').trim();
const dangerColorTransparent = rootStyles.getPropertyValue('--danger-color-transparent').trim();
const infoColorTransparent = rootStyles.getPropertyValue('--info-color-transparent').trim();
const successColorTransparent = rootStyles.getPropertyValue('--success-color-transparent').trim();*/